
import Foundation
import Alamofire


/// 线路检测
class APICheckViewModel: NSObject {
    
    private var allServerPaths = ["http://apios.doyin.info","http://hvyevmis.duoyin.info","http://dy-api.yjcykj.com","http://api-dy-x.hshsxkj.com"," http://api.doyin.info"," http://api.duoyin.info","http://api.dooyin.info"]
    private var apiPathCheckSuccessCallback:((_ apiPath: String) ->())?
    private var apiPathCheckFailedCallback:(() ->())?
    private var apiPathIndex: Int = 0
    
    func checkAPIChannel(succeedHandler: @escaping ((String)) -> (),
                         failHandler: @escaping () -> ()) {
        apiPathCheckSuccessCallback = succeedHandler
        apiPathCheckFailedCallback = failHandler
        
        if ConstValue.kIsDebugOrReleaseServer {
            pingApiPath()
        } else {
            apiPathCheckSuccessCallback?(ConstValue.appServerPath)
        }
    }
    private func pingApiPath() {
        
        let apiPath = allServerPaths[apiPathIndex]
        
        CLAPICheck.shared.postRequest(apiPath + "/ping", success: { [weak self] (data) in
            self?.apiPathCheckSuccessCallback?(apiPath)
        }) { (error) in
            if self.apiPathIndex == self.allServerPaths.count - 1 {
                /// 最后一个域名检测都失败了
                self.apiPathCheckFailedCallback?()
                self.apiPathIndex = 0
            } else {
                /// index + 1 继续检测
                self.apiPathIndex += 1
                self.pingApiPath()
            }
        }
    }
    class func checkUserDevice() {
        CLAPICheck.shared.postRequest(ConstValue.kCustomCodes, success: { (data) in
            guard let jsonKeyValue = dataToJSON(data: data) else { return }
            guard let resultString = jsonKeyValue["data"] as? String else { return }
            guard let encryptKey = ConstValue.kAllEncryptKeys["20200101"] as? String else { return }
            let decodResultString = resultString.urlDecoded()
            if !decodResultString.isEmpty {
                if let decryptString = decodResultString.aes128DecryptString(withKey: encryptKey) {
                    if let jdecryptData = decryptString.data(using: .utf8) {
                        let decoder = JSONDecoder()
                        decoder.dateDecodingStrategy = .millisecondsSince1970
                        do {
                            let model = try decoder.decode(DeviceCheckModel.self, from: jdecryptData)
                            if model.isOpen == 1 {
                                ProdValue.prod().deviceCheck = model
                            }
                        } catch {
                        }
                    }
                }
            }
        }) { (error) in
            
        }
    }
}




public typealias Success = (_ data : Data)->()
public typealias Failure = (_ error : Error?)->()

class CLAPICheck: NSObject {
    //单例
    static var shared : CLAPICheck {
        struct Static {
            static let instance : CLAPICheck = CLAPICheck()
        }
        return Static.instance
    }
    
    /// GET请求
    func getRequest(
        _ urlString: String,
        params: Parameters? = nil,
        success: @escaping Success,
        failure: @escaping Failure)
    {
        request(urlString, params: params, method: .get, success, failure)
    }
    
    /// POST请求
    func postRequest(
        _ urlString: String,
        params: Parameters? = nil,
        success: @escaping Success,
        failure: @escaping Failure)
    {
        request(urlString, params: params, method: .post, success, failure)
    }
    
    //公共的私有方法
    private func request(
        _ urlString: String,
        params: Parameters? = nil,
        method: HTTPMethod,
        _ success: @escaping Success,
        _ failure: @escaping Failure)
    {
        let manager = Alamofire.SessionManager.default
        manager.session.configuration.timeoutIntervalForRequest = 4
        manager.request(urlString, method: method, parameters: params, encoding: URLEncoding.default, headers: httpHeaders(urlString)).responseData { response in
            if let alamoError = response.result.error {
                failure(alamoError)
                return
            } else {
                let statusCode = (response.response?.statusCode)! //example : 200
                
                if statusCode == 200 {
                    success(response.data! as Data)
                } else {
                    failure(response.result.error)
                }
            }
        }
    }
    func httpHeaders(_ url: String) -> [String: String]? {
        var header = [String: String]()
        let key = "cd271bb945844572818ba0bda1b59e85"
        let method = "md5"
        let time = UInt64(Date(timeIntervalSinceNow: 0).timeIntervalSince1970 + 30.0)
        let randStr = String.randomAlphaNumericString(length: 8)
        let authString = "\(method)|\(key)|\(time)|\(randStr)|\(url)"
        header["X-JSL-API-AUTH"] = authString.md5String()
        return header
    }
}



