
import UIKit
import NicooNetwork

class XSVideoService: NicooService {
    
    static let appVersion: String = {
        let filePath = Bundle.main.path(forResource: "Info", ofType: "plist")
        let dictionary = NSDictionary(contentsOfFile: filePath!)
        return dictionary!["CFBundleShortVersionString"] as! String
    }()
    
    /**
     自定义拼接规则
     */
    override func urlGeneratingRule(_ apiMethodName: String) -> String {
        return String(format: "%@/%@", apiBaseURL ?? "", apiMethodName)
    }
}

extension XSVideoService: NicooServiceProtocol {
    
    /// 标记是否是生产环境
    var isProductionEnvironment: Bool {
       return true
    }

    /// 生产环境API base url
    var productionAPIBaseURL: String {
        return ProdValue.prod().kProdUrlBase ?? ""
    }
    /// 开发环境API base url
    var developmentAPIBaseURL: String {
        return ProdValue.prod().kProdUrlBase ?? ""
    }

    /// 生产环境API版本
    var productionAPIVersion: String {
        return XSVideoService.appVersion
    }
    /// 开发环境API版本
    var developmentAPIVersion: String {
        return XSVideoService.appVersion
    }

    /// 生产环境公钥
    var productionPublicKey: String {
        return ""
    }
    /// 开发环境公钥
    var developmentPublicKey: String {
        return ""
    }
    /// 生产环境私钥
    var productionPrivateKey: String {
        return ""
    }
    /// 开发环境私钥
    var developmentPrivateKey: String {
        return ""
    }

    /// 为某些Service需要拼凑额外字段到URL处
   open func extraParams() -> [String: Any]? {
        return nil
    }
  
    /// 为某些Service需要拼凑额外的HTTPToken，如accessToken
    open func extraHttpHeadParams(_ methodName: String) -> [String: String]? {
        
        let vparam = "\(ConstValue.kAppVersion)t"
        var paramsNormal = [String: String]()
        paramsNormal["Accept"] = "application/json"
        paramsNormal["Content-Type"] = "application/json"
        paramsNormal["version"] = vparam
        let key = "cd271bb945844572818ba0bda1b59e85"
        let method = "md5"
        let url = urlGeneratingRule(methodName)
        let time = UInt64(Date(timeIntervalSinceNow: 0).timeIntervalSince1970 + 30.0)
        let randStr = String.randomAlphaNumericString(length: 8)
        let authString = "\(method)|\(key)|\(time)|\(randStr)|\(url)"
        DLog("url ==== \(authString)")
        DLog("md5Auth == \(authString.md5String())")
        paramsNormal["X-JSL-API-AUTH"] = authString.md5String()
        guard let encryptKey = ConstValue.kAllEncryptKeys[AppInfo.share().handShake!] as? String else {
            DLog("没有找到可以使用的密钥 +++ 0,当作不加密处理")
            return paramsNormal
        }
        /// 加密参数
        var paramEcropty = [String: String]()
        var param = [String : Any]()
        param["version"] = vparam
        param["device_no"] = UIDevice.current.getIdfv()
        if let token = UserDefaults.standard.value(forKey: UserDefaults.kUserToken) as? String {
            param["token"] = "\(token)"
        }
        param["device_type"] = "I"
        if let data = try? JSONSerialization.data(withJSONObject: param, options: [])  {
            if let string = String(data: data, encoding: .utf8) {
                if ConstValue.kIsEncryptoApi {
                    let stringEncrypto = string.aes128EncryptString(withKey: encryptKey)
                    paramEcropty["X-TOKEN"] = stringEncrypto
                } else {
                    paramEcropty["X-TOKEN"] = string
                }
            }
        }
       
        paramEcropty["Accept"] = "application/json"
        paramEcropty["Content-Type"] = "application/json"
        paramEcropty["X-JSL-API-AUTH"] = authString.md5String()
        paramEcropty["User-Agent"] = "Mozilla/5.0 (iPhone; CPU iPhone OS 5_1_1 like Mac OS X) AppleDart/534.46 (KHTML, like Gecko) Version/5.1 Mobile/9B206 Safari/7534.48.3"
        return paramEcropty
    }

    /**
     提供拦截器集中处理Service错误问题，比如token失效等做一些特殊的处理
     返回false：代表程序不再继续错误回调，比如需要强制登錄，那么就直接回到登錄界面
     返回true：代表程序还需继续往下执行
     */
    open func shouldCallBackByFailedOnCallingAPI(_ response: NicooURLResponse?) -> Bool {
        tokenError = false
        guard let data = response?.content as? [String: Any] else {
            return true
        }
        let code = (data["code"] as? NSNumber)?.intValue
        if code == 403  || code == 4999 {
            // 发出被挤掉的消息
           // NotificationCenter.default.post(name: NSNotification.Name.kUserBeenLogOutNotification, object: nil)
            NotificationCenter.default.post(name: NSNotification.Name.kUserBeenLogOutNotification, object: nil, userInfo: ["code": code!])
            return true
        }
        if (data["message"] as? String) != nil {

        }
        return true
    }

    /**
     如果上面那个方法检测到是token失效，则把isTokenError置为true
     */
   open func isTokenError() -> Bool {
        return tokenError
    }

}
