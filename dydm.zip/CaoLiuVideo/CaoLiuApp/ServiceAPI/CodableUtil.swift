

/**
 用于解析JSON的全局方法 泛型, 可以处理一些公共的操作 例如：数据 的 解密， 加密等
 */

import Foundation

public func decode<T>(response: Data?, of: T.Type) throws -> T? where T: Codable {
    guard var responseData = response else { return nil }
    if let handShake = AppInfo.share().handShake, !handShake.isEmpty {  // 密钥存在 (只有第一个接口成功后，密钥才有可能存在)
        guard let decryptData = ConstValue.kIsEncryptoApi ? decryptJsonResultString(responseData) : responseData else { return nil }
        responseData = decryptData
    }
   
    let decoder = JSONDecoder()
    decoder.dateDecodingStrategy = .millisecondsSince1970
    do {
        let model = try decoder.decode(T.self, from: responseData)
        return model
    } catch {
        DLog("解析JSON出错: \(error)")
        return nil
    }
}

public struct ObjectResponse<T: Codable>: Codable {
   public let data: T?
}

fileprivate func decryptJsonResultString(_ responseData: Data) -> Data? {
    guard var jsonKeyValue = dataToJSON(data: responseData) else { return nil }
    guard let resultString = jsonKeyValue["data"] as? String else { return nil }
    if ConstValue.kAllEncryptKeys.count <= 0 || AppInfo.share().handShake == nil || AppInfo.share().handShake!.isEmpty {
        DLog("没有找到可以使用的密钥 +++ 2,当作不加密处理")
        return nil
    }
    guard let encryptKey = ConstValue.kAllEncryptKeys[AppInfo.share().handShake!] as? String else {
        DLog("没有找到可以使用的密钥 +++ 3,当作不加密处理")
        return nil
    }
    let decodResultString = resultString.urlDecoded()
    if !decodResultString.isEmpty {
        
        if let decryptString = decodResultString.aes128DecryptString(withKey: encryptKey) {
            if let jdecryptData = decryptString.data(using: .utf8) {
                let dict = try? JSONSerialization.jsonObject(with: jdecryptData, options: .mutableContainers)
               // DLog("decryptString \(decryptString)")
                jsonKeyValue["data"] = dict
            }
        }
    }
    if (!JSONSerialization.isValidJSONObject(jsonKeyValue)) {
        DLog("无法解析出JSONString")
        return nil
    }
    return try? JSONSerialization.data(withJSONObject: jsonKeyValue, options: [])
}

public func dataToJSON(data: Data) -> [String: Any]? {
    do {
        return try JSONSerialization.jsonObject(with: data , options: .mutableContainers) as? [String: Any]
    } catch {
        DLog(error)
    }
    return nil
}


public func jsonToData(json: [String : Any]) -> Data? {
    do {
        return try JSONSerialization.data(withJSONObject: json, options: .fragmentsAllowed) as? Data
    } catch {
        
    }
    return nil
}

