
import UIKit

class SearcHotCell: UICollectionViewCell {

    static let cellId = "SearcHotCell"
    var titleLab: UILabel = {
        let lan = UILabel()
        lan.font = UIFont.systemFont(ofSize: 13)
        lan.textAlignment = .center
        lan.textColor = UIColor.white
        lan.layer.cornerRadius = 2
        lan.layer.masksToBounds = true
        return lan
    }()
  
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(titleLab)
        titleLab.frame = self.bounds
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutIfNeeded() {
        super.layoutIfNeeded()
        layoutSubviews()
    }
}

class SearcHotVCell: UICollectionViewCell {

    static let cellId = "SearcHotVCell"
    static let itemSize = CGSize(width: (screenWidth-50)/2, height: 35)
    var titleLab: UILabel = {
        let lan = UILabel()
        lan.font = UIFont.systemFont(ofSize: 13)
        lan.textAlignment = .left
        lan.textColor = UIColor.white
        return lan
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(titleLab)
        layoutPagesubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setModel(_ model: VideoNew, _ index: Int? = 0) {
           titleLab.text = "\(index ?? 1).\(model.title ?? "")"
    }
    private func layoutPagesubviews() {
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(0)
            make.centerY.equalToSuperview()
            make.trailing.equalTo(0)
        }
    }
}


class SearchUserCell: UICollectionViewCell {
    
    static let cellId = "SearchUserCell"
    static let itemSize = CGSize(width: (screenWidth - 60)/4, height: (screenWidth - 60)/4 + 40)
    static let itemSize1 = CGSize(width: (screenWidth - 90)/4.5, height: (screenWidth - 90)/4.5 + 40)
    let headerImg: UIImageView = {
        let image = UIImageView()
        image.contentMode = .scaleAspectFill
        return image
    }()
    var nameLab: UILabel = {
        let lan = UILabel()
        lan.font = UIFont.systemFont(ofSize: 14)
        lan.textAlignment = .center
        lan.textColor = .white
        return lan
    }()
    lazy var focusButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor.clear
        button.setImage(getImage("VideoSeriesAdd"), for: .normal)
        button.layer.cornerRadius = 11
        button.layer.masksToBounds = true
        button.layer.borderWidth = 0.7
        button.layer.borderColor = UIColor.white.cgColor
        button.addTarget(self, action: #selector(addFocusAction), for: .touchUpInside)
        return button
    }()
  
    var addFocusActionHandler:(() -> Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(headerImg)
        contentView.addSubview(nameLab)
        contentView.addSubview(focusButton)
        nameLab.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalToSuperview()
            make.height.equalTo(40)
        }
        headerImg.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.bottom.equalTo(-40)
        }
        focusButton.snp.makeConstraints { (make) in
            make.trailing.bottom.equalTo(headerImg)
            make.height.width.equalTo(22)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setUserModel(_ user: CLUserInfo) {
        headerImg.kfsetHeader(user.avatar)
        nameLab.text = user.nick
    }
    
    /// 1: 搜索 2: 关注推荐
    func setStype(_ stype: Int) {
        if stype == 1 {
            headerImg.layer.cornerRadius = (screenWidth - 60)/8
            headerImg.layer.masksToBounds = true
            focusButton.isHidden = true
        } else if stype == 2 {
            headerImg.layer.cornerRadius = (screenWidth - 90)/9
            headerImg.layer.masksToBounds = true
            focusButton.isHidden = false
        }
    }
    
    @objc func addFocusAction() {
        tapRotationAnimation(focusButton)
        addFocusActionHandler?()
    }

}



class SearchUserListCell: UICollectionViewCell {

    static let cellId = "SearchUserListCell"
    let headerImg: UIImageView = {
        let v = UIImageView()
        v.borderRadius = 30
        return v
    }()
    var nameLab: UILabel = {
        let lan = UILabel()
        lan.font = UIFont.systemFont(ofSize: 14)
        lan.textColor = UIColor.white
        return lan
    }()
    var introLab: UILabel = {
        let lan = UILabel()
        lan.font = UIFont.systemFont(ofSize: 12)
        lan.textColor = .lightGray
        return lan
    }()
    var playCountLab: UILabel = {
        let lan = UILabel()
        lan.font = UIFont.systemFont(ofSize: 12)
        lan.textColor = .lightGray
        return lan
    }()
    lazy var attentionBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.backgroundColor = ConstValue.kStypeColor
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        btn.setTitle("关注", for: .normal)
        btn.setTitle("已关注", for: .selected)
        btn.setTitleColor(.white, for: .normal)
        btn.borderRadius = 16
        btn.addTarget(self, action: #selector(attentionClick), for: .touchUpInside)
        return btn
    }()
   
    var buttonClick:(() ->Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(headerImg)
        contentView.addSubview(nameLab)
        contentView.addSubview(introLab)
        contentView.addSubview(playCountLab)
        contentView.addSubview(attentionBtn)
        layoutPageSubs()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func attentionClick() {
        if !attentionBtn.isSelected {
            buttonClick?()
        }
    }
    func setModel(_ user: CLUserInfo) {
        headerImg.kfsetHeader(user.avatar)
        nameLab.text = user.nick
        if let intro = user.intro, !intro.isEmpty {
            introLab.text = intro
        } else {
            introLab.text = "暂无简介"
        }
        playCountLab.text = "\(getStringWithNumber(user.fans ?? 0))粉丝"
        attentionBtn.isSelected = user.is_attention == 1
        attentionBtn.backgroundColor = user.is_attention == 1 ? ConstValue.kCoverBgColor : ConstValue.kStypeColor
    }
    func layoutPageSubs() {
        attentionBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.centerY.equalToSuperview()
            make.height.equalTo(32)
            make.width.equalTo(70)
        }
        headerImg.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.centerY.equalToSuperview()
            make.height.width.equalTo(60)
        }
        nameLab.snp.makeConstraints { (make) in
            make.leading.equalTo(headerImg.snp.trailing).offset(10)
            make.top.equalTo(headerImg)
            make.height.equalTo(20)
        }
        introLab.snp.makeConstraints { (make) in
            make.leading.equalTo(nameLab)
            make.centerY.equalTo(headerImg)
            make.height.equalToSuperview()
            make.trailing.equalTo(attentionBtn.snp.leading).offset(-20)
        }
        playCountLab.snp.makeConstraints { (make) in
            make.leading.equalTo(nameLab)
            make.bottom.equalTo(headerImg)
            make.height.equalTo(20)
        }
    }
}


class SearchCommomCell: UICollectionViewCell {

    static let cellId = "SearchCommomCell"
    
    var itemView: ItemLayoutView?
    
    var searchKeyWordClick:((_ keyWork: String) -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = rgb(18, 18, 35)
        contentView.borderRadius = 7.5
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setModels(_ keys: [SearchHotTips]) {
        var searchs = [SearchHotTips]()
        if keys.count > 0 {
            keys.forEach { (str) in
                let model = SearchHotTips.init(id: nil, intro: nil, join: nil, play: nil, title: str.keyword, type_id: nil, video_count: nil, keyword: str.keyword, mcount: nil, selected: nil)
                searchs.append(model)
            }
            itemView = ItemLayoutView(aFrame: CGRect(x: 0, y: 0, width: (screenWidth - 40)/2, height: 50), aTitle: "大家都在搜", aArray: searchs)
            itemView?.backgroundColor = .clear
            itemView?.itemHotClick = {  [weak self] keywork in
                if let str = keywork.keyword, !str.isEmpty {
                    self?.searchKeyWordClick?(str)
                }
            }
            contentView.addSubview(itemView!)
            itemView?.snp.makeConstraints({ (make) in
                make.edges.equalToSuperview()
            })
        }
    }
    
    override func layoutIfNeeded() {
        super.layoutIfNeeded()
        layoutSubviews()
    }
}
