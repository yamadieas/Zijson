

import UIKit

class SearchNoDataHeader: UICollectionReusableView {
    
    static let reuseId = "SearchNoDataHeader"
    static let headerSize: CGSize = CGSize(width: screenWidth, height: 100.0)
    static let headerSizeShort: CGSize = CGSize(width: screenWidth, height: 30.0)
    lazy var label: UILabel = {
       let label = UILabel()
       label.text = ""
       label.textAlignment = .center
       label.font = UIFont.systemFont(ofSize: 15)
        label.textColor = UIColor.lightGray
       return label
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.clear
        addSubview(label)
        layoutPageViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

//MARK: -Layout
extension SearchNoDataHeader {
    
    private func layoutPageViews() {
        layoutLabel()
    }
    
    private func layoutLabel() {
        label.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.bottom.equalTo(0)
        }
    }
    
}


class SearchMoreFooter: UICollectionReusableView {
    static let reuseId = "SearchMoreFooter"
    
    lazy var moreButton: UIButton = {
        let btn = UIButton(type: .custom)
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        btn.borderRadius = 7.5
        btn.backgroundColor = ConstValue.kCoverBgColor
        btn.addTarget(self, action: #selector(buttonClick), for: .touchUpInside)
        return btn
    }()
    var actionHandler:(()->Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.clear
        addSubview(moreButton)
        moreButton.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.width.equalTo(180)
            make.height.equalTo(38)
        }
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @objc func buttonClick() {
        actionHandler?()
    }
}
