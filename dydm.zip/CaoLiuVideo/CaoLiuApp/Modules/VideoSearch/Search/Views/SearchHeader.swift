
import UIKit

class SearchHeader: UIView {

    @IBOutlet weak var barView: UIView!
    @IBOutlet weak var grayFakeView: UIView!
    @IBOutlet weak var searchTf: UITextField!
    @IBOutlet weak var cancleBtn: UIButton!
    @IBOutlet weak var searchPic: UIImageView!
    @IBOutlet weak var rightBtnWidth: NSLayoutConstraint!
    var cancleAction:(() -> ())?
    var searchAction:(() ->Void)?
    
    @IBAction func cancleAction(_ sender: UIButton) {
        searchAction?()
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        barView.backgroundColor = .clear
        grayFakeView.backgroundColor = ConstValue.kCoverBgColor
        cancleBtn.setTitleColor(UIColor.white, for: .normal)
        searchTf.setPlaceholderTextColor(placeholderText: "輸入關鍵詞搜索內容", color: UIColor.lightGray)
        searchPic.image = getImage("communitySeachIcon")
    }
    @IBAction func backAction(_ sender: UIButton) {
        cancleAction?()
    }
}

class NotDataTipsView: UIView {
    
    private let searchImg: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "GlobalNOData")
        return image
    }()
    private var nodateLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 15)
        lable.text = "未搜索到任何相關內容"
        return lable
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(nodateLable)
        addSubview(searchImg)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    private func layoutPageSubviews() {
        nodateLable.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview().offset(10)
        }
        searchImg.snp.makeConstraints { (make) in
            make.trailing.equalTo(nodateLable.snp.leading).offset(-5)
            make.centerY.equalToSuperview()
            make.width.height.equalTo(50)
        }
    }
}


class SearchBarView: UIView {
    let barBgView: UIView = {
        let v = UIView()
        v.backgroundColor = ConstValue.kAppSepLineColor
        v.layer.cornerRadius = 17.0
        v.layer.masksToBounds = true
        return v
    }()
    let searchIcon: UIImageView = {
        let img = UIImageView(image: getImage("communitySeachIcon"))
        img.isUserInteractionEnabled = true
        img.contentMode = .scaleAspectFit
        return img
    }()
    let textLab: UILabel = {
        let v = UILabel()
        v.textColor = .lightGray
        v.font = UIFont.systemFont(ofSize: 12)
        v.text = "搜索\(UserModel.share().authInfo?.config?.rule?.video_all ?? "10万")个视频"
        return v
    }()
    lazy var searchBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.tag = 1
        button.addTarget(self, action: #selector(searchClick(_:)), for: .touchUpInside)
        return button
    }()
    lazy var choseButton: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(getImage("selevideo"), for: .normal)
        button.setTitle(" 筛选 ", for: .normal)
        button.tag = 2
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 13)
        button.backgroundColor = ConstValue.kAppSepLineColor
        button.layer.cornerRadius = 15
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(searchClick(_:)), for: .touchUpInside)
        return button
    }()
    var barClickAction:((_ actId: Int) ->Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(barBgView)
        addSubview(choseButton)
        addSubview(searchIcon)
        addSubview(textLab)
        addSubview(searchBtn)
        layoutSubs()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func hideChoseBtn() {
        choseButton.isHidden = true
        barBgView.snp.updateConstraints { (make) in
            make.trailing.equalTo(-12)
        }
    }
    @objc func searchClick(_ sender: UIButton) {
        barClickAction?(sender.tag)
    }
    func layoutSubs() {
        barBgView.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.height.equalTo(34)
            make.leading.equalTo(12)
            make.trailing.equalTo(-78)
        }
        choseButton.snp.makeConstraints { (make) in
            make.leading.equalTo(barBgView.snp.trailing).offset(10)
            make.centerY.equalTo(barBgView)
            make.height.equalTo(30)
            make.trailing.equalTo(-15)
        }
        searchIcon.snp.makeConstraints { (make) in
            make.leading.equalTo(barBgView).offset(10)
            make.centerY.equalToSuperview()
            make.height.width.equalTo(16)
        }
        textLab.snp.makeConstraints { (make) in
            make.leading.equalTo(searchIcon.snp.trailing).offset(6)
            make.trailing.equalTo(barBgView.snp.trailing).offset(-10)
            make.centerY.equalTo(barBgView)
        }
        searchBtn.snp.makeConstraints { (make) in
            make.edges.equalTo(barBgView)
        }
    }
}
