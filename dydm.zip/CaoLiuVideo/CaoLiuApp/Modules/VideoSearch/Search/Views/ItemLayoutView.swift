
import UIKit

/// 自动布局画BUtton
class ItemLayoutView: UIView {
    
    var showTitle: Bool = true
    
    var titleLable: UILabel?
    var titleText: String = "熱門搜索" {
        didSet {
            titleLable?.text = titleText
        }
    }
    var buttons = [UIButton]()
    var itemModels = [SearchHotTips]()
    var seletedModels = [SearchHotTips]()
    var itemHotClick:((_ keyModel: SearchHotTips) -> Void)?
    init(aFrame: CGRect, aTitle: String, aArray: [SearchHotTips], _ haveTitle: Bool? = true) {
        super.init(frame: aFrame)
        self.backgroundColor = UIColor.clear
        showTitle = haveTitle ?? true
        titleText = aTitle
        itemModels = aArray
        self.viewLayoutWith(aTitle: aTitle, aArray: aArray)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //计算字体布局
    func viewLayoutWith(aTitle: String, aArray: [SearchHotTips]) {
        if aArray.count == 0 { return }
        self.removeAllSubviews()
        let tipLabel = UILabel.init(frame: CGRect.init(x: 15, y: 5, width: self.frame.size.width-30, height: 45))
        tipLabel.font = UIFont.boldSystemFont(ofSize: 16)
        tipLabel.textColor = UIColor.white
        tipLabel.text = titleText
        titleLable = tipLabel
        self.addSubview(tipLabel)
        titleLable?.isHidden = !showTitle
        var zX = CGFloat(15) //记录按钮的X
        var zY = CGFloat(showTitle ? 50 : 10) //记录按钮的Y - 对应 tipLabel.height + tipLabel.frame.origin.y
        let zH = CGFloat(32) //记录按钮的高
        for (index,value) in aArray.enumerated() {
            let valueC : String = showTitle ? value.keyword ?? "" : value.title ?? "" 
            var size = SizeWithFont(content: valueC as NSString, font: UIFont.systemFont(ofSize: 14), maxSize: CGSize.init(width: self.frame.size.width - 12*3, height: 32))
            size.width = size.width + 18 //每个按钮的长度
            //如果摆放的按钮大于屏幕宽 则另起一行
            if (zX+size.width+12) > self.frame.size.width {
                zY = zY + (zH+10) //10是按钮上下间的间隔
                zX = 15 //初始值
            }
            //最后一个按钮离底部距离 10
            if (zY+zH)>self.frame.size.height {
                //加一个上下间隔和按钮高度
                self.frame.size.height = zY + zH + 10
            }
            let colorNormal = ConstValue.kCoverBgColor
            let buton = UIButton(type: .custom)
            buton.tag = index
            buton.frame = CGRect(x: zX, y: zY, width: size.width, height: zH)
            buton.setBackgroundImage(UIImage.imageFromColor(colorNormal, frame: CGRect(x: 0, y: 0, width: 120, height: zH)), for: .normal)
            buton.setBackgroundImage(UIImage.imageFromColor(ConstValue.kStypeColor, frame: CGRect(x: 0, y: 0, width: 120, height: zH)), for: .selected)
            buton.setTitleColor(UIColor.white, for: .normal)
            buton.setTitleColor(UIColor.white, for: .selected)
            buton.setTitle(valueC, for: .normal)
            buton.titleLabel?.font = UIFont.systemFont(ofSize: 14)
            buton.layer.cornerRadius = 5 //zH/2
            buton.layer.masksToBounds = true
            buton.addTarget(self, action: #selector(buttonAction(sender:)), for: .touchUpInside)
            self.addSubview(buton)
           
            zX = zX + (buton.frame.size.width+12) //12是按钮左右间的间隔
        }
    }
    
    @objc func buttonAction(sender: UIButton) {
        itemHotClick?(itemModels[sender.tag])
    }
}

extension ItemLayoutView {
    func removeAllSubviews() {
        while self.subviews.count > 0{
            self.subviews.last?.removeFromSuperview()
        }
    }
    //font size
    func SizeWithFont(content : NSString, font : UIFont, maxSize : CGSize) -> CGSize {
        return content.boundingRect(with: maxSize, options: (NSStringDrawingOptions(rawValue: NSStringDrawingOptions.usesLineFragmentOrigin.rawValue | NSStringDrawingOptions.usesFontLeading.rawValue)), attributes: [NSAttributedString.Key.font : font], context: nil).size
    }
}
