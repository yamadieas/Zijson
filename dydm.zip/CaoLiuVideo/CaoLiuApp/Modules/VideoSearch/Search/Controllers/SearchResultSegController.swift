

import UIKit
import JXSegmentedView
import NicooNetwork

class SearchResultSegController: UIViewController {

    var titles = [String]()
    let dataSource = JXSegmentedTitleDataSource()
    let segmentedView = JXSegmentedView()
    lazy var listContainerView: JXSegmentedListContainerView! = {
        return JXSegmentedListContainerView(dataSource: self)
    }()
    
    let selectedLabel:UILabel = {
        let lab = UILabel()
        lab.text = "综合"
        lab.textColor = .white
        lab.textAlignment = .right
        lab.font = UIFont.systemFont(ofSize: 14)
        return lab
    }()
    let arrow: UIImageView = {
        let ar = UIImageView(image: getImage("downArrow"))
        ar.isUserInteractionEnabled = true
        return ar
    }()
    let selectedView: UIView = {
        let v = UIView()
        return v
    }()
    lazy var cateButton: UIButton = {
        let v = UIButton(type: .custom)
        v.addTarget(self, action: #selector(selectedAction(_:)), for: .touchUpInside)
        return v
    }()
    var popover: Popover = {
        let popoverOptions: [PopoverOption] = [
            .type(.auto),
            .blackOverlayColor(UIColor(white: 0.0, alpha: 0.6))
        ]
        let p = Popover(options: popoverOptions)
        return p
    }()
    
    let list1 = SearchVListController()
    let list2 = SearchVListController()
    let list3 = SearchVListController()
    
    var searchkey: String?
    var isHot: Bool = false
    
    var currentSegIndex: Int = 0
    
    var selectedIndex: Int = 0
    
    var indexChangeHandler:((_ index: Int) -> Void)?

    let selectedTexts = ["综合","播放最多","收藏最多","最新视频"]
    var keyChangeHandler:((_ keyWork: String) ->Void)?
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .clear
        setUpUI()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        listContainerView.frame = CGRect(x: 0, y: 55, width: view.bounds.size.width, height: view.bounds.size.height - 55)
    }
    
    func setUpUI() {
        dataSource.titles = titles
        dataSource.isTitleMaskEnabled = true
        dataSource.titleNormalFont = UIFont.systemFont(ofSize: 14)
        dataSource.titleSelectedZoomScale = 1.1
        dataSource.titleNormalColor = .white
        dataSource.titleSelectedColor = .white
        dataSource.itemSpacing = 25
        dataSource.isItemSpacingAverageEnabled = false
    
        let indicator = JXSegmentedIndicatorBackgroundView()
        indicator.indicatorColor = ConstValue.kStypeColor
        indicator.isIndicatorConvertToItemFrameEnabled = true
        indicator.indicatorCornerRadius = 4
        indicator.indicatorHeight = 28
        segmentedView.frame = CGRect(x: 0, y: 10, width: screenWidth, height: 40)
        segmentedView.dataSource = dataSource
        segmentedView.indicators = [indicator]
        
        view.addSubview(segmentedView)
        segmentedView.listContainer = listContainerView
        view.addSubview(listContainerView)
        setUpSelectedView()
    }
    func setUpSelectedView() {
        selectedView.addSubview(arrow)
        selectedView.addSubview(selectedLabel)
        segmentedView.addSubview(selectedView)
        arrow.snp.makeConstraints { (make) in
            make.trailing.equalTo(-5)
            make.centerY.equalToSuperview()
            make.height.width.equalTo(5)
        }
        selectedLabel.snp.makeConstraints { (make) in
            make.trailing.equalTo(arrow.snp.leading).offset(-3)
            make.centerY.equalToSuperview()
        }
        selectedView.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.centerY.equalToSuperview()
            make.width.equalTo(50)
            make.height.equalTo(40)
        }
        selectedView.addSubview(cateButton)
        cateButton.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    @objc func selectedAction(_ sender: UIButton) {
        let tableView = UITableView(frame: CGRect(x: 0, y: 10, width: 120, height: 160))
        tableView.delegate = self
        tableView.dataSource = self
        tableView.isScrollEnabled = false
        popover.show(tableView, fromView: cateButton)
    }
}

extension SearchResultSegController: JXSegmentedListContainerViewListDelegate {
    func listView() -> UIView {
        return view
    }
}

extension SearchResultSegController: JXSegmentedListContainerViewDataSource {
    func numberOfLists(in listContainerView: JXSegmentedListContainerView) -> Int {
        if let titleDataSource = segmentedView.dataSource as? JXSegmentedBaseDataSource {
            return titleDataSource.dataSource.count
        }
        return 0
    }

    func listContainerView(_ listContainerView: JXSegmentedListContainerView, initListAt index: Int) -> JXSegmentedListContainerViewListDelegate {
        if index == 0 {
            list1.segmentIndex = 0
            list1.searchkey = self.searchkey
            list1.isHot = isHot
            list1.vcShowCallBack = { [weak self] str in
                self?.currentSegIndex = 0
                if let keyWork = str, !keyWork.isEmpty {
                    self?.searchkey = keyWork
                    self?.list2.searchkey = keyWork
                    self?.list3.searchkey = keyWork
                    self?.keyChangeHandler?(keyWork)
                }
            }
            return list1
        } else if index == 1 {
            list2.segmentIndex = 1
            list2.searchkey = self.searchkey
            list2.isHot = isHot
            list2.vcShowCallBack = { [weak self] _ in
                self?.currentSegIndex = 1
            }
            return list2
        } else {
            list3.segmentIndex = 2
            list3.searchkey = self.searchkey
            list3.isHot = isHot
            list3.vcShowCallBack = { [weak self] _ in
                self?.currentSegIndex = 2
            }
            return list3
        }
    }
}

extension SearchResultSegController: UITableViewDelegate,UITableViewDataSource {
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 40
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        self.popover.dismiss()
        selectedIndex = indexPath.row
        selectedLabel.text = selectedTexts[selectedIndex]
        if selectedIndex == 0 {
            list1.orderKey = nil
            list2.orderKey = nil
            list3.orderKey = nil
        } else if selectedIndex == 1 {
            list1.orderKey = SearchVideoApi.kPlayCount
            list2.orderKey = SearchVideoApi.kPlayCount
            list3.orderKey = SearchVideoApi.kPlayCount
        } else if selectedIndex == 2 {
            list1.orderKey = SearchVideoApi.kOrder_keyLike
            list2.orderKey = SearchVideoApi.kOrder_keyLike
            list3.orderKey = SearchVideoApi.kOrder_keyLike
        } else if selectedIndex == 3 {
            list1.orderKey = SearchVideoApi.kOrder_keyOnline_at
            list2.orderKey = SearchVideoApi.kOrder_keyOnline_at
            list3.orderKey = SearchVideoApi.kOrder_keyOnline_at
        }
        switch currentSegIndex {
        case 0:
            list1.loadData()
            break
        case 1:
            list2.loadData()
            break
        case 2:
            list3.loadData()
            break
        default:
            break
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return selectedTexts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: .default, reuseIdentifier: nil)
        cell.textLabel?.text = self.selectedTexts[indexPath.row]
        cell.textLabel?.textAlignment = .center
        cell.textLabel?.font = UIFont.boldSystemFont(ofSize: 12)
        if selectedIndex == indexPath.row {
            cell.textLabel?.textColor = ConstValue.kStypeColor
        } else {
            cell.textLabel?.textColor = .darkText
        }
        return cell
    }
}
