
import UIKit
import NicooNetwork
import MJRefresh
import JXPagingView

class SearchCaTipsController: CLBaseViewController {
    
    private let layoutF : UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = SearcHotVCell.itemSize
        layout.minimumLineSpacing = 10   // 垂直最小间距
        layout.minimumInteritemSpacing = 20 // 水平最小间距
        layout.sectionInset = UIEdgeInsets(top: 10 , left: 15, bottom: 0, right: 15)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layoutF)
        collection.delegate = self
        collection.dataSource = self
        collection.showsVerticalScrollIndicator = true
        collection.backgroundColor = UIColor.clear
        collection.register(SearcHotVCell.classForCoder(), forCellWithReuseIdentifier: SearcHotVCell.cellId)
        collection.register(SearchMoreFooter.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: SearchMoreFooter.reuseId)
        return collection
    }()
    private lazy var tipsSearchApi: SearchModuleApi = {
        let api = SearchModuleApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()

    var listViewDidScrollCallback: ((UIScrollView) -> ())?
    var videos = [VideoNew]()
    
    var searchChannel: SearchChannel?
    var segIndex: Int = 0
  
    var isRecommend: Bool = false
    var notResult: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(collectionView)
        layoutPageSubViews()
        loadData()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        collectionView.frame = view.bounds
    }
    func loadData() {
        if segIndex > 0 {
            notResult = false
            XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
            NicooErrorView.removeErrorMeesageFrom(view)
            let _ = tipsSearchApi.loadData()
        }
    }
   
}

extension SearchCaTipsController: JXPagingViewListViewDelegate {
    func listView() -> UIView {
        return self.view
    }

    func listScrollView() -> UIScrollView {
        return collectionView
    }

    func listViewDidScrollCallback(callback: @escaping (UIScrollView) -> ()) {
        listViewDidScrollCallback = callback
    }
}

// MARK: - UIScrollViewDelegate
extension SearchCaTipsController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        listViewDidScrollCallback?(scrollView)
    }
}

// MARK: - UICollectionViewDataSource && UICollectionViewDelegate
extension SearchCaTipsController: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        if segIndex > 0 {
            return CGSize(width: screenWidth, height: 65)
        }
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return videos.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SearcHotVCell.cellId, for: indexPath) as! SearcHotVCell
        let model = videos[indexPath.item]
        cell.setModel(model, indexPath.item + 1)
        return cell
    }

    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: SearchMoreFooter.reuseId, for: indexPath) as! SearchMoreFooter
        header.moreButton.setTitle("更多\(searchChannel?.title ?? "")", for: .normal)
        header.actionHandler = { [weak self] in
            if let link = self?.searchChannel?.more_link, !link.isEmpty {
                self?.goInnerLink(link)
            }
        }
        return header
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let video = videos[indexPath.item]
        if video.is_long == 1 {
            goLongVideoDetail(video)
        } else {
            goShortVideoPlayerVC(video)
        }
    }
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension SearchCaTipsController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is SearchModuleApi {
            return [SearchModuleApi.kChannelId : searchChannel?.id ?? 0]
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if  manager is SearchModuleApi {
            if let modules = manager.fetchJSONData(SearchReformer()) as? SearchChannel {
                searchChannel = modules
                if let models = modules.video_list {
                    videos = models
                }
                collectionView.reloadData()
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
    }
}

// MARK: - Layout
extension SearchCaTipsController {
    private func layoutPageSubViews() {
        layoutCollectionView()
    }
    
    private func layoutCollectionView() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.bottom.trailing.equalToSuperview()
            make.top.equalToSuperview()
        }
    }
}
