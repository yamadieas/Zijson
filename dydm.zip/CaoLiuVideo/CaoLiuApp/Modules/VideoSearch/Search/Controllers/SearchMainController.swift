
import UIKit
import JXPagingView
import NicooNetwork

class SearchMainController: BasePagerViewController {
    
    private var searchView: SearchHeader = {
        guard let view = Bundle.main.loadNibNamed("SearchHeader", owner: nil, options: nil)?[0] as? SearchHeader else { return SearchHeader() }
        view.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: statusBarHeight + 44)
        view.backgroundColor = ConstValue.kVcViewColor
        view.cancleBtn.setTitle("搜索", for: .normal)
        return view
    }()
    private lazy var cleanbtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.frame = CGRect(x: screenWidth - 32, y: 20, width: 14, height:16)
        btn.setImage(getImage("cleanRbsIcon"), for: .normal)
        btn.addTarget(self, action: #selector(deleteSearchHistory), for: .touchUpInside)
        return btn
    }()
    let headerView = UIView()
    var recordView: ItemLayoutView?
    var historyView: ItemLayoutView?

    private lazy var searchMainApi: SearchMainDataApi = {
        let api = SearchMainDataApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var searchHotApi: SearchHotTextApi = {
        let api = SearchHotTextApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    let isNy = 0
    
    var keyModels = [SearchHotTips]()
    var historySearchs = [SearchHotTips]()
    
    var searchModel: SearchMainModel?
    
    var segVCs = [SearchCaTipsController]()
    
    let list1 = DiscoverVideoController()
    let list2 = DiscoverVideoController()
    let list3 = SearchCaTipsController()
    let list4 = SearchAnchorController()
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(searchView)
        searchView.searchTf.delegate = self
        layouSearchView()
        searchView.cancleAction = { [weak self] in
            guard let strSelf = self else { return }
            strSelf.navigationController?.popViewController(animated: true)
        }
        searchView.searchAction = { [weak self] in
            guard let strSelf = self else { return }
            if strSelf.searchView.searchTf.text == nil || strSelf.searchView.searchTf.text!.isEmpty {
                XSAlert.show(type: .text, text: "请輸入搜索內容")
                return
            }
            strSelf.searchWithKey(strSelf.searchView.searchTf.text)
            strSelf.saveSearchHistoryItem(strSelf.searchView.searchTf.text)
        }
        loadData()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        navigationController?.setNavigationBarHidden(true, animated: false)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        pagingView.frame =  CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight)
    }
    override func pagingView(_ pagingView: JXPagingView, initListAtIndex index: Int) -> JXPagingViewListViewDelegate {
        let vc = SearchCaTipsController()
        vc.segIndex = index
        if index == 0 {
            if let models = searchModel?.hot {
                vc.videos = models
            }
        } else {
            if let tags = searchModel?.tag {
                vc.searchChannel = tags[index - 1]
            }
        }
        return vc
    }
    override func preferredPagingView() -> JXPagingView {
        return JXPagingListRefreshView(delegate: self)
    }
    override func tableHeaderViewHeight(in pagingView: JXPagingView) -> Int {
        return  tableHeaderViewHeight + Int(safeAreaTopHeight)
    }
    override func tableHeaderView(in pagingView: JXPagingView) -> UIView {
        return headerView
    }
   
    // 数据请求
    private func loadData() {
        XSProgressHUD.showProgress(msg: nil, onView: view, animated: true)
        let _ = searchMainApi.loadData()
        if UserModel.share().searchHotTips == nil {
            _ = searchHotApi.loadData()
        }
    }
    
    func setUpPage() {
        var segTitles = [String]()
        segTitles.append("热门")
        if let tags = searchModel?.tag, tags.count > 0 {
            let all = tags.map { (model) -> String in
                return model.title ?? "未知"
            }
            segTitles.append(contentsOf: all)
        }
        
        titles = segTitles
        pagingView.mainTableView.backgroundColor = UIColor.clear
        //导航栏隐藏就是设置pinSectionHeaderVerticalOffset属性即可，数值越大越往下沉
        pagingView.pinSectionHeaderVerticalOffset = Int(safeAreaTopHeight)
        dataSource.isItemSpacingAverageEnabled = false
        dataSource.titleNormalFont = UIFont.systemFont(ofSize: 16)
        dataSource.titleSelectedFont = UIFont.boldSystemFont(ofSize: 20)
        dataSource.titleNormalColor = UIColor.lightGray
        dataSource.titleSelectedStrokeWidth = -1
        dataSource.titleSelectedColor = .white
        dataSource.titles = titles
        segmentedView.contentEdgeInsetLeft = 20
        pagingView.reloadData()
        segmentedView.reloadData()
    }
   
    func setUpUI() {
        var hisHeight: CGFloat = 0
        if let his = getHistorySearch(),his.count > 0 {
            his.forEach { (str) in
                let model = SearchHotTips.init(id: nil, intro: nil, join: nil, play: nil, title: str, type_id: nil, video_count: nil, keyword: str, mcount: nil, selected: nil)
                historySearchs.append(model)
            }
            historyView = ItemLayoutView(aFrame: CGRect(x: 0, y: safeAreaTopHeight, width: screenWidth, height: 50), aTitle: "历史搜索", aArray: historySearchs)
            historyView?.backgroundColor = .clear
            headerView.addSubview(historyView!)
            historyView?.addSubview(cleanbtn)
            hisHeight = historyView!.frame.height
            historyView?.itemHotClick = {  [weak self] keywork in
                self?.searchWithKey(keywork.keyword ?? "")
            }
        }
        var hotHeight: CGFloat = 0
        if let hotSearch = searchModel?.keyword, hotSearch.count > 0 {
            //封装的view
            recordView = ItemLayoutView(aFrame: CGRect(x: 0, y: safeAreaTopHeight + hisHeight, width: screenWidth, height: 50), aTitle: "热门搜索", aArray: hotSearch)
            recordView?.backgroundColor = .clear
            headerView.addSubview(recordView!)
            DLog("recordViewFrame = \(recordView!.frame)")
            hotHeight = recordView!.frame.size.height
            recordView?.itemHotClick = { [weak self] keywork in
                self?.searchWithKey(keywork.keyword ?? "", true)
            }
        }
        headerView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: safeAreaTopHeight + hisHeight + hotHeight)
        headerView.backgroundColor = ConstValue.kVcViewColor
        tableHeaderViewHeight = Int(hotHeight + hisHeight)
        setUpPage()
    }
    
   /// - Parameter keyWord: 关键词
    private func searchWithKey(_ keyWord: String?, _ isHot: Bool? = false) {
        searchView.searchTf.resignFirstResponder()
        searchView.searchTf.endEditing(true)
        // 跳转到搜索详情
        let searchRedvc = SearchResultController()
        searchRedvc.searchkey = keyWord
        searchRedvc.isHot = isHot ?? false
        navigationController?.pushViewController(searchRedvc, animated: false)
        searchRedvc.beginSearch = { [weak self] in
            self?.searchView.searchTf.becomeFirstResponder()
            searchRedvc.navigationController?.popViewController(animated: false)
        }
    }
}
extension SearchMainController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField.text == nil || textField.text!.isEmpty {
            XSAlert.show(type: .error, text: "请輸入搜索內容")
            return true
        }
        searchWithKey(textField.text)
        saveSearchHistoryItem(textField.text)
        return true
    }
}


// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension SearchMainController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is SearchMainDataApi {
            if let model = manager.fetchJSONData(SearchReformer()) as? SearchMainModel {
                searchModel = model
                setUpUI()
            }
        }
        if manager is SearchHotTextApi {
            if let models = manager.fetchJSONData(SearchReformer()) as? [SearchHotTips] {
                UserModel.share().searchHotTips = models
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        setUpUI()
    }
}

extension SearchMainController {
    func layouSearchView() {
        searchView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
    }
}

extension SearchMainController {
    /// 存储搜索历史
    private func saveSearchHistoryItem(_ text: String?) {
        if text == nil { return }
        guard var hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String] else {
            var array = [String]()
            array.append(text!)
            UserDefaults.standard.set(array, forKey: UserDefaults.kSearchHistory)
            return
        }
        if hisList.contains(text!) {
            hisList.removeAll { (str) -> Bool in
                return str == text!
            }
        }
        hisList.insert(text!, at: 0)
        if hisList.count > 15 {
            hisList.removeLast() // 移除最后一位
        }
        UserDefaults.standard.set(hisList, forKey: UserDefaults.kSearchHistory)
        
    }
       
    /// 清空搜索历史
    @objc private func deleteSearchHistory() {
        UserDefaults.standard.removeObject(forKey: UserDefaults.kSearchHistory)
        historySearchs.removeAll()
        historyView?.removeFromSuperview()
        recordView?.removeFromSuperview()
        setUpUI()
    }
       
    private func getHistorySearch() -> [String]? {
        if let hisList = UserDefaults.standard.array(forKey: UserDefaults.kSearchHistory) as? [String], hisList.count > 0 {
            let his = hisList.map { (str) -> String in
                return str
            }
            return his
        }
        return nil
    }
}



