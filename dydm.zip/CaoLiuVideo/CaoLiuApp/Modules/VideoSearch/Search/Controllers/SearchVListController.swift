import UIKit
import NicooNetwork
import MJRefresh
import JXSegmentedView

extension SearchVListController: JXSegmentedListContainerViewListDelegate {
    func listView() -> UIView {
        return self.view
    }
}

class SearchVListController: UIViewController {
   
    lazy var collectionView: UICollectionView = {
        let layout = WaterfallMutiSectionFlowLayout()
        layout.sectionHeadersPinToVisibleBounds = true
        layout.delegate = self
        
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsVerticalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(SearchCommomCell.classForCoder(), forCellWithReuseIdentifier: SearchCommomCell.cellId)
        collection.register(ShortVideoCell.classForCoder(), forCellWithReuseIdentifier: ShortVideoCell.cellId)
        collection.register(LongVideoCell.classForCoder(), forCellWithReuseIdentifier: LongVideoCell.cellId)
        collection.register(ADRandomCell.classForCoder(), forCellWithReuseIdentifier: ADRandomCell.cellId)
        collection.register(SegmentItemView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: SegmentItemView.identifier)
        collection.register(SegmentItemView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: SegmentItemView.identifier)
        collection.mj_footer = loadMoreView
        collection.mj_header = refreshView
        return collection
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
        loadmore?.setTitle("", for: .idle)
        loadmore?.setTitle("已經到底了", for: .noMoreData)
        loadmore?.stateLabel.font = ConstValue.kRefreshLableFont
        return loadmore!
    }()
    
    lazy private var refreshView: MJRefreshNormalHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshNormalHeader(refreshingBlock: {
            weakSelf?.loadFirstPage()
        })
        mjRefreshHeader?.activityIndicatorViewStyle = .white
        mjRefreshHeader?.arrowView.image = ConstValue.refreshImg
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()

    private lazy var videoListApi: SearchVideoApi =  {
        let api = SearchVideoApi()
        api.delegate = self
        api.paramSource = self
        api.isHot = isHot
        return api
    }()
  
    var cateModels = [VideoNew]()
 
    var segmentIndex: Int = 0
    var searchkey: String?
    var isHot: Bool = false
    /// 筛选条件
    var orderKey: String?
    /// 是否弹起短视频播放页
    var isPresentPlay: Bool = false
    
    var vcShowCallBack:((_ keyWork: String?) ->Void)?
    // MARK: - Life Cycly
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(collectionView)
        layoutPageSubviews()
        loadData()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        vcShowCallBack?(nil)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        collectionView.frame = view.bounds
    }
    private func goUserCenter(_ user: CLUserInfo?) {
        let userCenter = UserMCenterController()
        userCenter.userCode = user?.code
        navigationController?.pushViewController(userCenter, animated: true)
    }


}

// MARK: - Private - Funcs
extension SearchVListController {
    
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        _ = videoListApi.loadData()
    }
    func loadFirstPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        _ = videoListApi.loadData()
    }
    func loadNextPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = videoListApi.loadNextPage()
    }
    func endRefreshing() {
        collectionView.mj_footer.endRefreshing()
        collectionView.mj_header.endRefreshing()
    }
    
    func succeedRequest(_ models: [VideoNew]) {
        var videoModels = models
        if segmentIndex == 0 {
            let realDataCount = videoModels.count
            if let skip = UserModel.share().authInfo?.config?.rule?.ad_skip?.int, skip > 0 {
                if let adList = UserModel.share().authInfo?.video_out, adList.count > 0 {
                    let skipTimes = realDataCount/skip
                    if skipTimes > 0 {
                        for i in 1 ..< skipTimes + 1 {
                            let arm = arc4random()%(UInt32(adList.count))
                            let ad = adList[Int(arm)]
                            let model = VideoNew()
                            model.recAd = ad
                            if realDataCount > skip {
                                videoModels.insert(model, at: skip * i + i - 1)
                            }
                        }
                    }
                }
            }
        }
        if let hotSearch = UserModel.share().searchHotTips, hotSearch.count > 0 {
            let model = VideoNew()
            model.hotSearchs = hotSearch
            if videoModels.count > 3 {
                videoModels.insert(model, at: 3)
            }
        }
        let pageNumber = videoListApi.pageNumber
        if pageNumber == 1 {
            cateModels = videoModels
            if cateModels.count == 0 {
                NicooErrorView.showErrorMessage("未搜索到 “\(searchkey ?? "")“ 相关的视频", on: view, customerTopMargin: safeAreaTopHeight) {
                    self.loadData()
                }
            }
        } else {
            cateModels.append(contentsOf: videoModels)
        }
        loadMoreView.isHidden = models.count == 0
        collectionView.reloadData()
    }
    
    func failedRequest(_ manager: NicooBaseAPIManager) {
        endRefreshing()
        NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: safeAreaTopHeight + 60, clickHandler: {
            self.loadData()
        })
    }
}
extension SearchVListController: WaterfallMutiSectionDelegate {
    func heightForRowAtIndexPath(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, indexPath: IndexPath, itemWidth: CGFloat) -> CGFloat {
        if segmentIndex == 0 {
            let video = cateModels[indexPath.item]
            if let hots = video.hotSearchs, hots.count > 0 {
               let v = ItemLayoutView(aFrame: CGRect(x: 0, y: 0, width: (screenWidth - 40)/2, height: 50), aTitle: "大家都在搜", aArray: hots)
                return v.frame.height
            } else {
                if video.recAd != nil {
                    return ADRandomCell.itemSize.height
                } else {
                    if video.is_long == 1 {
                        return LongVideoCell.itemSizeDouble.height
                    } else {
                        return ShortVideoCell.itemSizeDouble.height
                    }
                }
            }
        } else if segmentIndex == 2 {
            return ShortVideoCell.itemSizeDouble.height
        } else if segmentIndex == 1 {
            return LongVideoCell.itemSizeDouble.height
        }
        return .zero
    }
    
    func columnNumber(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> Int {
        return 2
    }
    
  func referenceSizeForHeader(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGSize {
    return .zero
  }
  
  func referenceSizeForFooter(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGSize {
    return .zero
  }
  
  func insetForSection(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> UIEdgeInsets {
    return UIEdgeInsets(top: 5, left: 15, bottom: 5, right: 15)
  }
  
  
  func lineSpacing(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
    return 10.0
  }
  
  func interitemSpacing(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
    return 10.0
  }
  
  func spacingWithLastSection(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
    return 0
  }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension SearchVListController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return cateModels.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if segmentIndex == 0 {
            let video = cateModels[indexPath.item]
            if let hots = video.hotSearchs, hots.count > 0 {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SearchCommomCell.cellId, for: indexPath) as! SearchCommomCell
                cell.setModels(hots)
                cell.searchKeyWordClick = { [weak self] key in
                    self?.searchkey = key
                    self?.loadData()
                    self?.vcShowCallBack?(key)
                }
                return cell
            }
            if video.recAd != nil {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ADRandomCell.cellId, for: indexPath) as! ADRandomCell
                if let ad = video.recAd {
                    cell.setAdModel(model: ad)
                }
                return cell
            }
            if video.is_long == 0 {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShortVideoCell.cellId, for: indexPath) as! ShortVideoCell
                if cateModels.count > indexPath.item {
                    let model = cateModels[indexPath.item]
                    cell.setModel(model: model,.itemSizeDouble)
                    cell.avataClickHandler = { [weak self] in
                        self?.goUserCenter(model.user)
                    }
                }
                return cell
            } else {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongVideoCell.cellId, for: indexPath) as! LongVideoCell
                let model = cateModels[indexPath.row]
                 cell.setModel(model,.itemSizeDouble)
                cell.avataClickHandler = { [weak self] in
                    self?.goUserCenter(model.user)
                }
                return cell
            }
        } else if segmentIndex == 2 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShortVideoCell.cellId, for: indexPath) as! ShortVideoCell
            if cateModels.count > indexPath.item {
                let model = cateModels[indexPath.item]
                cell.setModel(model: model,.itemSizeDouble)
                cell.avataClickHandler = { [weak self] in
                    self?.goUserCenter(model.user)
                }
            }
            return cell
        } else if segmentIndex == 1 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongVideoCell.cellId, for: indexPath) as! LongVideoCell
            let model = cateModels[indexPath.row]
             cell.setModel(model,.itemSizeDouble)
            cell.avataClickHandler = { [weak self] in
                self?.goUserCenter(model.user)
            }
            return cell
        }
        return UICollectionViewCell()
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        let video = self.cateModels[indexPath.item]
        if video.hotSearchs != nil && video.hotSearchs!.count > 0 {
            return
        }
        if video.recAd != nil {
            if let link = video.recAd?.link, !link.isEmpty {
                goInnerLink(link,video.recAd?.position)
            }
        } else {
            if video.is_long == 1 {
                goLongVideoDetail(video)
            } else {
                goShortVideoPlayerVC(video)
            }
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension SearchVListController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is SearchVideoApi {
            var params = [String : Any]()
            params[SearchVideoApi.kKeywords] = searchkey
            if orderKey != nil {
                params[SearchVideoApi.kOrder_key] = orderKey
            }
            if segmentIndex == 1 {
                params[SearchVideoApi.kIslong] = 1
            } else if segmentIndex == 2 {
                params[SearchVideoApi.kIslong] = 0
            }
            return params
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        endRefreshing()
        if manager is SearchVideoApi {
            if let videoList = manager.fetchJSONData(VideoReformer()) as? [VideoNew] {
                succeedRequest(videoList)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        endRefreshing()
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        failedRequest(manager)
    }
}

// MARK: - Layout
private extension SearchVListController {
    
    func layoutPageSubviews() {
        layoutCollection()
    }
    func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
  
}
