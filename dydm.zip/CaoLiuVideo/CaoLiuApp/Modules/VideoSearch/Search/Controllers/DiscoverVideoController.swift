
import UIKit
import MJRefresh
import NicooNetwork
import JXPagingView

class DiscoverVideoController: CLBaseViewController {

    let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
    
    private lazy var collectionView: UICollectionView = {
        let coll = UICollectionView(frame: .zero, collectionViewLayout: layout)
        coll.backgroundColor = UIColor.clear
        coll.dataSource = self
        coll.delegate = self
        coll.register(ShortVideoCell.classForCoder(), forCellWithReuseIdentifier: ShortVideoCell.cellId)
        coll.register(SearchLongVideoCell.classForCoder(), forCellWithReuseIdentifier: SearchLongVideoCell.cellId)
        coll.register(SegmentItemView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: SegmentItemView.identifier)
        coll.register(SegmentItemView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: SegmentItemView.identifier)
        coll.register(SearchNoDataHeader.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: SearchNoDataHeader.reuseId)
        coll.mj_footer = loadMoreView
        return coll
    }()
    private lazy var loadMoreView: MJRefreshAutoNormalFooter = {
         weak var weakSelf = self
        let loadMore = MJRefreshAutoNormalFooter.init(refreshingBlock: {
            weakSelf?.loaaNextPage()
        })
        loadMore?.setTitle("", for: .idle)
        loadMore?.setTitle("已經到底了", for: .noMoreData)
        loadMore?.isHidden = true
        return loadMore!
    }()
    
    private lazy var searchVideoApi: SearchVideoApi = {
       let api = SearchVideoApi()
       api.paramSource = self
       api.delegate = self
       return api
    }()
    
    private lazy var videoListApi: SearchHotVideoApi = {
       let api = SearchHotVideoApi()
       api.paramSource = self
       api.delegate = self
       return api
    }()
    var listViewDidScrollCallback: ((UIScrollView) -> ())?
    var searchKey: String?
    
    var models: [VideoNew] = [VideoNew]()
    
    var isRecommend: Bool = false
    var notResult: Bool = false
    var isMainItem: Bool = false
    var isLong: Bool = false
    var viewModel: VideoViewModel = VideoViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(collectionView)
        layoutPageSubViews()
        
        loadData()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        collectionView.frame = view.bounds
    }
    func loadData() {
        notResult = false
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        NicooErrorView.removeErrorMeesageFrom(view)
        if isRecommend {
            let _ = videoListApi.loadData()
        } else {
           let _ = searchVideoApi.loadData()
        }
    }
    func loaaNextPage() {
        let _ = searchVideoApi.loadNextPage()
    }
    func endRefreshing() {
        collectionView.mj_footer.endRefreshing()
        XSProgressHUD.hide(for: view, animated: true)
    }
    func loadReCommentVideoData() {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ =  videoListApi.loadData()
    }
    private func goUserCenter(_ user: CLUserInfo?) {
        let userCenter = UserMCenterController()
        userCenter.userCode = user?.code
        navigationController?.pushViewController(userCenter, animated: true)
    }
}

extension DiscoverVideoController: JXPagingViewListViewDelegate {
    func listView() -> UIView {
        return self.view
    }

    func listScrollView() -> UIScrollView {
        return collectionView
    }

    func listViewDidScrollCallback(callback: @escaping (UIScrollView) -> ()) {
        listViewDidScrollCallback = callback
    }
}

// MARK: - UIScrollViewDelegate
extension DiscoverVideoController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        listViewDidScrollCallback?(scrollView)
    }
}

// MARK: - UICollectionViewDataSource && UICollectionViewDelegate
extension DiscoverVideoController: UICollectionViewDataSource, UICollectionViewDelegate {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return models.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if isLong {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SearchLongVideoCell.cellId, for: indexPath) as! SearchLongVideoCell
            let model = models[indexPath.row]
            cell.setModel(model)
            cell.avataClickHandler = { [weak self] in
                self?.goUserCenter(model.user)
            }
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShortVideoCell.cellId, for: indexPath) as! ShortVideoCell
            let model = models[indexPath.row]
            cell.setModel(model: model)
            cell.avataClickHandler = { [weak self] in
                self?.goUserCenter(model.user)
            }
            return cell
        }
    }
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if isMainItem {
            let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: SegmentItemView.identifier, for: indexPath) as! SegmentItemView
            header.backgroundColor = ConstValue.kVcViewColor
            header.setTitles(["影片","小视频"])
            header.segAction = { [weak self] index in
                self?.isLong = index == 0
                self?.loadData()
            }
            return header
        }
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: SearchNoDataHeader.reuseId, for: indexPath) as! SearchNoDataHeader
        header.label.text = notResult ? "未搜索到任何相關內容" : ""
        return header
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if isLong {
            goLongVideoDetail(models[indexPath.item])
        } else {
            goShortVideoPlayerVC(models[indexPath.item])
        }
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension DiscoverVideoController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return isLong ? SearchLongVideoCell.itemSize : ShortVideoCell.itemSizeThird
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return isLong ? 10.0 : 8.0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return isLong ? 0 : 4.0
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if isMainItem {
            return CGSize(width: screenWidth, height: 50)
        }
        if notResult {
           return SearchNoDataHeader.headerSize
        }
        return CGSize.zero
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension DiscoverVideoController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is SearchVideoApi {
           return  [SearchVideoApi.kKeywords : searchKey ?? "", SearchVideoApi.kIslong: isLong ? 1 : 0]
        }
        if manager is SearchHotVideoApi {
            return [SearchHotVideoApi.kIslong: isLong ? 1 : 0]
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: true)
        if manager is SearchVideoApi {
            if let list = manager.fetchJSONData(SearchReformer()) as? [VideoNew] {
                if searchVideoApi.pageNumber == 1 {
                    models = list
                    if list.count == 0 {
                        notResult = true
                        loadReCommentVideoData()
                    }
                } else {
                    models.append(contentsOf: list)
                }
                loadMoreView.isHidden = list.count == 0
                endRefreshing()
                collectionView.reloadData()
            }
        }
        
        if manager is SearchHotVideoApi {
            if let model = manager.fetchJSONData(SearchReformer()) as? [VideoNew] {
                models = model
                loadMoreView.isHidden = true
                endRefreshing()
                collectionView.reloadData()
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: true)
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        if manager is SearchVideoApi {
            NicooErrorView.showErrorMessage(.noNetwork, on: view) {
                self.loadData()
            }
        }
    }
}

// MARK: - Layout
extension DiscoverVideoController {
    private func layoutPageSubViews() {
        layoutCollectionView()
    }
    
    private func layoutCollectionView() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.bottom.trailing.equalToSuperview()
            make.top.equalToSuperview()
        }
    }
}
