
import UIKit
import NicooNetwork
import MJRefresh
import JXSegmentedView

extension SearchAnchorController: JXSegmentedListContainerViewListDelegate {
    func listView() -> UIView {
        return self.view
    }
}

class SearchAnchorController: CLBaseViewController {
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.titleLabel.text = nil
        bar.backgroundColor = UIColor.clear
        bar.titleLabel.text = "更多主播"
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    private lazy var searchBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(getImage("communitySeachIcon"), for: .normal)
        button.addTarget(self, action: #selector(searchBtnClick(_:)), for: .touchUpInside)
        return button
    }()
    private let layoutF : UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: screenWidth, height: 60)
        layout.minimumLineSpacing = 15
        layout.sectionInset = UIEdgeInsets(top: 15 , left: 0, bottom: 10, right: 0)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layoutF)
        collection.delegate = self
        collection.dataSource = self
        collection.showsVerticalScrollIndicator = true
        collection.backgroundColor = UIColor.clear
        collection.register(SearchUserListCell.classForCoder(), forCellWithReuseIdentifier: SearchUserListCell.cellId)
        collection.register(UINib(nibName: ModulesHeaderView.reuseId, bundle: Bundle.main), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: ModulesHeaderView.reuseId)
        collection.mj_header = refreshView
        collection.mj_footer = loadMoreView
        return collection
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
        loadmore?.setTitle("", for: .idle)
        loadmore?.setTitle("已经到底了", for: .noMoreData)
        loadmore?.stateLabel.font = ConstValue.kRefreshLableFont
        return loadmore!
    }()
    
    lazy private var refreshView: MJRefreshNormalHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshNormalHeader(refreshingBlock: {
            weakSelf?.loadData()
        })
        mjRefreshHeader?.activityIndicatorViewStyle = .white
        mjRefreshHeader?.arrowView.image = ConstValue.refreshImg
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    private lazy var searchUserApi: SearchUserApi = {
        let api = SearchUserApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var groupUserApi: UserListApi = {
        let api = UserListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    var userGroups = [UserGroupModel]()
    var userModels = [CLUserInfo]()
    
    var searchKey: String?
    var groupId: Int?
    var groupTitle: String?
    
    let viewModel = UserInfoViewModel()
    
    /// 0: segmentPage 1: 分组页面 2:单页面
    var pageType: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        navBar.navBarView.addSubview(searchBtn)
        view.addSubview(navBar)
        view.addSubview(collectionView)
        layoutPageSubViews()
        if pageType == 2 {
            navBar.titleLabel.text = groupTitle
        }
        loadData()
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if pageType == 0 {
            collectionView.frame = view.bounds
            navBar.isHidden = true
        }
    }
    @objc func searchBtnClick(_ sender: UIButton) {
        if let vcs = navigationController?.viewControllers {
            let allPlayVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: SearchMainController.self)
            }
            if allPlayVcs.count > 0 {
                let vc = allPlayVcs[0] as! SearchMainController
                navigationController?.popToViewController(vc, animated: true)
            } else {
                let vc = SearchMainController()
                navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        if pageType == 0 || pageType == 2 {
            searchUserApi.isSearch = pageType == 0
            let _ = searchUserApi.loadData()
        } else if pageType == 1 {
            let _ = groupUserApi.loadData()
        }
    }
    func loadNextPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        if pageType == 0 || pageType == 2 {
            searchUserApi.isSearch = pageType == 0
            let _ = searchUserApi.loadNextPage()
        } else if pageType == 1 {
            let _ = groupUserApi.loadNextPage()
        }
    }
    func endrefreshing() {
        loadMoreView.endRefreshing()
        refreshView.endRefreshing()
    }
}

// MARK: - UICollectionViewDataSource && UICollectionViewDelegate
extension SearchAnchorController: UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if pageType == 1 {
            return CGSize(width: screenWidth, height: 50)
        }
        return .zero
    }
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: ModulesHeaderView.reuseId, for: indexPath) as! ModulesHeaderView
        if pageType == 1 {
            let group = userGroups[indexPath.section]
            header.titleLab.text = group.title
            header.moreActionHandler = { [weak self] in
                guard let strongSelf = self else { return }
                let vc = SearchAnchorController()
                vc.pageType = 2
                vc.groupId = group.id
                vc.groupTitle = group.title
                strongSelf.navigationController?.pushViewController(vc, animated: true)
            }
        }
        return header
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        if pageType == 1 {
            return userGroups.count
        }
        return 1
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if pageType == 1 {
            if let members = userGroups[section].member {
                return members.count
            } else {
                return 0
            }
        }
        return userModels.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SearchUserListCell.cellId, for: indexPath) as! SearchUserListCell
        var model = CLUserInfo()
        if pageType == 1 {
            if let members = userGroups[indexPath.section].member, members.count > indexPath.item {
                model = members[indexPath.item]
            }
        } else {
             model = userModels[indexPath.item]
        }
        cell.setModel(model)
        cell.buttonClick = { [weak self] in
            self?.viewModel.loadAddFollowApi([UserAddFollowApi.kUserId: model.code ?? ""])
            model.is_attention = 1
            collectionView.reloadItems(at: [indexPath])
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        var model = CLUserInfo()
        if pageType == 1 {
            if let members = userGroups[indexPath.section].member, members.count > indexPath.item {
                model = members[indexPath.item]
            }
        } else {
            model = userModels[indexPath.item]
        }
        let vc = UserMCenterController()
        vc.userCode = model.code
        navigationController?.pushViewController(vc, animated: true)
    }
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension SearchAnchorController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is SearchUserApi {
            if pageType == 0 {
                return  [SearchUserApi.kKeywords : searchKey ?? ""]
            } else if pageType == 2 {
                return [SearchUserApi.kGroup_id : groupId ?? 0]
            }
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        endrefreshing()
        if manager is SearchUserApi {
            if let models = manager.fetchJSONData(SearchReformer()) as? [CLUserInfo] {
                if searchUserApi.pageNumber == 1 {
                    userModels = models
                    if userModels.count == 0 {
                        NicooErrorView.showErrorMessage(pageType == 0 ? "未搜索到 “\(searchKey ?? "")“ 相关的主播" : "没有更多了～", on: view, customerTopMargin: safeAreaTopHeight + 40) {
                            self.loadData()
                        }
                    }
                } else {
                    userModels.append(contentsOf: models)
                }
                loadMoreView.isHidden = models.count == 0
                collectionView.reloadData()
            }
        }
        if manager is UserListApi {
            if let models = manager.fetchJSONData(SearchReformer()) as? [UserGroupModel] {
                if groupUserApi.pageNumber == 1 {
                    userGroups = models
                    if userGroups.count == 0 {
                        NicooErrorView.showErrorMessage("没有更多数据了～", on: view, customerTopMargin: safeAreaTopHeight + 40) {
                            self.loadData()
                        }
                    }
                } else {
                    userGroups.append(contentsOf: models)
                }
                loadMoreView.isHidden = models.count == 0
                collectionView.reloadData()
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        endrefreshing()
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        if manager is SearchUserApi {
            NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: safeAreaTopHeight + 40) {
                self.loadData()
            }
        }
    }
}

// MARK: - Layout
extension SearchAnchorController {
    private func layoutPageSubViews() {
        layoutNavbar()
        layoutCollectionView()
    }
    private func layoutNavbar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
        searchBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-18)
            make.centerY.equalToSuperview()
            make.width.equalTo(18)
            make.height.equalTo(18)
        }
    }
    private func layoutCollectionView() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.bottom.trailing.equalToSuperview()
            if pageType == 0 {
                make.top.equalToSuperview()
            } else {
                make.top.equalTo(navBar.snp.bottom)
            }
        }
    }
}

// MARK: - CLNavigationBarDelegate
extension SearchAnchorController:  CLNavigationBarDelegate  {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}
