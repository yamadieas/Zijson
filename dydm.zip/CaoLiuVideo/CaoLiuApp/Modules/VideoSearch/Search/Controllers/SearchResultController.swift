
import UIKit
import JXPagingView
import JXSegmentedView

class SearchResultController: CLBaseViewController {
    
    private var searchView: SearchHeader = {
        guard let view = Bundle.main.loadNibNamed("SearchHeader", owner: nil, options: nil)?[0] as? SearchHeader else { return SearchHeader() }
        view.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: statusBarHeight + 44)
        view.cancleBtn.setImage(getImage("selevideo"), for: .normal)
        view.rightBtnWidth.constant = 70
        view.cancleBtn.borderRadius = 17
        view.cancleBtn.backgroundColor = ConstValue.kCoverBgColor
        view.cancleBtn.setTitle(" 筛选", for: .normal)
        view.cancleBtn.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        return view
    }()
    let dataSource = JXSegmentedTitleDataSource()
    let segmentedView = JXSegmentedView()
    lazy var listContainerView: JXSegmentedListContainerView! = {
        return JXSegmentedListContainerView(dataSource: self)
    }()
    let vc1 = SearchResultSegController()
    let vc2 = SearchAnchorController()
    var searchkey: String?
    var isHot: Bool = false
    var beginSearch:(()->Void)?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(searchView)
        layoutPageSubViews()
        searchView.searchTf.text = searchkey
        searchView.searchTf.delegate = self
        searchView.cancleAction = { [weak self] in
            self?.navigationController?.popViewController(animated: false)
        }
        searchView.searchAction = { [weak self] in
            let vc = TypesCategrayController()
            vc.InVipPart = false
            self?.navigationController?.pushViewController(vc, animated: true)
        }
        
        let titles = ["视频", "主播"]
        //dataSource一定要通过属性强持有！！！！！！！！！
        dataSource.isItemSpacingAverageEnabled = false
        dataSource.titles = titles
        dataSource.titleNormalColor = .lightGray
        dataSource.titleSelectedColor = UIColor.white
        dataSource.itemSpacing = 25
        dataSource.titleNormalFont = UIFont.systemFont(ofSize: 16)
        dataSource.titleSelectedFont = UIFont.boldSystemFont(ofSize: 20)

        let indicator = JXSegmentedIndicatorLineView()
        indicator.indicatorWidth = JXSegmentedViewAutomaticDimension
        indicator.isScrollEnabled = true
        indicator.indicatorColor = .white
        indicator.indicatorWidth = 12

        segmentedView.frame = CGRect(x: 0, y: safeAreaTopHeight + 10 , width: screenWidth, height: 45)
        segmentedView.dataSource = dataSource
        segmentedView.indicators = [indicator]
        segmentedView.defaultSelectedIndex = 0
    
        view.addSubview(segmentedView)

        segmentedView.listContainer = listContainerView
        view.addSubview(listContainerView)
        
        if let nav = self.navigationController {
            listContainerView.scrollView.panGestureRecognizer.require(toFail: nav.interactivePopGestureRecognizer!)
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        listContainerView.frame = CGRect(x: 0, y: safeAreaTopHeight + 55, width: view.bounds.width, height: view.bounds.height - safeAreaTopHeight - 55)
    }
    
}

extension SearchResultController: JXSegmentedListContainerViewDataSource {
    func numberOfLists(in listContainerView: JXSegmentedListContainerView) -> Int {
        if let titleDataSource = segmentedView.dataSource as? JXSegmentedBaseDataSource {
            return titleDataSource.dataSource.count
        }
        return 0
    }

    func listContainerView(_ listContainerView: JXSegmentedListContainerView, initListAt index: Int) -> JXSegmentedListContainerViewListDelegate {
        if index == 0 {
            vc1.titles = ["全部","只看长视频","只看短视频"]
            vc1.searchkey = searchkey
            vc1.isHot = isHot
            vc1.keyChangeHandler = { [weak self] key in
                self?.searchkey = key
                self?.vc2.searchKey = key
                self?.searchView.searchTf.text = key
            }
            return vc1
        } else {
            let vc2 = SearchAnchorController()
            vc2.searchKey = searchkey
            return vc2
        }
    }
}

// MARK: - UITextFieldDelegate
extension SearchResultController: UITextFieldDelegate {
    func textFieldDidBeginEditing(_ textField: UITextField) {
        beginSearch?()
    }
}

// MARK: - Layout
extension SearchResultController {
    
    private func layoutPageSubViews() {
        layoutDiscoverSearchView()
    }
    
    private func layoutDiscoverSearchView() {
        searchView.snp.makeConstraints { (make) in
            make.top.leading.trailing.equalToSuperview()
            make.height.equalTo(statusBarHeight + 44)
        }
    }
    
}
