

import UIKit

class SystemAlert: UIView {

    @IBOutlet weak var contenView: UIView!
    @IBOutlet weak var titleLable: UILabel!
    @IBOutlet weak var titleContenView: UIView!
    @IBOutlet weak var topImage: UIImageView!
    @IBOutlet weak var commitBtn: UIButton!
    @IBOutlet weak var textInfoView: UITextView!
    @IBOutlet weak var iconApp: UIImageView!
    @IBOutlet weak var offcialUrlLabel: UILabel!
    
    var messages = ""
    var currentIndex: Int = 0
    var closeActionHandler:(() -> Void)?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        textInfoView.delegate = self
        contenView.backgroundColor = .white
        textInfoView.textColor = .darkText
    }
    
    func setMessages(_ messages: String) {
        self.messages = messages
        if messages.count > 0 {
            textInfoView.attributedText = TextSpaceManager.configColorString(allString: messages, attribStr: messages, .darkText, UIFont.systemFont(ofSize: 14), 6)
            textInfoView.setContentOffset(CGPoint.zero, animated: false)
        }
    }
    
    @IBAction func commitBtnClick(_ sender: UIButton) {
        closeActionHandler?()
    }
    
    private func goGroup() {
        if let url = URL(string: AppInfo.share().appInfo?.potato_invite_link ?? "") {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url, options: [:],
                                          completionHandler: { (success) in
                })
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
}

extension UpdateAlert:  UITextViewDelegate {
    
    func textView(_ textView: UITextView, shouldInteractWith URL: URL, in characterRange: NSRange) -> Bool {
        return true
    }
    
}
