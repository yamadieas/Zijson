
import UIKit
import Photos

/// 视频选择列表
class ThumbnailViewController: CLBaseViewController {
    
    @IBOutlet weak var alCollectionView: ALCollectionView!
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.titleLabel.text = "视频选择"
        bar.titleLabel.textColor = UIColor.white
        bar.backgroundColor = UIColor.clear
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    var islong: Int = 0
    var videoChoseHandler:((_ asset: PHAsset) -> Void)?
    var cancleChoseHandler: (() -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        alCollectionView.isLong = islong
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(navBar)
        layoutPageSubviews()
       
        self.initCollectionView()
    }
    
    private func initCollectionView() {
        alCollectionView.didOverScrollTop = { [weak self] in
            self?.close()
        }
        alCollectionView.didSelectItemAt = { [weak self] (collectionView: UICollectionView, indexPath: IndexPath) in
            if let cell: ALCollectionViewCell = collectionView.cellForItem(at: indexPath) as? ALCollectionViewCell {
                if let asset: PHAsset = cell.asset {
                    if UserModel.share().isPushLF {
                        self?.goBack(asset: asset)
                    } else {
                        //self?.libraryVideoEditor(asset: asset)
                        let coverVC = VideoCoverChoseController()
                        coverVC.asset = asset
                        coverVC.islong = self?.islong ?? 0
                        self?.navigationController?.pushViewController(coverVC, animated: true)
                    }
//                    if self?.islong == 1 {
//                        let coverVC = VideoCoverChoseController()
//                        coverVC.asset = asset
//                        coverVC.islong = self?.islong ?? 0
//                        self?.navigationController?.pushViewController(coverVC, animated: true)
//                    } else {
//                        
//                    }
                }
            }
        }
        alCollectionView.initList(type: .video) { (isAuthorization: Bool) in
            DLog("isAuthorization: \(isAuthorization)")
        }
    }
    /// 选择视频编辑
    private func libraryVideoEditor(asset: PHAsset) {
        switch asset.mediaType {
        case .video:
            let storyboard: UIStoryboard = UIStoryboard(name: "VT", bundle: nil)
            let vc: VTViewController = storyboard.instantiateViewController(withIdentifier: "VT") as! VTViewController
            vc.asset = asset
            vc.sourceType = .Source_Library
            vc.applyCheckDoneActionHandler = { [weak self] image in
                guard let strongself = self else {
                    return
                }
            }
            vc.islong = self.islong
            //vc.camareVideoPath = FileManager.videoExportURL
            self.navigationController?.pushViewController(vc, animated: false)
        default:
            break
        }
    }
    private func goBack(asset: PHAsset) {
        self.dismiss(animated: true) {
            DLog("allready dissMiss")
            self.videoChoseHandler?(asset)
        }
    }
    
    private func close() {
        dismiss(animated: true) {
        }
    }
    
}

// MARK: - QHNavigationBarDelegate
extension ThumbnailViewController:  CLNavigationBarDelegate  {
    
    func backAction() {
        dismiss(animated: true) {
            self.cancleChoseHandler?()
        }
    }
}

// MARK: - Layout
private extension ThumbnailViewController {
    
    func layoutPageSubviews() {
        layoutNavBar()
        layoutCollection()
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    func layoutCollection() {
        alCollectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom)
            } else {
                make.bottom.equalToSuperview()
            }
        }
    }
    
}
