
import UIKit
import AVKit
import Photos

/// 视频封面图片选择
class VideoCoverChoseController: UIViewController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.titleLabel.text = "选择封面"
        bar.titleLabel.textAlignment = .left
        bar.titleLabel.font = UIFont.systemFont(ofSize: 15)
        bar.titleLabel.textColor = UIColor.white
        bar.backgroundColor = UIColor.clear
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    private lazy var photoBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("本地照片", for: .normal)
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.addTarget(self, action: #selector(libraryChoseAction(_:)), for: .touchUpInside)
        return button
    }()
    private lazy var doneBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("下一步", for: .normal)
        button.backgroundColor = ConstValue.kStypeColor
        button.borderRadius = 6
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.addTarget(self, action: #selector(doneAction(_:)), for: .touchUpInside)
        button.isEnabled = false
        return button
    }()
    private let customLayout: CustomFlowPhotoLayout = {
        let layout = CustomFlowPhotoLayout()
        layout.itemSize = CGSize(width: 85, height: 120)
        // layout.
        return layout
    }()
    private let videoCover: UIImageView = {
        let image = UIImageView()
        image.image = UIImage(named: "placeholderV")
        image.contentMode = .scaleAspectFit
        return image
    }()
    private let coverView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(white: 0.0, alpha: 0.9)
        return view
    }()
    lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: 120), collectionViewLayout: customLayout)
        collection.backgroundColor = UIColor.clear
        collection.showsHorizontalScrollIndicator = true
        collection.delegate = self
        collection.dataSource = self
        collection.register(VideoCoverChoseCell.classForCoder(), forCellWithReuseIdentifier: VideoCoverChoseCell.cellId)
        return collection
    }()
    var videoPathUrl: URL!
    var pictures = [UIImage]()
    var duration: Int = 0
    /// 当前选中的滤镜index
    var currentSelectedIndex: Int = 0
    
    var fakeButton: UIButton?
    
    var islong: Int = 0
    
    var asset: PHAsset!
    //var filterChoseHandler:((_ filter: FilterModel) -> Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        XSProgressHUD.showProgress(msg: "图片获取中...", onView: view, animated: false)
        self.asset.toAVAsset { [weak self] (asset) in
            guard let stSelf = self else { return }
            DispatchQueue.main.async {
                let ast = asset as? AVURLAsset
                if let asUrl = ast?.url {
                    print("ast.url = \(asUrl.absoluteString)")
                    let timeName = "\(Date.getTimeNameStrWithDate(date: Date())).mp4"
                    let fileUrl = FileManager.getUploadDirectoryFilePathURL(timeName)
                    try? Data.init(contentsOf: asUrl).write(to: fileUrl, options: .atomic)
                    stSelf.videoPathUrl = fileUrl
                    stSelf.setUpViews()
                    stSelf.getImageLastImage()
                }
            }
        }
    }
    
    private func setUpViews() {
        view.addSubview(navBar)
        navBar.navBarView.addSubview(photoBtn)
        navBar.navBarView.addSubview(doneBtn)
        layoutBaseView()
        view.addSubview(videoCover)
        view.addSubview(coverView)
        view.addSubview(collectionView)
        layoutPageSubviews()
    }
    
    /// 截取视频 图片 每5秒抽一针
    private func getImageLastImage() {
        guard let url = self.videoPathUrl else {
            XSAlert.show(type: .error, text: "封面获取失败！")
            return
        }
        //1. 获取视频时长
        let urlAsset = AVURLAsset(url: url)
        let seconds = urlAsset.duration.seconds
        duration = Int(seconds)
        //2. 截图配置
        let generator = AVAssetImageGenerator(asset: urlAsset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        generator.requestedTimeToleranceBefore = .zero
        generator.requestedTimeToleranceAfter = .zero
        
        //3. 分段截图时间数组
        var times: [NSValue] = []
        if Int(seconds) < 2 {
            XSProgressHUD.hide(for: view, animated: false)
            XSAlert.show(type: .text, text: "视频太短或格式出错！")
            return
        }
        for i in 1..<Int(seconds) {
            let timeM = CMTimeMake(value: Int64(i), timescale: 1)
            if Int(timeM.seconds)%(seconds > 300 ? 40 : 10) == 1 { // 视频时长大余2分钟 每10秒取一帧。 小于2分钟 每5秒取一帧
                let timeV = NSValue(time: timeM)
                times.append(timeV)
            }
        }
        DLog("times: \(times), count: \(times.count)")
        //4. 开始截图
        generator.generateCGImagesAsynchronously(forTimes: times) { [weak self]
            (requestedTime, cgimage, actualTime, result, error) in
            guard let strongSelf = self else { return }
            switch result {
            case .cancelled, .failed: break
            case .succeeded:
                guard let image = cgimage else {
                    return
                }
                let displayImage = UIImage(cgImage: image)
                if let dataImage = displayImage.jpegData(compressionQuality: 1.0) { // 图片压缩一次，否则原图5 -600 kb
                    DLog("displayImage.size = \((displayImage.pngData() ?? Data()).count/1024)KB  dataImage.size = \(dataImage.count/1024)KB")
                    if let imageSmall = UIImage(data: dataImage) {
                        strongSelf.pictures.append(imageSmall)
                    }
                }
                DispatchQueue.main.async {
                    DLog("strongSelf.pictures.count = \(strongSelf.pictures.count) times.count = \(times.count)")
                    if strongSelf.pictures.count == times.count {
                        XSProgressHUD.hide(for: strongSelf.view, animated: false)
                        strongSelf.doneBtn.isEnabled = true
                        strongSelf.collectionView.reloadData()
                    }
                }
            @unknown default:
                break
            }
        }
    }
    
}

// MARK: - User - Actions
private extension VideoCoverChoseController {
    
    @objc func libraryChoseAction(_ sender: UIButton) {
        _ = self.jh_presentPhotoVC(1 , completeHandler: {  [weak self]  items in
            guard let strongSelf = self else { return }
            if items.count == 0 { return }
            for item in items {
                let _ = item.originalImage({ (originImage) in
                    strongSelf.videoCover.image = originImage
                })
            }
        })
    }
    func saveImage(currentImage: UIImage, persent: CGFloat) {
        if let imageData = currentImage.jpegData(compressionQuality: persent) as NSData? {
            let fullPath = FileManager.getUploadDirectoryFilePathURL("\(videoPathUrl.path.md5() ?? "").png")
            imageData.write(toFile: fullPath.path, atomically: true)
            print("fullPath=\(fullPath)")
        }
    }
    @objc func doneAction(_ sender: UIButton) {
        // 点击完成，先删除录制的临时 视频文件
        //FilesManager.deleteAllRecordFile()
        // 拿到URL
        DLog("拿到视频 --> \(videoPathUrl!) \n 拿到视频封面 --> \(videoCover.image ?? UIImage())")
        fileSizeWithPath(videoPathUrl!)
        let coverLocalPath = FileManager.getUploadDirectoryFilePathURL("\(videoPathUrl.path.md5() ?? "").png")
        if let image = videoCover.image {
            saveImage(currentImage: image, persent: 1.0)
        }
        let pushVc = PushVideoController()
        pushVc.videoImage = videoCover.image
        pushVc.videoDuration = duration
        pushVc.videoLocalPath = videoPathUrl
        pushVc.islong = self.islong
        pushVc.coverLocalpath = coverLocalPath
        navigationController?.pushViewController(pushVc, animated: true)
    }
    
    // 计算文件大小
    func fileSizeWithPath(_ url: URL) {
        DLog("outputPath = \(url.absoluteString)")
        if let dataFile = try? Data(contentsOf: url)  {
            let size = Float(dataFile.count/1024/1024)
            DLog("fileSize = \(size)M")
        }
    }
}

// MARK: - QHNavigationBarDelegate
extension VideoCoverChoseController:  CLNavigationBarDelegate  {
    
    func backAction() {
       navigationController?.popViewController(animated: true)
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension VideoCoverChoseController: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return pictures.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: VideoCoverChoseCell.cellId, for: indexPath) as! VideoCoverChoseCell
        cell.imageCover.image = pictures[indexPath.row]
        videoCover.image = pictures[currentSelectedIndex]
        cell.fakeButton.isSelected = indexPath.row == currentSelectedIndex
        if indexPath.row == currentSelectedIndex {
            fakeButton = cell.fakeButton
        }
        cell.coverClickHandler = { [weak self] in
            guard let strongSelf = self else { return }
            if indexPath.row != strongSelf.currentSelectedIndex {
                strongSelf.fakeButton?.isSelected = false
                cell.fakeButton.isSelected = true
                strongSelf.currentSelectedIndex = indexPath.row
                collectionView.reloadData()
                strongSelf.videoCover.image = strongSelf.pictures[indexPath.row]
            }
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
    }
    
}

// MARK: - Layout
private extension VideoCoverChoseController {
    
    func layoutPageSubviews() {
        layoutCoverView()
        layoutCollection()
        layoutVideoCover()
    }
    
    func layoutBaseView() {
         layoutNavBar()
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
        layoutDoneBtn()
    }
    
    func layoutDoneBtn() {
        doneBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-12)
            make.centerY.equalToSuperview()
            make.height.equalTo(30)
            make.width.equalTo(60)
        }
        photoBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(doneBtn.snp.leading).offset(-15)
            make.centerY.equalToSuperview()
            make.height.equalTo(30)
        }
    }
    
    func layoutVideoCover() {
        videoCover.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(navBar.snp.bottom).offset(5)
            make.bottom.equalTo(coverView.snp.top)
        }
    }
    
    func layoutCoverView() {
        coverView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview()
            make.height.equalTo(180)
        }
    }
    
    func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(140)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-5)
            } else {
                make.bottom.equalToSuperview().offset(-5)
            }
        }
    }
}
