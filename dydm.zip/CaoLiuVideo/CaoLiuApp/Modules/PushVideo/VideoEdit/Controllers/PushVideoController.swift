

import UIKit
import AVKit
import Photos
import NicooNetwork

/// 视频上传确认页面
class PushVideoController: UIViewController {
    

    static let kLocalTaskTitles = "localTaskTitles"
    static let kLocalTaskTalkTitle = "kLocalTaskTalkTitle"

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.titleLabel.text = "发布视频"
        bar.titleLabel.textColor = UIColor.white
        bar.backgroundColor = UIColor.clear
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    lazy var textView: UITextView = {
        let textView = UITextView()
        textView.textColor = UIColor.init(white: 0.9, alpha: 1.0)
        textView.font = UIFont.systemFont(ofSize: 13)
        textView.backgroundColor = UIColor.clear
        textView.delegate = self
        return textView
    }()
    let placeHodlerLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor(r: 59, g: 57, b: 73)
        lable.font = UIFont.systemFont(ofSize: 14)
        lable.numberOfLines = 2
        lable.text = "写标题并使用合适的话题，能让更多人看到~"
        return lable
    }()
    let tagButton: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitleColor(ConstValue.kStypeColor, for: .normal)
        btn.setTitle("# 话题", for: .normal)
        btn.borderRadius = 15
        btn.bordercolor = ConstValue.kAppSepLineColor
        btn.borderWidth = 1.0
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        btn.addTarget(self, action: #selector(choseCateTips), for: .touchUpInside)
        return btn
    }()
    lazy var videoCoverImg: UIImageView = {
        let v = UIImageView()
        v.image = videoImage
        v.isUserInteractionEnabled = true
        v.backgroundColor = .black
        v.contentMode = .scaleAspectFit
        v.borderRadius = 3
        return v
    }()
    lazy var videoBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setImage(getImage("pauseIcon"), for: .normal)
        button.addTarget(self, action: #selector(videoWatch), for: .touchUpInside)
        return button
    }()
    lazy var choseCoverBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor(white: 0.2, alpha: 0.7)
        button.setTitle("修改封面", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        button.layer.cornerRadius = 15
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(rechoseCover), for: .touchUpInside)
        return button
    }()
    let line: UIView = {
        let v = UIView()
        v.backgroundColor = ConstValue.kCoverBgColor
        return v
    }()
    let coinsTitle: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.boldSystemFont(ofSize: 14)
        lab.textColor = .white
        lab.attributedText = TextSpaceManager.configColorString(allString: "解锁价格 (0或不填视为不收费)", attribStr: "(0或不填视为不收费)", .lightGray, UIFont.systemFont(ofSize: 13), 0)
        return lab
    }()
    let coinInputView: UIView = {
        let v = UIView()
        v.borderRadius = 6
        v.bordercolor = ConstValue.kStypeColor
        v.borderWidth = 1.0
        return v
    }()
    private lazy var coinInputTf: UITextField = {
        let tf = UITextField()
        tf.textColor = UIColor.white
        tf.borderStyle = .none
        tf.font = UIFont.boldSystemFont(ofSize: 15)
        tf.placeholder = "设置视频解锁价格(最多\(UserModel.share().uploadDiamond_limit ?? 0)个)"
        tf.setPlaceholderTextColor(placeholderText: "设置视频解锁价格(最多\(UserModel.share().uploadDiamond_limit ?? 0)个)", color: UIColor(white: 0.8, alpha: 0.6))
        tf.keyboardType = .numberPad
        return tf
    }()
    let progressCover: UILabel = {
        let label = UILabel()
        label.textColor = ConstValue.kStypeColor
        label.font = UIFont.systemFont(ofSize: 12)
        label.backgroundColor = UIColor(white: 0.0, alpha: 0.5)
        label.textAlignment = .center
        label.numberOfLines = 2
        return label
    }()
    lazy var saveBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("保存草稿", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = UIColor(red: 56/255.0, green: 59/255.0, blue: 71/255.0, alpha: 0.99)
        button.addTarget(self, action: #selector(saveTask), for: .touchUpInside)
        button.layer.cornerRadius = 22.5
        button.layer.masksToBounds = true
        return button
    }()
    lazy var commitBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("发布作品", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        button.setTitleColor(UIColor.white, for: .normal)
        button.backgroundColor = ConstValue.kStypeColor
        button.addTarget(self, action: #selector(commitPushVideo(_:)), for: .touchUpInside)
        button.layer.cornerRadius = 22.5
        button.layer.masksToBounds = true
        return button
    }()
    private let layout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = 10
        layout.scrollDirection = .horizontal
        layout.sectionInset = UIEdgeInsets(top: 10 ,left: 10, bottom: 10, right: 0)
        return layout
    }()
    lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.clear
        collection.isScrollEnabled = false
        collection.register(PushKeysCell.classForCoder(), forCellWithReuseIdentifier: PushKeysCell.cellId)
        return collection
    }()
    private lazy var uploadCountApi: UserUploadCountApi = {
        let api = UserUploadCountApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    
    var pushTask = PushPresenter()
    
    var videoImage: UIImage?
    var coverLocalpath: URL?
    var videoLocalPath: URL!
    var videoDuration: Int = 0
    var tagModels = [SearchHotTips]()
    /// 是否是上传已存在任务的视频
    var isUploadExit = false
    var isChangeparams = false
    var islong: Int = 0
    
    deinit {
        DLog("PushVideoController -- release")
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        navBar.titleLabel.text = islong == 1 ? "发布长视频" : "发布短视频"
        setExitTaskData()
        setUpUI()
    }
    
    private func setUpUI() {
        view.addSubview(navBar)
        view.addSubview(videoCoverImg)
        view.addSubview(videoBtn)
        view.addSubview(choseCoverBtn)
        view.addSubview(progressCover)
        view.addSubview(textView)
        view.addSubview(placeHodlerLable)
        view.addSubview(tagButton)
        view.addSubview(collectionView)
        view.addSubview(line)
        view.addSubview(coinsTitle)
        view.addSubview(coinInputView)
        coinInputView.addSubview(coinInputTf)
        view.addSubview(saveBtn)
        view.addSubview(commitBtn)
        layoutPageSubviews()
        
    }
    
    private func setExitTaskData() {
        if isUploadExit {
            /// 参数 fu zhi
            videoImage = pushTask.pushModel.videoCover
            if let url = pushTask.pushModel.videoLacalURL {
                 videoLocalPath = url
            }
            videoDuration = pushTask.pushModel.duration ?? 0
            if let tags = pushTask.pushModel.tagsModel {
                 tagModels = tags
            }
            coverLocalpath = pushTask.pushModel.coverLocalPath
            
            if let titleStr = pushTask.pushModel.title, !titleStr.isEmpty {
                textView.text = titleStr
                placeHodlerLable.text = nil
            }
            if let coins = pushTask.pushModel.coins, coins > 0 {
                coinInputTf.text = "\(coins)"
            }
            if let islong = pushTask.pushModel.islong {
                self.islong = islong
            }
            if pushTask.videoPushStatu == .waitForUpload {
                commitBtn.setTitle("发布作品", for: .normal)
            } else {
                commitBtn.setTitle("重新发布", for: .normal)
            }
        }
    }
    
    
    private func goWorkUploadVc(_ backToRoot: Bool) {
        if let vcs = navigationController?.viewControllers {
            let allVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: UploadingWorksController.self)
            }
            if allVcs.count > 0 {
                let vc = allVcs[0] as! UploadingWorksController
                vc.backToRoot = false
                navigationController?.popToViewController(vc, animated: true)
            } else {
                let vcNew = UploadingWorksController()
                vcNew.backToRoot = backToRoot
                navigationController?.pushViewController(vcNew, animated: true)
            }
        }
    }
    
    private func closeAction() {
        self.dismiss(animated: true, completion: nil)
    }
}

// MARK: - User Actions
private extension PushVideoController {
    
    /// 预览播放
    @objc func videoWatch() {
        let playerVc = AVPlayerViewController()
        playerVc.player = AVPlayer(url: videoLocalPath!)
        playerVc.player?.play()
        playerVc.modalPresentationStyle = .fullScreen
        self.present(playerVc, animated: false, completion: nil)
    }
    /// 重选图片
    @objc func rechoseCover() {
        _ = self.jh_presentPhotoVC(1 , completeHandler: {  [weak self]  items in
            guard let strongSelf = self else { return }
            if items.count == 0 { return }
            for item in items {
                let _ = item.originalImage({ (originImage) in
                    strongSelf.videoImage = originImage
                    strongSelf.videoCoverImg.image = originImage
                    strongSelf.saveImage(currentImage: originImage, persent: 1.0)
                })
            }
        })
    }
    func saveImage(currentImage: UIImage, persent: CGFloat) {
        if let imageData = currentImage.jpegData(compressionQuality: persent) as NSData? {
            let fullPath = FileManager.getUploadDirectoryFilePathURL("\(videoLocalPath.path.md5() ?? "").png")
            FileManager.sharedInstance.remove(atPath: fullPath.path)
            
            imageData.write(toFile: fullPath.path, atomically: true)
            print("fullPath=\(fullPath)")
        }
    }
    @objc func choseCateTips() {
        let tagsVc = TipTypeChoseController()
        tagsVc.finishCallBack = { [weak self] tags in
            self?.isChangeparams = true
            self?.tagModels = tags
            self?.collectionView.reloadData()
            self?.navigationController?.popViewController(animated: true)
        }
        navigationController?.pushViewController(tagsVc, animated: true)
    }
    
    /// 存草稿
    @objc func saveTask() {
        if isUploadExit {
            if textView.text != pushTask.pushModel.title || coinInputTf.text != "\(pushTask.pushModel.coins ?? 0)"{
                isChangeparams = true
            }
            if pushTask.videoPushStatu == .waitForUpload { // 草稿再加入
                if !isChangeparams {
                    XSAlert.show(type: .text, text: "草稿已存在")
                } else {
                    pushTask.pushModel.title = textView.text
                    pushTask.pushModel.tags = getVideoTags()
                    if let coins = Int(coinInputTf.text ?? "0"), coins > 0 {
                        pushTask.pushModel.coins = coins
                    }
                    pushTask.pushModel.islong = islong
                    pushTask.pushModel.tagsModel = tagModels
                    pushTask.pushModel.create_at = Date.getLocalDateStrWithDate(date: Date())
                    showSaveSuccessDialog()
                }
            } else { /// 非草稿，点击存草稿
                XSAlert.show(type: .text, text: "已在上传列表中，不能存为草稿")
            }
            return
        }
            
        // 可以控制草稿最多几份
        let waitTasks = UploadTask.shareTask().tasks.filter { (presennter) -> Bool in
            return presennter.videoPushStatu == .waitForUpload
        }
        if waitTasks.count > 0 {
            XSAlert.show(type: .text, text: "您已有一份草稿未处理")
            return
        }

        let pushModel = PushVideoModel()
        pushModel.videoCover = videoImage
        pushModel.coverLocalPath = coverLocalpath
        pushModel.title = textView.text
        if let coins = Int(coinInputTf.text ?? "0"), coins > 0 {
            pushModel.coins = coins
        }
        pushModel.islong = islong
        pushModel.duration = videoDuration
        pushModel.tags = getVideoTags()
        pushModel.tagsModel = tagModels
        pushModel.create_at = Date.getLocalDateStrWithDate(date: Date())
        pushModel.videoLacalURL = videoLocalPath
        pushTask.pushModel = pushModel
        UploadTask.shareTask().tasks.insert(pushTask, at: 0)
        
        showSaveSuccessDialog()
    }
    func showSaveSuccessDialog() {
        showDialog(title: nil, message: "草稿保存成功 \n请前往“我的”-“作品管理”-“上传列表”查看\n", okTitle: "立即查看", cancelTitle: isUploadExit ? "返回" : "返回主页", okHandler: {
            self.goWorkUploadVc(true)
        }) {
            self.backAction()
        }
    }
    
    /// 上传业务 1.判断必传参数。 2.上传封面图， 3。上传视频文件 4. 吊用提交接口。
    @objc func commitPushVideo(_ sender: UIButton) {
        tapScaleDownAnimation(sender)
        if textView.text.isEmpty {
            XSAlert.show(type: .text, text: "请填写视频话题内容")
            return
        }
        if tagModels.count == 0 {
            XSAlert.show(type: .text, text: "请选择视频标签/话题")
            return
        }
        if textView.text.count > 30 {
            XSAlert.show(type: .text, text: "标题最多20字")
            return
        }
        if let coins = coinInputTf.text, let coinsInt = Int(coins) {
            if coinsInt > (UserModel.share().uploadDiamond_limit ?? 0) {
                XSAlert.show(type: .text, text: "最多设置\(UserModel.share().uploadDiamond_limit ?? 0)钻石")
                return
            }
        }
        let uploadingTasks = UploadTask.shareTask().tasks.filter({ (presenter) -> Bool in
            return presenter.videoPushStatu == .videoUploading
        })
        if uploadingTasks.count >= 3 {
            showDialog(title: nil, message: "最多可同时上传3个作品,\n请等待上传中作品完成\n", okTitle: "查看进度", cancelTitle: "再等一会", okHandler: {
               self.goWorkUploadVc(false)
            }, cancelHandler: nil)
            return
        }
        commitBtn.isEnabled = false
        saveBtn.isEnabled = false
        commitUpload()
    }
    
    /// 提交 // 这里用 UploadTask持有 task,
    func commitUpload() {
        let pushModel = PushVideoModel()
        pushModel.videoCover = videoImage
        pushModel.coverLocalPath = coverLocalpath
        pushModel.title = textView.text
        pushModel.duration = videoDuration
        pushModel.coins = Int(coinInputTf.text ?? "0") ?? 0
        pushModel.islong = islong
        pushModel.tags = getVideoTags()
        pushModel.tagsModel = tagModels
        pushModel.create_at = Date.getLocalDateStrWithDate(date: Date())
        pushModel.videoLacalURL = videoLocalPath
        pushTask.pushModel = pushModel
        /// 如果任务已存在，
        let exit = UploadTask.shareTask().tasks.contains { (presenter) -> Bool in
            return presenter.pushModel.videoLacalURL == pushTask.pushModel.videoLacalURL
        }
        if !exit {
            let waitTasks = UploadTask.shareTask().tasks.filter({ (persenter) -> Bool in
                return persenter.videoPushStatu == .waitForUpload
            })
            if waitTasks.count > 0 {
                if UploadTask.shareTask().tasks.count > waitTasks.count { // 有草稿 也有 上传任务
                    UploadTask.shareTask().tasks.insert(pushTask, at: waitTasks.count)
                } else if UploadTask.shareTask().tasks.count == waitTasks.count {  // 只有草稿
                    UploadTask.shareTask().tasks.append(pushTask)
                }
            } else { // 没有草稿
                UploadTask.shareTask().tasks.insert(pushTask, at: 0)
            }
        }
        pushTask.uploadVideo()
        showDialog(title: nil, message: "作品已加入上传队列\n请前往“我的”-“作品管理”-“上传列表”查看\n", okTitle: "立即查看", cancelTitle: "返回主页", okHandler: {
            self.goWorkUploadVc(true)
        }) {
            self.backAction()
        }
    }
    
    func updateProgressUI(_ progress: Double) {
        let height = Float(progress * 145.0)
        progressCover.snp.updateConstraints { (make) in
            make.height.equalTo(height)
        }
        progressCover.text = String(format: "上传中%.f%@", Float(progress * 100.0), "%")
    }
    
    func getVideoTags() -> [[String: Any]] {
        var tags = [[String: Any]]()
        for tagModel in tagModels {
            var tagParams = [String : Any]()
            tagParams["id"] = tagModel.id ?? 0
            tagParams["title"] = tagModel.title ?? ""
            tags.append(tagParams)
        }
        return tags
    }
    /// 取出所有的ids
    func getVideokeysIds() -> [Int]? {
        var tagKeyIds = [Int]()
        for tagModel in tagModels {
            tagKeyIds.append(tagModel.id ?? 0)
        }
        return tagKeyIds
//        if let data = try? JSONSerialization.data(withJSONObject: tagKeyIds, options: []) {
//            if let json = NSString.init(data: data, encoding: String.Encoding.utf8.rawValue) {
//                return json as String
//            }
//        }
    }
    
    /// 取出所有title
    func getVideokeysTitles() -> [String] {
        var tagKeyTitles = [String]()
        for tagModel in tagModels {
            tagKeyTitles.append(tagModel.title ?? "")
        }
        return tagKeyTitles
    }
    
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension PushVideoController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return tagModels.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = cellForRow(with: indexPath)
        return cell
    }
    
    /// 配置cell
    func cellForRow(with indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PushKeysCell.cellId, for: indexPath) as! PushKeysCell
        cell.tagLabel.text = "# \(tagModels[indexPath.row].title ?? "")"
        cell.tagLabel.backgroundColor = .clear
        cell.deleteTagsHandler = { [weak self] in
            self?.tagModels.remove(at: indexPath.item)
            self?.isChangeparams = true
            self?.collectionView.reloadData()
        }
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let model = tagModels[indexPath.item]
        let size = UILabel().textSize(text: model.title ?? "", font: UIFont.systemFont(ofSize: 13), maxSize: CGSize(width: screenWidth, height: 40), 0)
        return CGSize(width: size.width + 30, height: 40)
    }
}

// MARK: - QHNavigationBarDelegate
extension PushVideoController:  CLNavigationBarDelegate  {
    
    func backAction() {
        if isUploadExit {
            navigationController?.popViewController(animated: true)
        } else {
            closeAction()
        }
    }
    
}

// MARK: - UITextViewDelegate
extension PushVideoController: UITextViewDelegate {
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        placeHodlerLable.text = nil
    }
    
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if textView.text.count >= 20 {
            showNearDialog(redTitle: "温馨提示", message: "视频标题最多输入20字", okTitle: "知道了", cancelTitle: nil, okHandler: nil, cancelHandler: nil)
        }
        return true
    }
    
    func textViewShouldEndEditing(_ textView: UITextView) -> Bool {
        if textView.text.isEmpty {
            placeHodlerLable.text = "写标题并使用合适的话题，能让更多人看到~"
        }
        return true
    }
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension PushVideoController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCustomAnimation(msg: nil, onView: self.view, imageNames: nil, bgColor: UIColor.clear, animated: false)
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is UserUploadCountApi {
            if let dic = manager.response.content as? [String : Any] {
                if ConstValue.kIsEncryptoApi { /// 加密后 s次数变为字符串
                    if let result = dic["result"] as? String  {
                        let decodeResultString = result.urlDecoded()
                        if let num = decodeResultString.aes128DecryptString(withKey: ConstValue.kApiEncryptKey) {
                            if Int(num) == 0 {
                                XSAlert.show(type: .error, text: "今日上传次数已满，请隔日再上传")
                            } else {
                                commitUpload()
                            }
                        }
                    }
                } else {
                    if let result = dic["result"] as? Int {
                        if result == 0 {
                            XSAlert.show(type: .error, text: "今日上传次数已满，请隔日再上传")
                        } else {
                            commitUpload()
                        }
                    }
                }
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        XSAlert.show(type: .error, text: "网络不佳，请重试")
    }
}


// MARK: - Layout
private extension PushVideoController {
    
    func layoutPageSubviews() {
        layoutNavBar()
        layoutVideoPart()
        layoutBottomPart()
        layoutCollectionView()
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    func layoutVideoPart() {
        videoCoverImg.snp.makeConstraints { (make) in
            make.trailing.equalTo(-12)
            make.top.equalTo(navBar.snp.bottom).offset(10)
            make.width.equalTo(100)
            make.height.equalTo(145)
        }
        videoBtn.snp.makeConstraints { (make) in
            make.centerX.equalTo(videoCoverImg)
            make.centerY.equalTo(videoCoverImg).offset(-15)
            make.width.height.equalTo(40)
        }
        choseCoverBtn.snp.makeConstraints { (make) in
            make.bottom.equalTo(videoCoverImg).offset(-8)
            make.centerX.equalTo(videoCoverImg)
            make.height.equalTo(30)
            make.width.equalTo(80)
        }
        textView.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.top.equalTo(navBar.snp.bottom).offset(5)
            make.trailing.equalTo(videoCoverImg.snp.leading).offset(-10)
            make.height.equalTo(150)
        }
        progressCover.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalTo(videoCoverImg)
            make.height.equalTo(0)
        }
        placeHodlerLable.snp.makeConstraints { (make) in
            make.top.equalTo(navBar.snp.bottom).offset(5)
            make.leading.equalTo(textView).offset(10)
            make.trailing.equalTo(textView).offset(-10)
            make.height.equalTo(40)
        }
        tagButton.snp.makeConstraints { (make) in
            make.leading.equalTo(textView).offset(10)
            make.bottom.equalTo(textView)
            make.height.equalTo(30)
            make.width.equalTo(65)
        }
    }
  
    func layoutBottomPart() {
        saveBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.width.equalTo((ConstValue.kScreenWdith - 55)/2)
            make.height.equalTo(45)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-15)
            } else {
                make.bottom.equalTo(-15)
            }
        }
        commitBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.width.equalTo((ConstValue.kScreenWdith - 55)/2)
            make.height.equalTo(45)
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-15)
            } else {
                make.bottom.equalTo(-15)
            }
        }
    }
    
    func layoutCollectionView() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(videoCoverImg.snp.bottom).offset(10)
            make.height.equalTo(60)
        }
        line.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(collectionView.snp.bottom)
            make.height.equalTo(3)
        }
        coinsTitle.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(line.snp.bottom)
            make.height.equalTo(50)
        }
        coinInputView.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(coinsTitle.snp.bottom).offset(5)
            make.height.equalTo(50)
        }
        coinInputTf.snp.makeConstraints { (make) in
            make.leading.equalTo(20)
            make.trailing.equalTo(-20)
            make.centerY.equalToSuperview()
            make.height.equalTo(40)
        }
    }
}
