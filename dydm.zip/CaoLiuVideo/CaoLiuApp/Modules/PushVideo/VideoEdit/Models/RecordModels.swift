

import Foundation

struct CateListModel: Codable {
    var current_page: Int?
    var data: [CateSectionModel]?
}

struct CateSectionModel: Codable {
    var id: Int?
    var title: String?
    var type_list: [CateTagModel]?
}

struct CateTagModel: Codable {
    var id: Int?
    var title: String?
    var isSelected: Bool? = false
}

class PushVideoModel {
    var videoCover: UIImage?           // 视频封面图
    var coverLocalPath: URL?         // 本地图片地址
    var coverPath: String?           // 远程图片地址
    
    var videoUrl: String?           // 远程视频地址
    var videoLacalURL: URL?         // 视频本地路径
    
    var coins: Int?
    var islong: Int?
    
    var title: String?
    var tags: [[String : Any]]?
    var tagsModel: [SearchHotTips]?  // 标签
    var duration: Int?
    var create_at: String?
    
    var commitParams: [String: Any]?  // 提交接口所需参数
    
    var isLocal: Bool? = false
}

/// 视频上传成功回调model
struct PushVideoBackModel: Codable {
    var file_name: String?
    var file_content_type: String?
    var file_path: String?
    var file_size: String?
}


/// 上传任务管理单利
class UploadTask: NSObject {
    static private let task: UploadTask = UploadTask()
    class func shareTask() -> UploadTask {
        return task
    }
    /// 保存暂未发布的视频任务
    var tasks = [PushPresenter]()
    /// 保存发布主页 填写的 发布文字
    var content:String?
    
    func saveAllTasksDataToLocal() {
        if tasks.count == 0 {
            cleanLocalTaskParam()
            return
        }
        var taskArray = [[String: Any]]()
        for p in tasks {
            let task = p.pushModel
            var taskParams = [String: Any]()
            taskParams[PushVideoApi.kTitle] = task.title
            taskParams[PushVideoApi.kVideo] = task.videoUrl
            taskParams[PushVideoApi.kDuration] = task.duration
            taskParams[PushVideoApi.kUplodAt] = task.create_at
            taskParams[PushVideoApi.kVideoLocalPath] = task.videoLacalURL?.path
    
            taskParams[PushVideoApi.kCoverImage] = task.coverPath
            taskParams[PushVideoApi.kImageLocalPath] = task.coverLocalPath?.path
            taskParams[PushVideoApi.kTagParams] = task.tags
            taskParams[PushVideoApi.kUploadStatu] = p.videoPushStatu.rawValue
            
            taskArray.append(taskParams)
            print("taskParamsSave = \(taskArray)")
        }
        UserDefaults.standard.set(taskArray, forKey: UserDefaults.kVideoTaskParams)
    }
    
    func readLocalUploadTasks() {
        if let taskArrays = UserDefaults.standard.value(forKey: UserDefaults.kVideoTaskParams) as? [[String: Any]] {
            print("taskParams = \(taskArrays)")
            for taskParams in taskArrays {
                let presenter = PushPresenter()
                let task = PushVideoModel()
                if let title = taskParams[PushVideoApi.kTitle] as? String {
                    task.title = title
                }
                if let videoUrl = taskParams[PushVideoApi.kVideo] as? String {
                    task.videoUrl = videoUrl
                }
                if let videoLacalURL = taskParams[PushVideoApi.kVideoLocalPath] as? String {
                    task.videoLacalURL = URL(fileURLWithPath: videoLacalURL)
                }
                if let duration = taskParams[PushVideoApi.kDuration] as? Int {
                    task.duration = duration
                }
                if let create_at = taskParams[PushVideoApi.kUplodAt] as? String {
                    task.create_at = create_at
                }
                if let coverPath = taskParams[PushVideoApi.kCoverImage] as? String {
                    task.coverPath = coverPath
                }
                if let coverLacalPath = taskParams[PushVideoApi.kImageLocalPath] as? String {
                    let filePathURL = URL(fileURLWithPath: coverLacalPath)
                    task.coverLocalPath = filePathURL
                    if let image = UIImage(contentsOfFile: filePathURL.path) {
                        task.videoCover = image
                    }
                }
                if let tagParams = taskParams[PushVideoApi.kTagParams] as? [[String: Any]] {
                    task.tags = tagParams
                    var tagsModels = [SearchHotTips]()
                    for i in 0 ..< tagParams.count {
                        let param = tagParams[i]
                        var model = SearchHotTips()
                        if let id = param["id"] as? Int {
                            model.id  = id
                            model.type_id = id
                        }
                        if let title = param["title"] as? String {
                            model.title = title
                        }
                        tagsModels.append(model)
                    }
                    task.tagsModel = tagsModels
                }
                presenter.pushModel = task
                if let statu = taskParams[PushVideoApi.kUploadStatu] as? Int {
                    presenter.videoPushStatu = VideoPushStatu(rawValue: statu) ?? VideoPushStatu.waitForUpload
                }
                UploadTask.shareTask().tasks.append(presenter)
            }
        }
    }
    
    /// 清理本地上传任务
    func cleanLocalTaskParam() {
        if let _ = UserDefaults.standard.value(forKey: UserDefaults.kVideoTaskParams) as? [[String: Any]] {
            UserDefaults.standard.set(nil, forKey:  UserDefaults.kVideoTaskParams)
        }
    }
}
