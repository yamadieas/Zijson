

import UIKit
import Alamofire
import NicooNetwork

/// 视频上传状态
///
/// - waitForUpload: 视频等待上传
/// - videoUploading: 视频上传中...
/// - videoUploadFailed: 视频上传失败
/// - imageUploading: 封面图上传中...
/// - imageUploadFailed: 封面图上传失败
/// - commitFailed: 提交失败
/// - videoChecking: 提交成功之后，视频进入审核状态 （下一次拉去列表这个状态应该有后台数据 控制）
enum VideoPushStatu: Int {
    case waitForUpload = 0
    case videoUploading = 1
    case videoUploadFailed = 2
    case imageUploading = 3
    case imageUploadFailed = 4
    case commitFailed = 5
    case videoChecking = 6
}

/// 上传类型
///
/// - pushTypeCheck: 资质审核
/// - pushTypeWorks: 上传作品
enum VideoPushType: Int {
    case pushTypeCheck = 0
    case pushTypeWorks
}

class PushPresenter: NSObject {

    /// 封面图上传Api
    private lazy var imageUpLoad: UploadImageTool = {
        let upload = UploadImageTool()
        upload.delegate = self
        return upload
    }()
    /// 视频上传Api
    private lazy var videoUpLoad: UploadVideoTool = {
        let upload = UploadVideoTool()
        upload.delegate = self
        return upload
    }()
    /// 上传提交Api
    private lazy var pushUpApi: PushVideoApi = {
        let pushApi = PushVideoApi()
        pushApi.paramSource = self
        pushApi.delegate = self
        return pushApi
    }()

    var videoPushStatu: VideoPushStatu = .waitForUpload
    var videoPushType: VideoPushType = .pushTypeWorks
    
    /// 上传所需资源，参数
    var pushModel = PushVideoModel()
    var videoProgress: Double = 0.0
    
    /// 视频上传进度回调
    var videoUploadProgressHandler:((_ progress: Double) -> Void)?
    /// 视频上传成功
    var videoUploadSucceedHandler:(() -> Void)?
    /// 视频上传失败
    var videoUploadFailedHandler:((_ errorMsg: String) -> Void)?
    
    /// 图片上传成功
    var imageUploadSucceedHandler:(() -> Void)?
    /// 图片上传失败
    var imageUploadFailedHandler:((_ errorMsg: String) -> Void)?
    
    /// 提交成功
    var commitUploadSucceedHandler:(() -> Void)?
    /// 提交失败
    var commitUploadFailedHandler:((_ errorMsg: String) -> Void)?
 
}

// MARK: - Open func
extension PushPresenter {
    
    /// 上传视频封面
    func uploadVideoCover() {
        videoPushStatu = .imageUploading
        imageUpLoad.upload(pushModel.videoCover)
    }
    
    /// 上传视频
    func uploadVideo() {
        videoPushStatu = .videoUploading
        videoUpLoad.upload(pushModel.videoLacalURL)
    }
    
    /// 资源上传完，提交
    func commitForPush() {
        let _ = pushUpApi.loadData()
    }
    
    /// 上传失败时，存本地
    func saveUploadTask() {
        UploadTask.shareTask().saveAllTasksDataToLocal()
    }
}

// MARK: - UploadImageDelegate
extension PushPresenter: UploadImageDelegate {
    
    func paramsForAPI(_ uploadImageTool: UploadImageTool) -> [String : String]? {
        return nil
    }
    
    func uploadImageMethod(_ uploadImageTool: UploadImageTool) -> String {
        let dateNow = Date()
        let timeInterval: TimeInterval = dateNow.timeIntervalSince1970
        let timeStamp = Int(timeInterval)
        let platform = "I"
        let signString = String(format: "%@%d%@", platform, timeStamp, "pb5pe0MXChXsic0N")
        let sign = (signString.md5()?.uppercased() ?? "") as String
        DLog("signString == \(signString)")
        return "/upload?dir=uc&platform=\(platform)&timestamp=\(timeStamp)&sign=\(sign)"
    }
    
    func uploadImageSuccess(_ uploadImageTool: UploadImageTool, resultDic: [String : Any]?) {
        if let result = resultDic?["result"] as? [String: Any], let path = result["file_path"] as? String {
            pushModel.coverPath = path
            ///  图片上传成功回调
            imageUploadSucceedHandler?()
            /// 这里吊用提交接口
            commitForPush()
        }
    }
    
    func uploadImageFailed(_ uploadImageTool: UploadImageTool, errorMessage: String?) {
        videoPushStatu = .imageUploadFailed
        saveUploadTask()
        imageUploadFailedHandler?(errorMessage ?? "封面图上传失败！")
    }
    
    func base64Encoding(plainString: String) -> String {
        let plainData = plainString.data(using: String.Encoding.utf8)
        let base64String = plainData?.base64EncodedString(options: NSData.Base64EncodingOptions.init(rawValue: 0))
        return base64String!
    }
}

// MARK: - UploadVideoDelegate
extension PushPresenter: UploadVideoDelegate {
    
    func uploadVideoMethod(_ uploadVideoTool: UploadVideoTool) -> String {
        let dateNow = Date()
        let timeInterval: TimeInterval = dateNow.timeIntervalSince1970
        let timeStamp = Int(timeInterval)
        let platform = "I"
        let signString = String(format: "%@%d%@", platform, timeStamp, "pb5pe0MXChXsic0N")
        let sign = (signString.md5()?.uppercased() ?? "") as String
        DLog("signString == \(signString)")
        return "/upload?dir=uv&platform=\(platform)&timestamp=\(timeStamp)&sign=\(sign)"
       
    }
    
    func uploadVideoSuccess(_ uploadVideoTool: UploadVideoTool, resultDic: [String : Any]?) {
        if let videoFileInfo = resultDic?["result"] as? [String: String], let path = videoFileInfo["file_path"] {
            pushModel.videoUrl = path
            /// 视频上传成功回调
            videoUploadSucceedHandler?()
            /// 上传图片
            uploadVideoCover()
        }
    }
    
    func uploadVideoProgress(_ progress: Double) {
        videoProgress = progress
        videoUploadProgressHandler?(progress)
    }
    
    func uploadVideoFailed(_ uploadVideoTool: UploadVideoTool, errorMessage: String?) {
        videoPushStatu = .videoUploadFailed
        saveUploadTask()
        videoUploadFailedHandler?(errorMessage ?? "视频上传失败！")
    }
    
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension PushPresenter: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        var params = [String: Any]()
        params[PushVideoApi.kTitle] = pushModel.title
        params[PushVideoApi.kDuration] = pushModel.duration
        params[PushVideoApi.kVideo] = pushModel.videoUrl
        params[PushVideoApi.kCoverImage] = pushModel.coverPath
        params[PushVideoApi.kIslong] = pushModel.islong ?? 0
        params[PushVideoApi.kCoins] = pushModel.coins ?? 0
        let mStr = NSMutableString.init()
        if let tags = pushModel.tags, tags.count > 0 {
            for i in 0 ..< tags.count {
                if i == tags.count - 1 {
                    mStr.append("\(tags[i]["id"] ?? "0")")
                } else {
                    mStr.append("\(tags[i]["id"] ?? "0"),")
                }
            }
            params[PushVideoApi.kTagIds] = mStr as String
        }
        DLog("pushVideoParams = \(params)")
        return params
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if manager is PushVideoApi {
            videoPushStatu = .videoChecking
            saveUploadTask()
            commitUploadSucceedHandler?()
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager is PushVideoApi  {
            videoPushStatu = .commitFailed
            saveUploadTask()
            commitUploadFailedHandler?(manager.errorMessage)
        }
    }
}

