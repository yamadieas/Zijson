
import UIKit

public class CLHomePlayCell: UICollectionViewCell {
    
    static let cellId = "QHHomeCellIdentifier"

    let bgImage: UIImageView = {
          let imageView = UIImageView()
          imageView.isUserInteractionEnabled = true
          imageView.contentMode = .scaleAspectFit
          imageView.backgroundColor = UIColor.darkText
          return imageView
      }()
    let imagePlace: UIImageView = {
        let imageView = UIImageView()
        imageView.isUserInteractionEnabled = true
        imageView.contentMode = .scaleAspectFill
        imageView.backgroundColor = .darkText
        imageView.image = getImage("playCellBg") 
        return imageView
    }()
    let bottomView: ShortBottomView = {
        let v = ShortBottomView()
        return v
    }()
    let infoView: DetailInfoView = {
        let v = DetailInfoView()
        v.backgroundColor = .clear
        v.infoLab.textColor = .white
        v.countsLab.textColor = .white
        return v
    }()
    let adVidew: ShortAdBottomView = {
        let v = ShortAdBottomView()
        v.backgroundColor = .clear
        return v
    }()
    /// 广告点击后响应跳转
    lazy var adCoverTap: UIButton = {
        let tap = UIButton(type: .custom)
        tap.addTarget(self, action: #selector(allActionFunc(_:)), for: .touchUpInside)
        tap.isHidden = true
        return tap
    }()
    lazy var headerBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.contentMode = .scaleAspectFill
        button.layer.cornerRadius = 13
        button.layer.masksToBounds = true
        button.layer.borderColor = UIColor.white.cgColor
        button.layer.borderWidth = 1.0
        button.addTarget(self, action: #selector(allActionFunc(_:)), for: .touchUpInside)
        return button
    }()
    lazy var focusButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor.clear
        button.setTitle("关注", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 11)
        button.backgroundColor = ConstValue.kStypeColor
        button.layer.cornerRadius = 11
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(allActionFunc(_:)), for: .touchUpInside)
        return button
    }()
   
    let vipTipsView: UserShorVipView = {
        let v = UserShorVipView(frame: CGRect(x: 0, y: 0, width: screenWidth - 30, height: 30))
        v.backgroundColor = .clear
        return v
    }()
    lazy var tipsLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .left
        lable.numberOfLines = 1
        lable.textColor = .white
        lable.font = UIFont.systemFont(ofSize: 13)
        return lable
    }()
    lazy var nameLable: UIButton = {
        let lable = UIButton(type: .custom)
        lable.titleLabel?.font = UIFont.boldSystemFont(ofSize: 16)
        lable.addTarget(self, action: #selector(allActionFunc(_:)), for: .touchUpInside)
        return lable
    }()
    let countDownlabel: UILabel = {
        let lable = UILabel()
        lable.backgroundColor = UIColor.colorGradientChangeWithSize(size: CGSize(width: screenWidth - 30, height: 45), direction: .level, startColor: rgb(247, 219, 172), endColor: rgb(223, 180, 127))
        lable.numberOfLines = 2
        lable.textColor = .darkText
        lable.borderRadius = 7.5
        lable.textAlignment = .center
        lable.font = UIFont.boldSystemFont(ofSize: 14)
        lable.isHidden = true
        lable.layer.cornerRadius = 3
        lable.layer.masksToBounds = true
        return lable
    }()
    lazy var tipsButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor.clear
        button.addTarget(self, action: #selector(allActionFunc(_:)), for: .touchUpInside)
        button.isHidden = true
        return button
    }()
   
    lazy var introLable: UILabel = {
        let lable = UILabel()
        lable.textAlignment = .left
        lable.numberOfLines = 5
        lable.textColor = .white
        lable.font = UIFont.systemFont(ofSize: 14)
        return lable
    }()
   
    var videoModel: VideoNew?

    /// 1: 头像 2: 关注 3: 广告点击 4: 影片 5 分享 6: 金币支付 7: 新用户标签
    var actionSingleHandler:((_ actionId: Int) -> Void)?
    var videoFavorItemClick:((_ isFavor: Bool) -> Void)?
    var clickTypeKeyCellHandler: ((SearchHotTips)->())?
    var actionVipViewHandler:((_ actionId: Int) -> Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.darkText
        self.selectedBackgroundView = UIView()
        setUpUI()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setUpUI()
    }
    
    //MARK: Private
    func setUpUI() {
        contentView.backgroundColor = UIColor.clear
        contentView.addSubview(bgImage)
        contentView.insertSubview(imagePlace, at: 0)
        contentView.addSubview(adVidew)
        contentView.addSubview(adCoverTap)
       
        contentView.addSubview(headerBtn)
        contentView.addSubview(focusButton)
        contentView.addSubview(infoView)
        contentView.addSubview(bottomView)
        contentView.addSubview(nameLable)
        contentView.addSubview(vipTipsView)
        contentView.addSubview(countDownlabel)
        contentView.addSubview(tipsButton)
        layoutPageSubviews()
        
    }
    
    func setVideoModel(_ video: VideoNew?) {
        videoModel = video
        let mstring = NSMutableString()
        if let allKeys = video?.category, allKeys.count > 0 {
            for keyModel in allKeys {
                mstring.append(" #\(keyModel.title ?? "")")
            }
        }
        let size = UILabel().textSize(text: video?.title?.appending(mstring as String) ?? "", font: UIFont.boldSystemFont(ofSize: 14), maxSize: CGSize(width: screenWidth - 30, height: 200), 4)
        infoView.snp.updateConstraints { (make) in
            make.height.equalTo(55 + size.height)
        }
        infoView.setModel(video, .white)
        infoView.tagClickAction = { [weak self] tag in
            self?.clickTypeKeyCellHandler?(tag)
        }
        bottomView.setModel(video)
        bottomView.itemClickHandler = { [weak self] index in
            if index == 0 {
                self?.videoFavorItemClick?(video?.is_like == 0)
            } else if index == 1 {
                self?.actionSingleHandler?(5)
            }
        }
        setUIHidenOrNot(false)
        videoModel = video ?? VideoNew()
        bgImage.kfSetHeaderImageWithUrl(video?.cover, placeHolder: getImage("playCellBg"))
       
        if let userModel = video?.user {
            headerBtn.kfsetHeader(userModel.avatar)
            nameLable.setTitle("@\(userModel.nick ?? "")", for: .normal)
        }
        if let follow = video?.is_attention {
            focusButton.isHidden = follow == 1
        } else {
            focusButton.isHidden = false
        }
        if let time = video?.countdown?.countdown_time, time > 0 {
            countDownlabel.isHidden = false
            tipsButton.isHidden = false
            countDownlabel.tag = 333
            let size = countDownlabel.textSize(text: "\(video?.countdown?.countdown_intro ?? "") \(time > 1 ? PlayerView.formatTimDuration(duration: time) : "")", font: UIFont.systemFont(ofSize: 14), maxSize: CGSize(width: screenWidth-30, height: 300), 35)
            countDownlabel.snp.updateConstraints { (make) in
                if size.height + 10 > 45 {
                    make.height.equalTo(size.height + 0)
                } else {
                    make.height.equalTo(45)
                }
            }
            countDownlabel.attributedText = TextSpaceManager.getAttributeStringWithString("\(video?.countdown?.countdown_intro ?? "") \(time > 1 ? LGConfig.timeDuration(duration: time) : "")", lineSpace: 3, .center)
        } else {
            countDownlabel.isHidden = true
            tipsButton.isHidden = true
            countDownlabel.snp.updateConstraints { (make) in
                make.height.equalTo(0)
            }
            countDownlabel.tag = -1
        }
        vipTipsView.setModel(video)
        vipTipsView.clickAction = { [weak self] actionId in
            self?.actionVipViewHandler?(actionId)
        }
        adCoverTap.isHidden = true
        adVidew.isHidden = true
        bottomView.isHidden = false
    }
   
    func setAdModel(_ ad: AdHome?) {
        bgImage.kfSetHeaderImageWithUrl(ad?.cover, placeHolder: getImage("playCellBg"))
        adVidew.titleLabel.attributedText = TextSpaceManager.getAttributeStringWithString(ad?.title ?? "", lineSpace: 5)
        setUIHidenOrNot(true)
        bottomView.isHidden = true
        adVidew.isHidden = false
        adCoverTap.isHidden = false
        vipTipsView.isHidden = true
    }
    
    //MARK: Action
    @objc func allActionFunc(_ sender: UIButton) {
        if sender == headerBtn || sender == nameLable {
            actionSingleHandler?(1)
        } else if sender == focusButton {
            actionSingleHandler?(2)
        } else if sender == adCoverTap {
            actionSingleHandler?(4)
        } else if sender == tipsButton {
            actionSingleHandler?(7)
        }
    }
  
    /// 拖动进度时的ui显示隐藏
    func setUIHidenOrNot(_ isDrag: Bool) {
        headerBtn.isHidden = isDrag
        focusButton.isHidden = isDrag
        nameLable.isHidden = isDrag
        infoView.isHidden = isDrag
        if vipTipsView.tag == 154 {
            vipTipsView.isHidden = true
        } else {
            vipTipsView.isHidden = isDrag
        }
        if countDownlabel.tag != -1 {
            countDownlabel.isHidden = isDrag
        } else {
            countDownlabel.isHidden = true
        }
    }
}

// MARK: - layout
private extension CLHomePlayCell {
    
    func layoutPageSubviews() {
        bgImage.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        imagePlace.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        adVidew.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalToSuperview()
        }
        adCoverTap.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        
        bottomView.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalToSuperview()
            make.height.equalTo(safeAreaBottomHeight + 60)
        }
        countDownlabel.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.bottom.equalTo(bottomView.snp.top).offset(-20)
            make.height.equalTo(45)
        }
        tipsButton.snp.makeConstraints { (make) in
            make.edges.equalTo(countDownlabel)
        }
        infoView.snp.makeConstraints { (make) in
            make.leading.equalTo(0)
            make.trailing.equalTo(0)
            make.bottom.equalTo(countDownlabel.snp.top).offset(-5)
            make.height.equalTo(75)
        }
        headerBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.bottom.equalTo(infoView.snp.top)
            make.height.width.equalTo(26)
        }
        nameLable.snp.makeConstraints { (make) in
            make.centerY.equalTo(headerBtn)
            make.leading.equalTo(headerBtn.snp.trailing).offset(8)
        }
        focusButton.snp.makeConstraints { (make) in
            make.centerY.equalTo(headerBtn)
            make.leading.equalTo(nameLable.snp.trailing).offset(10)
            make.height.equalTo(22)
            make.width.equalTo(44)
        }
        vipTipsView.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.bottom.equalTo(headerBtn.snp.top).offset(-8)
            make.height.equalTo(30)
        }
    }
}

extension NSObject {
    class func timeDuration(duration:Int) -> String {
        guard  duration != 0 else{
            return "00:00:00"
        }
        let durationDays = (duration / 86400)
        let durationHours = (duration / 3600) % 24
        let durationMinutes = (duration / 60) % 60
        let durationSeconds = duration % 60
        if durationDays > 0 {
            return String(format: "%d天:%02d:%02d:%02d",durationDays,durationHours,durationMinutes,durationSeconds)
        } else {
            if durationHours > 0 {
                return String(format: "%02d:%02d:%02d",durationHours,durationMinutes,durationSeconds)
            } else {
                return String(format: "%02d:%02d",durationMinutes,durationSeconds)
            }
        }
    }
    class func timeDurationArry(duration:Int) -> [String] {
        guard  duration != 0 else{
            return ["00","00","00"]
        }
        let durationDays = (duration / 3600 / 24)
        let durationHours = (duration / 3600) % 24
        let durationMinutes = (duration / 60) % 60
        let durationSeconds = duration % 60
        if durationDays > 0 {
            return[String(format: "%d",durationDays),String(format: "%02d",durationHours),String(format: "%02d",durationMinutes),String(format: "%02d",durationSeconds)]
        } else {
            return[String(format: "%02d",durationHours),String(format: "%02d",durationMinutes),String(format: "%02d",durationSeconds)]
        }
    }
}
