
import UIKit

class SignCollection: UIView {
    
    private let customLayout: UICollectionViewFlowLayout = {
        let layout = UICollectionViewFlowLayout()
        layout.itemSize = SignItemCell.itemSize
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = 0
        layout.sectionInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        return layout
    }()
    private lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect.zero, collectionViewLayout: customLayout)
        collection.backgroundColor = UIColor.clear
        collection.showsVerticalScrollIndicator = false
        collection.isScrollEnabled = false
        collection.delegate = self
        collection.dataSource = self
        collection.register(SignItemCell.classForCoder(), forCellWithReuseIdentifier: SignItemCell.cellId)
        return collection
    }()
    var sign = SignInfo()
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.white
        seUpUI()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func seUpUI() {
        addSubview(collectionView)
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(0)
            make.bottom.equalToSuperview().offset(-12)
        }
    }
    
    func setUpSign(_ signInfo: SignInfo) {
        sign = signInfo
        collectionView.reloadData()
    }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension SignCollection: UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let signsData = sign.sign_ini?.ini {
             return signsData.count
        }
       return 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: SignItemCell.cellId, for: indexPath) as! SignItemCell
        if let signsData = sign.sign_ini?.ini, let signInfo = sign.sign_info {
            if indexPath.item < signInfo.sign ?? 0 {
                cell.itemBgView.backgroundColor = ConstValue.kStypeColor
                cell.titleLab.textColor = .white
            } else {
                cell.itemBgView.backgroundColor = UIColor(r: 229, g: 242, b: 255)
                 cell.titleLab.textColor = .lightGray
            }
            let signPic = signsData[indexPath.item]
            cell.titleLab.text = getStringWithNumber(signPic.coins ?? 0)
        }
        return cell
    }
    
}


class SignItemCell: UICollectionViewCell {
    static let width = (screenWidth - 60)/7
    static let height = width * 3/2
    static let itemSize = CGSize(width: width, height: height)
    static let cellId = "SignItemCell"
    let itemBgView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(r: 229, g: 242, b: 255)
        view.layer.cornerRadius = 5
        return view
    }()
    let lineView: UIView = {
        let v = UIView()
        v.backgroundColor = UIColor(r: 229, g: 242, b: 255)
        return v
    }()
    let itemImage: UIImageView = {
        let image = UIImageView()
        image.image = getImage("diamond")
        image.contentMode = .scaleAspectFit
        image.addShadow(radius: 5, opacity: 0.8, UIColor.white)
        return image
    }()
    let titleLab: UILabel = {
        let lable = UILabel()
        lable.textColor = .lightGray
        lable.textAlignment = .center
        lable.font = UIFont.systemFont(ofSize: 12)
        return lable
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = UIColor.clear
        self.backgroundColor = UIColor.clear
        contentView.addSubview(lineView)
        contentView.addSubview(itemBgView)
        contentView.addSubview(itemImage)
        contentView.addSubview(titleLab)
        
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

// MARK: - layout
private extension SignItemCell {
    func layoutPageSubviews() {
        layoutItemBgView()
        layoutItemImage()
        layoutTitleLab()
    }
    func layoutItemBgView() {
        itemBgView.snp.makeConstraints { (make) in
            make.top.bottom.equalToSuperview()
            make.leading.equalTo(3)
            make.trailing.equalTo(-3)
        }
    }
    func layoutTitleLab() {
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(5)
            make.trailing.equalTo(-5)
            make.top.equalTo(itemImage.snp.bottom).offset(5)
        }
    }
    func layoutItemImage() {
        itemImage.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(10)
            make.height.width.equalTo(SignItemCell.width - 16)
        }
        lineView.snp.makeConstraints { (make) in
            make.centerY.equalTo(itemImage)
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(4)
        }
    }
}
