//
//  VideoViewModel.swift
//  CaoLiuApp
//
//  Created by mac on 2019/3/5.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import NicooNetwork

/// 视频ViewModel
class VideoViewModel: NSObject {
    
    private lazy var channelListApi: ChannelListApi =  {
        let api = ChannelListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var moduleMoreApi: VideoModuleMoreApi =  {
        let api = VideoModuleMoreApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var videoApi: VideoListApi =  {
        let api = VideoListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var videoHomeApi: VideoHomeListApi =  {
        let api = VideoHomeListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var shortListApi: VideoShortListApi =  {
        let api = VideoShortListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    private lazy var videoAttApi: VideoAttentionListApi =  {
        let api = VideoAttentionListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var videoFavorApi: UserFavorAddApi =  {
        let api = UserFavorAddApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var removeWatchRecordApi: UserDelWatchRecordsApi =  {
        let api = UserDelWatchRecordsApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var videoSeriesListApi: SearchVideoApi =  {
        let api = SearchVideoApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var userVideoListApi: UserWorkListApi =  {
        let api = UserWorkListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var recVideoListApi: SearchHotVideoApi = {
        let api = SearchHotVideoApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var videoAuthApi: VideoAuthApi =  {
        let api = VideoAuthApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var videoProgressReportApi: VideoProgressReportApi =  {
        let api = VideoProgressReportApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var watchRecordApi: UserWatchReccordListApi = {
        let api = UserWatchReccordListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var commentApi: VideoCommentApi = {
        let api = VideoCommentApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
   
    lazy var shaeApi: AppShareContentApi = {
        let api = AppShareContentApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    
    var params: [String: Any]?
    var videoList = [VideoNew]()
 
    var homeModels = [VideoHomeNew]()
    /// 用于区分是否k在播放页面拉去数据
    var sourceCount: Int = 0
    /// 是否是下拉刷新操作
    var isRefreshOperation = false
    
    var noMore = false

    var isRecomment = true
    
    var requestListSuccessHandle:(() -> Void)?
    var requestMoreListSuccessHandle:(() -> Void)?
    var requestFailedHandle:((_ msg: String) -> Void)?
    
    /// 分类频道列表
    var getChannelListSuccessHandle:((_ models: [ChannelModel]) -> Void)?
    var getChannelListFailedHandle:((_ msg: String) -> Void)?
    
    /// 类型下视频
    var requestTypeListSuccessHandle:((_ videos: [VideoNew], _ page: Int) -> Void)?
    var requestTypeListFailedHandle:((_ msg: String) -> Void)?
    
    var requestShortListFailedHandle:((_ msg: String, _ page: Int) -> Void)?
    
    /// 用户的视频
    var getUserVideoListSuccess:((_ videos: [VideoNew], _ page: Int) -> Void)?
    var getUserVideoListFailed:((_ msg: String) -> Void)?
    
    /// 用户历史观看的的视频
    var getWatchRecordListSuccess:((_ videos: [WatchRecord], _ page: Int) -> Void)?
    
    /// 热门视频
    var getHotVideoListSuccess:((_ videos: [VideoNew]) -> Void)?
    var getHotVideoListFailed:((_ msg: String) -> Void)?
    
    var showNodataCallBackHandler:(() -> Void)?
    
    var videoAuthSucceedHandler:((VideoNew) -> Void)?
    var videoAuthFailedHandler:((_ errorMsg: String) -> Void)?
    
    var videoCommentSuccessHandler:(() -> Void)?
    var videoCommentFailedHandler:((_ errorMsg: String) -> Void)?
    
    var videoInfoApiSuccessHandler:((_ model: [VideoModel]) -> Void)?
    var videoInfoApiFailedHandler:((_ msg: String) -> Void)?
    
    
    //系列中视频
    func loadChannelListData(_ params: [String: Any]?,
                             succeedHandler: @escaping ((_ models: [ChannelModel]) -> ()),
                             failHandler: @escaping (_ failMessage: String) -> ()) {
        self.params = params
        if let po = params?[ChannelListApi.kPosition] as? Int {
            channelListApi.position = po
        } else {
            channelListApi.position = 0
        }
        getChannelListSuccessHandle = succeedHandler
        getChannelListFailedHandle = failHandler
        let _ = channelListApi.loadData()
    }
    /// 模块更多视频列表
    func loadModuleMoreListData(params: [String: Any]?,
                                inVipPart: Bool,
                                pageNumber: Int,
                                limit: Int,
                            succeedHandler: @escaping ((_ models: [VideoNew]) -> ()),
                            failHandler: @escaping (_ failMessage: String) -> ())  {
        self.params = params
        getHotVideoListSuccess = succeedHandler
        getHotVideoListFailed = failHandler
        
        moduleMoreApi.inVIPPart = inVipPart
        moduleMoreApi.pageNumber = pageNumber
        moduleMoreApi.kDefaultCount = limit
        _ = moduleMoreApi.loadNextPage()
    }
    
    func loadData() {
        let _ = videoApi.loadData()
    }
    
    func loadNextPage() {
        let _ = videoApi.loadNextPage()
    }
    
    /// 获取首页数据列表
    func loadHomeData(_ recomment: Bool) {
        isRecomment = recomment
        let _ = videoHomeApi.loadData()
    }
    
    func loadHomeDataNextPage() {
        let _ = videoHomeApi.loadNextPage()
    }
    
    //标签中视频 （条件搜索视频接口）
    func loadSeriesVideoData(_ paramsv: [String: Any]?,
                             succeedHandler: @escaping ((_ video: [VideoNew], _ page: Int) -> ()),
                             failHandler: @escaping (_ failMessage: String) -> ()) {
        params = paramsv
        requestTypeListSuccessHandle = succeedHandler
        requestTypeListFailedHandle = failHandler
        let _ = videoSeriesListApi.loadData()
    }
    
    func loadSeriesVideoNextPage() {
        let _ = videoSeriesListApi.loadNextPage()
    }
    
    ///短视频列表 （刷刷刷）
    func loadShortVideoData(_ params: [String: Any]?,
                             succeedHandler: @escaping ((_ video: [VideoNew], _ page: Int) -> ()),
                             failHandler: @escaping (_ failMessage: String, _ page: Int) -> ()) {
        self.params = params
        requestTypeListSuccessHandle = succeedHandler
        requestShortListFailedHandle = failHandler
        let _ = shortListApi.loadData()
    }
    
    /// 短视频列表 （刷刷刷）下一页
    func loadShortVideoNextPage(_ params: [String: Any]?) {
        self.params = params
        let _ = shortListApi.loadNextPage()
    }
    
    //用户的作品视频列表
    func loadUserVideosData(_ param: [String: Any]?,
                             succeedHandler: @escaping ((_ video: [VideoNew], _ page: Int) -> ()),
                             failHandler: @escaping (_ failMessage: String) -> ()) {
        params = param
        getUserVideoListSuccess = succeedHandler
        getUserVideoListFailed = failHandler
        let _ = userVideoListApi.loadData()
    }
    
    func loadUserVideosNextPage() {
        let _ = userVideoListApi.loadNextPage()
    }
    
    /// 用户 观看历史 视频列表
    func loadWatchRecordData(_ param: [String: Any]?,
                             succeedHandler: @escaping ((_ video: [WatchRecord], _ page: Int) -> ()),
                             failHandler: @escaping (_ failMessage: String) -> ()) {
        params = param
        getWatchRecordListSuccess = succeedHandler
        getUserVideoListFailed = failHandler
        let _ = watchRecordApi.loadData()
    }
    
    func loadWatchRecordNextPage() {
        let _ = watchRecordApi.loadNextPage()
    }
    
    /// 用户删除观看记录
    func loadDelectedWatchRecord(_ param: [String: Any]?,
                                 succeedHandler: @escaping (() -> ()),
                                 failHandler: @escaping (_ failMessage: String) -> ()) {
        params = param
        requestListSuccessHandle = succeedHandler
        requestFailedHandle = failHandler
        let _ = removeWatchRecordApi.loadData()
    }
    
    ///热门视频
    func loadRecVideoListApi(_ param: [String: Any]?,
                             succeedHandler: @escaping ((_ video: [VideoNew]) -> ()),
                             failHandler: @escaping (_ failMessage: String) -> ()) {
        params = param
        getHotVideoListSuccess = succeedHandler
        getHotVideoListFailed = failHandler
        let _ = recVideoListApi.loadData()
    }
    
    func loadShareApi() {
        _ = shaeApi.loadData()
    }
    
    /// 视频鉴权
    func loadVideoAuthData(params: [String : Any]? ,succeedHandler: @escaping ((VideoNew) -> ()),
                           failHandler: @escaping (_ failMessage: String) -> ()) {
        self.params = params
        videoAuthFailedHandler = failHandler
        videoAuthSucceedHandler = succeedHandler
        let _ = videoAuthApi.loadData()
    }
    /// 视频观看进度上报
    func loadVideoProgressReportData(params: [String : Any]? ,succeedHandler: @escaping (() -> ()),
                           failHandler: @escaping (_ failMessage: String) -> ()) {
        self.params = params
        requestListSuccessHandle = succeedHandler
        requestFailedHandle = failHandler
        let _ = videoProgressReportApi.loadData()
    }
    
    /// 视频评论
    func loadVideoCommentApi(_ parmasForComment: [String: Any]?) {
        params = parmasForComment
        let _ = commentApi.loadData()
    }
    
}

// MARK: - 暴露给Vc的方法
extension VideoViewModel {
    
    func getVideoList() -> [VideoNew] {
        return videoList
    }
    
    func getHomeList() -> [VideoHomeNew] {
        return homeModels
    }
}

// MARK: - 私有方法
private extension VideoViewModel {
    
    func requestSuccess(_ list: [VideoNew], _ pageNumber: Int) {
         requestTypeListSuccessHandle?(list, pageNumber)
    }
    func requestFail(_ msg: String) {
        requestFailedHandle?(msg)
    }
    func requestHomeListSuccess(_ list: [VideoHomeNew]) {
        if videoHomeApi.pageNumber == 1 {
            homeModels = list
            if list.count == 0 {
                noMore = true
            } else {
                noMore = false
            }
            isRefreshOperation = true
            sourceCount = homeModels.count   //只有第一页数据才在这里赋值
            requestListSuccessHandle?()
        } else {
            //DLog("已为你提前补充数据\(list.count)条 --- \(list)")
            if list.count == 0 {
                noMore = true
            } else {
                noMore = false
            }
            homeModels.append(contentsOf: list)
            requestMoreListSuccessHandle?()
        }
        
        if homeModels.count == 0 {
            // 显示无数据
            showNodataCallBackHandler?()
            noMore = true
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension VideoViewModel: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is VideoHomeListApi {
            return [VideoHomeListApi.kIsFree: isRecomment ? 0 : 1]
        }
        return params
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if manager is ChannelListApi {
            if let channels = manager.fetchJSONData(VideoReformer()) as? [ChannelModel] {
                getChannelListSuccessHandle?(channels)
            }
        }
        if manager is VideoModuleMoreApi {
            if let list = manager.fetchJSONData(VideoReformer()) as? [VideoNew] {
                getHotVideoListSuccess?(list)
            }
        }
        if manager is VideoListApi {
            if let videoListModel = manager.fetchJSONData(VideoReformer()) as? [VideoNew] {
                requestSuccess(videoListModel, videoApi.pageNumber)
            }
        }
        if manager is SearchVideoApi {
            if let videoList = manager.fetchJSONData(VideoReformer()) as? [VideoNew] {
                requestSuccess(videoList, videoSeriesListApi.pageNumber)
            }
        }
        if manager is VideoShortListApi {
            if let videoList = manager.fetchJSONData(VideoReformer()) as? [VideoNew] {
                requestSuccess(videoList, shortListApi.pageNumber)
            }
        }
        if manager is UserWorkListApi {
            if let videoList = manager.fetchJSONData(VideoReformer()) as? [VideoNew] {
                getUserVideoListSuccess?(videoList, userVideoListApi.pageNumber)
            }
        }
        if manager is UserWatchReccordListApi {
            if let videoList = manager.fetchJSONData(VideoReformer()) as? [WatchRecord] {
                getWatchRecordListSuccess?(videoList, watchRecordApi.pageNumber)
            }
        }
        if manager is SearchHotVideoApi {
            if let videoList = manager.fetchJSONData(SearchReformer()) as? [VideoNew] {
                getHotVideoListSuccess?(videoList)
            }
        }
        if manager is VideoHomeListApi {
            if let videoHomeListModel = manager.fetchJSONData(VideoReformer()) as? [VideoHomeNew] {
               requestHomeListSuccess(videoHomeListModel)
            }
        }
        
        if manager is VideoAuthApi {
            if let videoModel = manager.fetchJSONData(VideoReformer()) as? VideoNew {
                videoAuthSucceedHandler?(videoModel)
            }
        }
        if manager is VideoProgressReportApi || manager is UserDelWatchRecordsApi {
            requestListSuccessHandle?()
        }
        if manager is AppShareContentApi {
            if let model = manager.fetchJSONData(VideoReformer()) as? ShareContentModel {
                AppInfo.share().shareInfo = model
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        if manager is VideoListApi || manager is VideoHomeListApi || manager is VideoAttentionListApi  {
            requestFail(manager is VideoHomeListApi ? "" : "")
        }
        if manager is VideoProgressReportApi || manager is UserDelWatchRecordsApi {
            requestFailedHandle?(manager.errorMessage)
        }
        if manager is SearchVideoApi  {
            requestTypeListFailedHandle?(manager.errorMessage)
        }
        if manager is VideoShortListApi  {
            requestShortListFailedHandle?(manager.errorMessage,shortListApi.pageNumber)
        }
        if manager is UserWorkListApi || manager is UserWatchReccordListApi {
            getUserVideoListFailed?(manager.errorMessage)
        }
        if manager is SearchHotVideoApi {
            getHotVideoListFailed?(manager.errorMessage)
        }
        if manager is VideoAuthApi {
            videoAuthFailedHandler?(manager.errorMessage)
        }
        if manager is ChannelListApi {
            getChannelListFailedHandle?(manager.errorMessage)
        }
    }
}

