
import UIKit

struct ShareTypeItemModel {
    var title: String
    var content: String? = nil
    var imageUrl: String? = nil
    var type: ShareContentType
}

enum ShareContentType: Int {
    case text = 0
    case textLink = 1
    case picture = 2
}

class ShareContentItemCell: UICollectionViewCell {
    
    static let cellId = "ShareContentItemCell"
    static let itemSize = CGSize(width: (screenWidth-30)/2, height: (screenWidth-30)*2/3)
    var titleLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = .white
        return label
    }()
    var contentLabel: UILabel = {
        let label = UILabel()
        label.textAlignment = .center
        label.font = UIFont.systemFont(ofSize: 13)
        label.textColor = UIColor.white
        label.numberOfLines = 0
        label.text = UserModel.share().authInfo?.config?.sys?.share_text
        return label
    }()
    
    let imageButton: ShareImageContentView = {
        guard let card = Bundle.main.loadNibNamed("ShareImageContentView", owner: nil, options: nil)?[0] as? ShareImageContentView else { return  ShareImageContentView() }
        return card
    }()
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = ConstValue.kVBgColor
        contentView.layer.cornerRadius = 9
        contentView.layer.masksToBounds = true
        contentView.addSubview(titleLabel)
        contentView.addSubview(contentLabel)
        contentView.addSubview(imageButton)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setShareTypeModel(_ model: ShareTypeItemModel) {
        
        titleLabel.text = model.title
        UserModel.share().shareText = model.content ?? ShareContentItemCell.getDefaultContentString()

        if model.type == .textLink || model.type == .text {
            contentLabel.text = ShareContentItemCell.getDefaultContentString()
        } else {
            contentLabel.text = model.content ?? ShareContentItemCell.getDefaultContentString()
        }
        if model.type == .textLink || model.type == .text {
            imageButton.isHidden = true
            contentLabel.isHidden = false
        } else {
            imageButton.isHidden = false
            contentLabel.isHidden = true
        }
    }
    
    /// 获取默认分享文本
    class func getDefaultContentString()-> String {
        if let textToShare = UserModel.share().authInfo?.config?.sys?.share_text {
            return textToShare
        }
        return ""
    }
    class func getDownLoadUrl() -> String {
        if let downloadString = UserModel.share().authInfo?.config?.sys?.share_url {
           return downloadString
        }
        return ""
    }
    
}

// MARK: - Layout
private extension ShareContentItemCell {
    func layoutPageSubviews() {
        layoutTitleLabel()
        layoutContentLabel()
        layoutImageContentButton()
        
    }
    func layoutTitleLabel() {
        titleLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(5)
            make.trailing.equalTo(-5)
            make.top.equalToSuperview()
            make.height.equalTo(40)
        }
    }
    func layoutContentLabel() {
        contentLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.bottom.equalTo(-25)
        }
    }
    func layoutImageContentButton() {
        let height: CGFloat = ShareContentItemCell.itemSize.height - 75
        imageButton.snp.makeConstraints { (make) in
            make.top.equalTo(titleLabel.snp.bottom).offset(10)
            make.centerX.equalToSuperview()
            make.height.equalTo(height)
            make.width.equalTo(height*3/4)
        }
    }
}
