//
//  ShareImageContentView.swift
//  CaoLiuApp
//
//  Created by mac on 2019/10/2.
//  Copyright © 2019年 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import DouYinScan

class ShareImageContentView: UIView {
    @IBOutlet weak var topicImage: UIImageView!
    @IBOutlet weak var shareText: UILabel!
    @IBOutlet weak var webLabel: UILabel!
    @IBOutlet weak var inviteCodeImg: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        self.backgroundColor = UIColor(white: 0.95, alpha: 1)
        webLabel.addShadow(radius: 5, opacity: 0.8)
        self.layer.masksToBounds = true
        loadQRcode()
        setCardInfo()
    }
    
    func setCardInfo() {
        if let code = UserModel.share().user?.code, let office = UserModel.share().authInfo?.config?.sys?.share_url {
            let sss = office.components(separatedBy: "?")
            if sss.count > 0 {
                 shareText.attributedText = TextSpaceManager.getAttributeStringWithString("掃碼或瀏覽器輸入“\(sss[0])”下載輸入我的邀請碼：\(code) 免費觀看", lineSpace: 10)
            }
        }
        webLabel.attributedText = TextSpaceManager.getAttributeStringWithString(AppInfo.share().shareInfo?.content ?? "", lineSpace: 5)
    }
}

private extension ShareImageContentView {
    func loadQRcode() {
        if let downloadString = UserModel.share().authInfo?.config?.sys?.share_url {
              let qrImg = ScanWrapper.createCode(codeType: "CIQRCodeGenerator", codeString: downloadString, size: CGSize(width: 200, height: 200), qrColor: UIColor.black, bkColor: UIColor.white)
                  inviteCodeImg.image = qrImg
            
        }
    }
    
}
