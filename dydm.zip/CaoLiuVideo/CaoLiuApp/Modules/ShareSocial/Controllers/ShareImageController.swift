
import UIKit
import DouYinScan

class ShareImageController: CLBaseViewController {
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.titleLabel.text = "分享图片"
        bar.lineView.isHidden = true
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    
    let cardView: ShareImageContentView = {
        guard let card = Bundle.main.loadNibNamed("ShareImageContentView", owner: nil, options: nil)?[0] as? ShareImageContentView else { return  ShareImageContentView() }
        return card
    }()
    
    private lazy var shareButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor(r: 0, g: 123, b: 255)
        button.layer.cornerRadius = 20
        button.layer.masksToBounds = true
        button.setTitle("分 享", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    private lazy var saveButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor(r: 0, g: 123, b: 255)
        button.layer.cornerRadius = 20
        button.layer.masksToBounds = true
        button.setTitle("保 存", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 16)
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    
    var shareActivityHandler:(() -> Void)?
    
    var model: ShareTypeItemModel?
    
    deinit {
        NotificationCenter.default.removeObserver(self)
    }

    override func viewDidLoad() {
         NotificationCenter.default.addObserver(self, selector: #selector(shareactivityDown), name: Notification.Name.kShareActivityDownNotification, object: nil)
        super.viewDidLoad()
        loadCard()
    }
   
    private func loadCard() {
        view.addSubview(navBar)
        view.addSubview(cardView)
        view.addSubview(saveButton)
        view.addSubview(shareButton)
        layoupageSubvies()
        if let imagerl = AppInfo.share().shareInfo?.cover, !imagerl.isEmpty {
             cardView.topicImage.kfSetVerticalImageWithUrl(imagerl)
        } else {
            let image = getImage("defaultShare3")
            cardView.topicImage.image = image
        }
        if let code = UserModel.share().user?.code, let office = UserModel.share().authInfo?.config?.sys?.share_url {
            let sss = office.components(separatedBy: "?")
            if sss.count > 0 {
                cardView.shareText.attributedText = TextSpaceManager.getAttributeStringWithString("掃碼或瀏覽器輸入“\(sss[0])”下載輸入我的邀請碼：\(code) 免費觀看", lineSpace: 10)
            }
        }
        loadQRcode()
        
    }
    
    @objc private func buttonClick(_ sender: UIButton) {
        if sender == saveButton {
            if let image = cardView.toImage()
            {
                AppInfo.share().uploadUserAction([UploadActionsLogApi.kEvent: UploadActionsLogApi.kSave_share])
                UIImageWriteToSavedPhotosAlbum(image, self, nil, nil)
                XSAlert.show(type: .success, text: "保存成功")
                self.dismiss(animated: false, completion: nil)
            }
        } else {
            if let image = cardView.toImage() {
                AppInfo.share().uploadUserAction([UploadActionsLogApi.kEvent: UploadActionsLogApi.kShare])
                 self.share(image)
            }
        }
    }
    
    @objc private func shareactivityDown() {
       // self.dismiss(animated: false, completion: nil)
    }

    func loadQRcode() {
        if let downloadString = UserModel.share().authInfo?.config?.sys?.share_url {
            let qrImg = ScanWrapper.createCode(codeType: "CIQRCodeGenerator", codeString: downloadString, size: CGSize(width: 200, height: 200), qrColor: UIColor.black, bkColor: UIColor.white)
            cardView.inviteCodeImg.image = qrImg
        }
    }
    
}

// MARK: - CLNavigationBarDelegate
extension ShareImageController:  CLNavigationBarDelegate  {
    
    func backAction() {
        self.dismiss(animated: false, completion: nil)
    }
}

// MARK: - Layout
private extension ShareImageController {
    func layoupageSubvies() {
        layoutNavBar()
        layoutCard()
        layoutSaveButton()
        layoutShareButton()
    }
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    func layoutShareButton() {
        shareButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-35)
            make.top.equalTo(cardView.snp.bottom).offset(35)
            make.leading.equalTo(self.view.snp.centerX).offset(10)
            make.height.equalTo(40)
        }
    }
    func layoutSaveButton() {
        saveButton.snp.makeConstraints { (make) in
            make.leading.equalTo(35)
            make.top.equalTo(cardView.snp.bottom).offset(35)
            make.trailing.equalTo(self.view.snp.centerX).offset(-10)
            make.height.equalTo(40)
        }
    }
    func layoutCard() {
        cardView.snp.makeConstraints { (make) in
            make.trailing.equalTo(-30)
            make.top.equalTo(navBar.snp.bottom).offset(50)
            make.leading.equalTo(30)
            make.bottom.equalTo(-safeAreaBottomHeight-150)
        }
    }
   
}
