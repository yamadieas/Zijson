

import Foundation


enum ModulePageType: Int, Codable {
    case Module = 1
    case H5 = 2
    case Game = 3
}

class ChannelModel: Codable {
    var id: Int?
    var title: String?
    var sort: Int?
    var `protocol`: String?
    var position: Int? // 1首页 2会员 3约炮
    
    var background: String? // topBar 背景色
    var highlight_font: String? // 选中tabbar 字体铯
    var small_font: String?
    
    /// banner背景广告图
    var cover: String?
    var cover_link: String? // banner背景广告图 跳转协议
    
    /// H5 页面
    var url: String?   // H5 页面链接
    var type: ModulePageType?    //首页 ：（1 模块 2 H5 3 游戏）-- vip模块：（1 H5 2 游戏）
    
    var created_at: String?
    var updated_at: String?
}


class ModulesModel: Codable {
    var id: Int?
    var tab_id: Int?
    var title: String?
    var module: Module?
    var pageNum: Int?  /// 当前第几页
    var limit: Int?
    var sort: Int?
    var more_link: String? //
    var `protocol`: String? //
    
    /// adBanner
    var ad_1_data: [AdHome]?
    /// adScroll
    var ad_2_data: [AdHome]?
    /// adImage
    var ad_3_data: [AdHome]?
    /// adFullWidth
    var ad_4_data: [AdHome]?
    /// longVScroll
    var video_1_data: [VideoNew]?
    /// shortVScroll
    var video_2_data: [VideoNew]?
    /// longVdouble
    var video_3_data: [VideoNew]?
    /// longV_Five
    var video_4_data: [VideoNew]?
    /// shortV_Third
    var video_5_data: [VideoNew]?
    /// waterFall
    var video_6_data: [VideoNew]?

}
enum Module: String, Codable {
    
    case ad = "ad_1"
    case adFull = "ad_4"
    case adScroll = "ad_2"
    case adImage = "ad_3"
    
    case longVScroll = "video_1"
    case shortVScroll = "video_2"
    case longVdouble = "video_3"
    case longV_Five = "video_4"
    case shortV_Third = "video_5"
    case waterFall = "video_6"
}


class UserGroupModel: Codable {
    var id: Int?
    var title: String?
    var is_attention: Int?
    var member: [CLUserInfo]?
}


class LFMsgLsModel: Codable {
    var current_page: Int?
    var data: [LFMsgModel]?
    var total: Int?
}
/// 楼凤
class LFMsgModel: Codable {
     var id: Int?
     var title: String?
     var cover: String?
     var video: String? // video screen
    
     var is_top: Int?
     var province: String?
     var city: String?
     var people: String?
     var age: String?
     
     var serving_money: [String]?
     var serving: [String]?
     var serving_intro: String?
     var quality: String?
     var milieu: String?
     
     var like_count: Int?
     var paytype: Int? // 1. 会员解锁 2. 钻石解锁 3.免费
     var coins: Int?  // 解锁钻石
     var decide_coins: Int? // 预约所需钻石数

     var is_like: Int?
     var is_look_contact: Int?
     var is_attest: Int? //是否认证
     var attest_text: String? // 认证文案
     
     var feel_count: Int?
     var comment_count: Int?
     
     var comments_data: [LFCommentModel]?
     var user_info: CLUserInfo?
     
     var images: [String]?
     var contact: String?
     var created_at: String?
     var updated_at: String?
     
     var u: String?
     ///  上架状态: 0-未上架 1-已上架
     var status: Int?
     ///  审核状态 0未审核(即审核中)1审核通过2审核失败
     var check: Int?
     var status_text: String? ///  如，楼风信息状态中文意思： 审核中
     
     var type: Int? // 1 - 2
     var isLocal: Bool?
}

class LFShopListModel: Codable {
    var ad: [AdHome]?
    var shop: [LFShopModel]?
}
class LFShopModel: Codable {
    var id: Int?
    var code: String?
    var type: Int?  //商家类型:1-经纪人 2-个人
    var contact: String?  //联系方式
    var serving_intro: String? //服务介绍
    var serving_area: String?  //服务地区
    var like_count: Int?
    var mm_count: Int?  //MM总数
    var top_mm_id: String?
    var sort: Int?
    var deposit_money: String?  //商家交的保证金
    var statu: Int? //  状态:0-禁用 1-启用
    var top_mm_info: LFMsgModel? //---首推MM信息---
    var user_info: CLUserInfo?   // 商家个人信息
    var mm_citydata: [LFLocalModel]?
}

/// 商家详情model
class LFShopDetail: Codable {
    var ad: [AdHome]?
    var shop_info: LFShopModel? // 商家信息
    var user_info: CLUserInfo?  // 商家个人信息
    var top_mm_info: LFMsgModel? // //---首推MM信息---
    var mm_citydata: [LFLocalModel]? // 地区
    var comments_data: [LFCommentModel]? // 评论列表
    
    var comment_count: Int?  // 评论数
    var is_like: Int?
    var is_look_contact: Int? // 是否可以观看联系方式
}

class LFModuleModel: Codable {
    var bulletin: String?
    var ad: [AdHome]?
    var list: [LFLocalModel]?
    var hot_city: [String]?
}

/// 楼凤 地区
class LFLocalModel: Codable {
    var province: String?   // 市
    var son_city: [LFCityModel]? // 区      // 服务地区 - 商家发布MM选择
    var search_son_city: [LFCityModel]?  //服务地区 - 普通用户筛选
}

class LFCityModel: Codable {
    var id : Int?
    var pid: Int?
    var city: String?
}

class LFCommentModel: Codable {
    var _id: String?
    var content_id: Int?
    var order_sn: String?
    var user_code: String?
    var floor_post_id: Int?
    var comment_msg: String?
    var comment_image: [String]?
    var comment_status: Int?
    var time_string: String?
    var created_at: String?
    var user_info: CLUserInfo?
    var floor_info: LFMsgModel?
    var is_author: Int?
}

class LFMsgAuthModel: Codable {
    var title: String?
    var cover : String?
    var remark: String?
}

class LFOrderModel: Codable {
    var id: Int?
    var floor_post_id: Int?
    var order_sn: String? // 订单号
    var from_code: String? //预下订单-用户邀请码
    var to_code: String? //
    var floor_post_info: SingleLfModel?
    var sub_money:String? //可抵扣金额
    var coins: Int? // 实付钻石
    //var
    var can_get_coins: Int? //发布体验后可得钻石
    var status: Int? // 1预约成功 2已退款(即取消了-后台控制)
    var is_finish: Int? // 是否发布体验：0-未发布 1-已发布
    var created_at: String? // 发布时间
    var updated_at: String? // 更新时间
    var is_reimburse: Int?
    var can_get_coins_text: String?  //发布体验后可得钻石-详细文字信息
    var user_info: CLUserInfo?
    var order_status_text: String? // 订单状态的文案意思
}
class SingleLfModel: Codable {
    var id: Int?
    var cover: String?
    var place: String?
    var title: String?
    var serving_money: String?
}






/** ------------------------------- 废弃 --------------------------------------*/
struct PictureKey: Codable {
    var images_type: String?
}

class PictureLsModel: Codable {
    var current_page: Int?
    var data: [PictureModel]?
    var total: Int?
}
class PictureModel: Codable {
    var id: Int?
    var source_title: String?
    var source_images_type: String?
    var like_count: Int?
    var cover: String?
    var coins: Int?
    var is_like: Int?
    
    var is_free_all: Int?
    var free_count: String?
    var images: [String]?
    var all_count: Int?
}
/** ---------------------------------------------------------------------*/
