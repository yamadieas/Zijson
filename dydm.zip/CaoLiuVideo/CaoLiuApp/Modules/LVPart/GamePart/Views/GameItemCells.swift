
import UIKit

class GameItemCell: UICollectionViewCell {
    
    static let cellId = "GameItemCell"
    static let itemSizeDouble = CGSize(width: (screenWidth - 40)/2, height: (screenWidth - 40)/2*9/16 + 30)
   
    let shadowV: UIView = {
        let v = UIView()
        v.backgroundColor = .clear
        v.layer.cornerRadius = 8
        return v
    }()
    let coverImg: UIImageView = {
        let v = UIImageView()
        v.backgroundColor = .clear
        v.contentMode = .scaleAspectFill
        v.borderRadius = 10
        return v
    }()
    let dimonLab: UILabel = {
        let la = UILabel()
        la.textColor = .white
        la.textAlignment = .center
        la.font = UIFont.boldSystemFont(ofSize: 11)
        return la
    }()
    let dimondTipView: UIView = {
        let v = UIView()
        v.backgroundColor = rgb(255, 0, 32)
        v.isHidden = true
        return v
    }()
    let desLab: UILabel = {
        let la = UILabel()
        la.textColor = .white
        la.font = UIFont.boldSystemFont(ofSize: 14)
        return la
    }()
   
    let coverLayer: CAGradientLayer = {
        let ly = CAGradientLayer()
        ly.colors = [UIColor.clear.cgColor, UIColor(white: 0.0, alpha: 0.6).cgColor]
        ly.locations = [0.75, 1.0]
        return ly
    }()
    var avataClickHandler:(() ->Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = .clear
        backgroundColor = .clear
        contentView.addSubview(shadowV)
        shadowV.addSubview(coverImg)
        shadowV.addSubview(dimondTipView)
        dimondTipView.addSubview(dimonLab)
        shadowV.addSubview(desLab)
        layoutSubs()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @objc func avartarClick() {
        avataClickHandler?()
    }
    
    func setModel(_ model: GameListModel) {
        coverImg.kfSetHorizontalImageWithUrl(model.image)
        desLab.text = model.name
        if let tag = model.tag, !tag.isEmpty {
            dimondTipView.isHidden = false
            dimonLab.text = tag
            dimondTipView.backgroundColor = rgb(231, 25, 29)
            let size = dimonLab.textSize(text: dimonLab.text ?? "", font: dimonLab.font, maxSize: CGSize(width: 200, height: 24))
            dimondTipView.bounds = CGRect(x: 0, y: 0, width: size.width + 15, height: 24)
            dimondTipView.snp.updateConstraints { (make) in
                make.width.equalTo(size.width + 15)
            }
            dimondTipView.corner(byRoundingCorners: [.topRight, .bottomLeft], radii: 10)
        } else {
            dimondTipView.isHidden = true
        }
    }
    private func layoutSubs() {
        shadowV.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        coverImg.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo((screenWidth-40)/2*9/16)
        }
    
        dimonLab.snp.makeConstraints { (make) in
            make.leading.equalTo(6)
            make.trailing.equalTo(-6)
            make.centerY.equalToSuperview()
        }
        dimondTipView.snp.makeConstraints { (make) in
            make.trailing.top.equalToSuperview()
            make.width.equalTo(45)
            make.height.equalTo(24)
        }
        desLab.snp.makeConstraints { (make) in
            make.leading.equalTo(2)
            make.trailing.equalTo(-2)
            make.top.equalTo(coverImg.snp.bottom).offset(8)
        }
    }
    
}


class GameChargeHeaderView: UICollectionReusableView {
    static let identifier = "GameChargeHeaderView"
    static let headerSizeSg = CGSize(width: screenWidth, height: 55)
    let yuETipLable: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.systemFont(ofSize: 12)
        lab.textColor = .lightGray
        lab.text = "游戏余额："
        return lab
    }()
    let yuELable: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.boldSystemFont(ofSize: 20)
        lab.textColor = .white
        lab.text = "¥0.00"
        return lab
    }()
    let chargeTipLable: UILabel = {
        let lab = UILabel(frame: CGRect(x: 0, y: 0, width: 40, height: 18))
        lab.font = UIFont.boldSystemFont(ofSize: 11)
        lab.textColor = .white
        lab.textAlignment = .center
        lab.backgroundColor = rgb(255, 0, 32)
        lab.text = "送VIP"
        return lab
    }()
    let registTipLable: UILabel = {
        let lab = UILabel(frame: CGRect(x: 0, y: 0, width: 40, height: 18))
        lab.font = UIFont.boldSystemFont(ofSize: 11)
        lab.textColor = .white
        lab.textAlignment = .center
        lab.backgroundColor = rgb(255, 0, 32)
        lab.text = "送3元"
        return lab
    }()
    lazy var chargeBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitle("充值", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        btn.backgroundColor = rgb(30, 65, 255)
        btn.borderRadius = 6
        btn.addTarget(self, action: #selector(itemClick(_:)), for: .touchUpInside)
        return btn
    }()
    lazy var cashBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitle("提现", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        btn.backgroundColor = rgb(30, 65, 255)
        btn.borderRadius = 6
        btn.addTarget(self, action: #selector(itemClick(_:)), for: .touchUpInside)
        return btn
    }()
    lazy var registBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitle("注册", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        btn.backgroundColor = rgb(30, 65, 255)
        btn.borderRadius = 6
        btn.addTarget(self, action: #selector(itemClick(_:)), for: .touchUpInside)
        return btn
    }()
    var buttonTapHandler:((_ id: Int) -> Void)?
    
    var gameSend: Bool = false
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initialize()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initialize()
    }
    private func initialize() {
        backgroundColor = ConstValue.kVcViewColor
        addSubview(registBtn)
        addSubview(registTipLable)
        addSubview(yuETipLable)
        addSubview(yuELable)
        addSubview(cashBtn)
        addSubview(chargeBtn)
        addSubview(chargeTipLable)
        layoutSegViews()
        chargeTipLable.corner(byRoundingCorners: [.topLeft,.topRight, .bottomRight], radii: 9)
        registTipLable.corner(byRoundingCorners: [.topLeft,.topRight, .bottomRight], radii: 9)
    }
    @objc func itemClick(_ sender: UIButton) {
        if sender == cashBtn {
            buttonTapHandler?(2)
        } else if sender == chargeBtn {
            buttonTapHandler?(1)
        } else if sender == registBtn {
            buttonTapHandler?(3)
        }
    }
    func setGameSend(_ send: Bool) {
        gameSend = send
        registBtn.isHidden = !gameSend
        cashBtn.snp.updateConstraints { make in
            make.trailing.equalTo(gameSend ? -95 : -15)
        }
    }
    
    private func layoutSegViews() {
        yuELable.snp.makeConstraints { (make) in
            make.bottom.equalTo(-8)
            make.leading.equalTo(15)
            make.height.equalTo(20)
        }
        yuETipLable.snp.makeConstraints { (make) in
            make.bottom.equalTo(yuELable.snp.top).offset(-5)
            make.leading.equalTo(15)
            
        }
        registBtn.snp.makeConstraints { make in
            make.trailing.equalTo(-15)
            make.bottom.equalTo(-8)
            make.width.equalTo(70)
            make.height.equalTo(32)
        }
        registTipLable.snp.makeConstraints { (make) in
            make.trailing.equalTo(registBtn)
            make.bottom.equalTo(registBtn.snp.top).offset(5)
            make.height.equalTo(18)
            make.width.equalTo(40)
        }
        cashBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(gameSend ? -95 : -15)
            make.bottom.equalTo(-8)
            make.width.equalTo(70)
            make.height.equalTo(32)
        }
        chargeBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(cashBtn)
            make.trailing.equalTo(cashBtn.snp.leading).offset(-10)
            make.height.equalTo(32)
            make.width.equalTo(70)
        }
        chargeTipLable.snp.makeConstraints { (make) in
            make.trailing.equalTo(chargeBtn)
            make.bottom.equalTo(chargeBtn.snp.top).offset(5)
            make.height.equalTo(18)
            make.width.equalTo(40)
        }
    }
}

class GameCardTopView: UICollectionReusableView {
    
    static let reuseId = "GameCardTopView"
    static let height: CGFloat = 105.0
    
    let bgContentV: UIView = {
        let image = UIView()
        image.layer.cornerRadius = 15
        image.layer.masksToBounds = true
        image.backgroundColor = UIColor.colorGradientChangeWithSize(size: CGSize(width: screenWidth - 30, height: 100), direction: .level, startColor: rgb(119, 60, 245), endColor: rgb(160, 132, 247))
        return image
    }()
    let earnAllLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.white
        label.font = UIFont.boldSystemFont(ofSize: 21)
        label.text = "¥0.00"
        return label
    }()
    let earnAlltipLable: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.font = UIFont.systemFont(ofSize: 13)
        label.text = "当前余额"
        return label
    }()
    lazy var detailBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("资金明细", for: .normal)
        button.backgroundColor = UIColor.darkText
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 12)
        button.borderRadius = 16.5
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    var btnClickHandler:((_ actionId: Int)->Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = ConstValue.kVcViewColor
        addSubview(bgContentV)
        bgContentV.addSubview(earnAlltipLable)
        bgContentV.addSubview(earnAllLabel)
        bgContentV.addSubview(detailBtn)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    @objc func buttonClick(_ sender: UIButton) {
        tapScaleDownAnimation(sender)
        btnClickHandler?(0)
    }
    func layoutPageSubviews() {
        bgContentV.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.height.equalTo(100)
        }
        earnAlltipLable.snp.makeConstraints { (make) in
            make.leading.equalTo(35)
            make.bottom.equalTo(bgContentV.snp.centerY).offset(-5)
        }
        earnAllLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(earnAlltipLable)
            make.top.equalTo(earnAlltipLable.snp.bottom).offset(8)
        }
        detailBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-25)
            make.centerY.equalToSuperview()
            make.height.equalTo(33)
            make.width.equalTo(80)
        }
    }
}

class GamePayProblemTipCell : UICollectionViewCell {
    
    static let cellId = "GamePayProblemTipCell"
    
    let textLable: UILabel = {
        let lab = UILabel()
        lab.textAlignment = .center
        lab.font = UIFont.systemFont(ofSize: 13)
        lab.textColor = .white
        lab.text = "付款未到账？联系在线客服"
        return lab
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = .clear
        backgroundColor = .clear
        contentView.addSubview(textLable)

        textLable.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.leading.equalTo(10)
            make.trailing.equalTo(-10)
        }
        let text = "付款未到账？联系在线客服"
        let attributeText = NSMutableAttributedString(string: text, attributes: [NSAttributedString.Key.font:UIFont.pingFangSemibold(size: 13),NSAttributedString.Key.foregroundColor:UIColor.white])
        let range = text.range(of: "联系在线客服")
        attributeText.addAttributes([NSAttributedString.Key.underlineStyle:NSUnderlineStyle.thick.rawValue,NSAttributedString.Key.foregroundColor: ConstValue.kStypeColor,NSAttributedString.Key.underlineColor:ConstValue.kStypeColor], range: NSRange(range!, in: text))
        self.textLable.attributedText = attributeText
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}


class GameCardCollCell: UICollectionViewCell {
    static let cellId = "GameCardCollCell"
    static let itemSize = CGSize(width: (screenWidth - 50)/3, height: (screenWidth - 50)/3)
    let cardName: UILabel = {
        let lab = UILabel()
        lab.textColor = .white
        lab.textAlignment = .center
        lab.font = UIFont.boldSystemFont(ofSize: 16)
        return lab
    }()
    let infoMsgLabel: UILabel = {
        let lab = UILabel()
        lab.textColor = .white
        lab.textAlignment = .center
        lab.font = UIFont.systemFont(ofSize: 13)
        return lab
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        contentView.backgroundColor = ConstValue.kCoverBgColor
        contentView.borderRadius = 10.0
        contentView.borderWidth = 1.0
        contentView.addSubview(cardName)
        contentView.addSubview(infoMsgLabel)
        layoutPages()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setVipCardModel(_ model: VipCardModel) {
        cardName.text = "\(model.title ?? "")"
        infoMsgLabel.text = model.intro
    }
    func layoutPages() {
        cardName.snp.makeConstraints { (make) in
            make.bottom.equalTo(contentView.snp.centerY).offset(-5)
            make.leading.equalTo(10)
            make.trailing.equalTo(-10)
        }
        infoMsgLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(8)
            make.trailing.equalTo(-8)
            make.top.equalTo(cardName.snp.bottom).offset(10)
        }
    }
    
}
