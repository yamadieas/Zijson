
import UIKit
import NicooNetwork
import AlipaySDK

class GameChargeController: CLBaseViewController {
    
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.titleLabel.text = "我的钱包"
        bar.titleLabel.textColor = UIColor.white
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    private let layout = UICollectionViewFlowLayout()
    lazy var collView: UICollectionView = {
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsVerticalScrollIndicator = false
        collection.backgroundColor = ConstValue.kVcViewColor
        collection.register(GameCardCollCell.classForCoder(), forCellWithReuseIdentifier: GameCardCollCell.cellId)
        collection.register(PayTypeCollCell.classForCoder(), forCellWithReuseIdentifier: PayTypeCollCell.cellId)
        collection.register(GamePayProblemTipCell.classForCoder(), forCellWithReuseIdentifier: GamePayProblemTipCell.cellId)
        collection.register(GameCardTopView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: GameCardTopView.reuseId)
        collection.register(SearchNoDataHeader.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: SearchNoDataHeader.reuseId)
        
        return collection
    }()
    private lazy var recordBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("充值记录", for: .normal)
        button.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        button.setTitleColor(.white, for: .normal)
        button.addTarget(self, action: #selector(recordBtnBtnClick(_:)), for: .touchUpInside)
        return button
    }()
    private lazy var payBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.setTitle("立即支付", for: .normal)
        button.borderRadius = 24.0
        button.backgroundColor = UIColor.colorGradientChangeWithSize(size: CGSize(width: screenWidth - 50, height: 48), direction: .level, startColor: rgb(247, 219, 172), endColor: rgb(223, 180, 127))
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        button.setTitleColor(.darkText, for: .normal)
        button.addTarget(self, action: #selector(payBtnBtnClick(_:)), for: .touchUpInside)
        button.isHidden = true
        return button
    }()
  
    private lazy var gameCardApi: GameCardsApi = {
        let api = GameCardsApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    private lazy var orderAddApi: UserOrderAddApi = {
        let api = UserOrderAddApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    var banlance: String?
    var backLaunchAdViewController:(() ->Void)?
    var vipCards = [VipCardModel]()
    var currentPayType: PayTypeModel?
    var selectedIndex: Int = 0
    let viewModel = VideoViewModel()
    var payTypes: [PayTypeModel]?
    var paySelectedIndex: Int = 0
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(navBar)
        navBar.navBarView.addSubview(recordBtn)
        view.addSubview(collView)
        layoutPages()
        loadData()
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        if let vcs = navigationController?.viewControllers, vcs.contains(self) {
            DLog("viewDidDisappear --- Push or Present")
        } else {
            DLog("viewDidDisappear --- Pop or Dimiss")
            backLaunchAdViewController?()
        }
    }
    @objc func recordBtnBtnClick(_ sender: UIButton) {
        let payRecordVC = PayRecordController()
        payRecordVC.isGame = true
        navigationController?.pushViewController(payRecordVC, animated: true)
    }
    @objc func payBtnBtnClick(_ sender: UIButton) {
        addOrder()
    }
    private func loadData() {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        _ = gameCardApi.loadData()
    }
    private func addOrder() {
        if currentPayType == nil {
            XSAlert.show(type: .error, text: "請选择支付方式")
            return
        }
        XSProgressHUD.showCycleProgress(msg: "提交訂單...", onView: view, animated: false)
        let _ = orderAddApi.loadData()
    }
    /// 支付
    private func goAlipay(_ orderModel: OrderAddModel) {
        
        guard let payUrl = orderModel.link else { return }
        let vc = PayWaitController()
        vc.orderInfo = orderModel.order_info ?? OrderInfoMsg()
        if vipCards.count > selectedIndex {
            vc.amount = vipCards[selectedIndex].price
        }
        navigationController?.pushViewController(vc, animated: true)
        if payUrl.isEmpty { return }
        
        if orderModel.type == .url {
            if let url = URL(string: payUrl) {
                if #available(iOS 10, *) {
                    UIApplication.shared.open(url, options: [:], completionHandler: { (success) in
                    })
                } else {
                    UIApplication.shared.openURL(url)
                }
            }
        } else if orderModel.type == .alipaySDK {
            AlipaySDK.defaultService()?.payOrder(payUrl, fromScheme: "DYGame", callback: { (result) in
                if result != nil {
                    if let code = result!["resultStatus"] as? String {
                        if code == "9000" {
                            XSAlert.show(type: .success, text: "支付成功，请返回个人中心查看")
                        }
                    }
                }
            })
        } else if orderModel.type == .wechatSDK {
            if let data = payUrl.data(using: .utf8) {
                if let json = dataToJSON(data: data) {
                    if let appid = json["appid"] as? String,
                        let noncestr = json["noncestr"] as? String,
                        let partnerid = json["partnerid"] as? String,
                        let prepayId = json["prepayid"] as? String,
                        let timestamp = json["timestamp"] as? UInt32,
                        let package = json["package"] as? String ,
                        let sign = json["sign"] as? String
                    {
                        let paramer: String = String(format: "nonceStr=%@&package=%@&partnerId=%@&prepayId=%@&timeStamp=%d&sign=%@&signType=%@", noncestr,package,partnerid,prepayId,timestamp,sign,"SHA1")
                        let openUrl: String = String(format: "%@app/%@/pay/?%@", "weixin://",appid,paramer)
                        if let url = URL(string: openUrl) {
                            if #available(iOS 10, *) {
                                UIApplication.shared.open(url, options: [:],
                                                          completionHandler: {
                                                            (success) in
                                })
                            } else {
                                UIApplication.shared.openURL(url)
                            }
                        }
                    }
                }
            }
        }
    }
    /// 充值系统繁忙提示
    private func showServerWarningAlert(msg: String) {
        let alert = UIAlertController(title: "支付提示", message: "\r\(msg)", preferredStyle: .alert)
        let cancle = UIAlertAction(title: "好的", style: .cancel, handler: nil)
        alert.addAction(cancle)
        alert.modalPresentationStyle = .fullScreen
        self.present(alert, animated: true, completion: nil)
    }
    /// 联系管理员充值
    private func goToServerVerb() {
        if let url = URL(string: AppInfo.share().appInfo?.potato_invite_link ?? "") {
            if #available(iOS 10, *) {
                UIApplication.shared.open(url, options: [:], completionHandler: { (success) in
                })
            } else {
                UIApplication.shared.openURL(url)
            }
        }
    }
    
}
// MARK: - UICollectionViewDelegateFlowLayout
extension GameChargeController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if indexPath.section == 0 {
            return GameCardCollCell.itemSize
        } else if indexPath.section == 1 {
            return CGSize(width: screenWidth, height: 50)
        } else if indexPath.section == 2 {
            return CGSize(width: screenWidth, height: 50)
        }
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        if section == 0 {
            return 10
        }
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        if section == 0 {
            return 10
        }
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if section == 0 {
            return UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
        } else if section == 1{
            return .zero
        } else if section == 2 {
            return UIEdgeInsets(top:15, left: 15, bottom: 15, right: 15)
        }
        return .zero
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 0 {
            return CGSize(width: screenWidth, height: 130)
        }
        return .zero
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForFooterInSection section: Int) -> CGSize {
        return .zero
    }
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionHeader {
            let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: GameCardTopView.reuseId, for: indexPath) as! GameCardTopView
            headerView.earnAllLabel.text = "¥\(banlance ?? "0.00")"
            headerView.btnClickHandler = { [weak self] _ in
                let vc = CoinDetailController()
                vc.type = 2
                self?.navigationController?.pushViewController(vc, animated: true)
            }
            return headerView
        } else {
            let footer = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: SearchNoDataHeader.reuseId, for: indexPath) as! SearchNoDataHeader
            footer.label.textColor = .red
            footer.label.font = UIFont.systemFont(ofSize: 12)
            footer.label.text = "(小提示：充值成功后，请联系客服领取VIP兑换码)"
            return footer
        }
    }
}
// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension GameChargeController: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 3
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return vipCards.count
        } else if section == 1 {
            return 0
        } else if section == 2 {
            return 1
        }
        return .zero
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: GameCardCollCell.cellId, for: indexPath) as! GameCardCollCell
            let model = vipCards[indexPath.item]
            cell.setVipCardModel(model)
            if indexPath.item == selectedIndex {
                cell.contentView.bordercolor = ConstValue.kStypeColor
            } else {
                cell.contentView.bordercolor  = UIColor.clear
            }
            return cell
        } else if indexPath.section == 1 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PayTypeCollCell.cellId, for: indexPath) as! PayTypeCollCell
            if let pay = payTypes?[indexPath.item] {
                cell.setModel(pay)
                if indexPath.item == paySelectedIndex {
                    cell.selectedBtn.isSelected = true
                } else {
                    cell.selectedBtn.isSelected = false
                }
            }
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: GamePayProblemTipCell.cellId, for: indexPath) as! GamePayProblemTipCell
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if indexPath.section == 0 {
            selectedIndex = indexPath.item
            collView.reloadData()
            let vipCard = vipCards[indexPath.item]
            if let payTypes = vipCard.payment, payTypes.count > 0 {
                let controller = PayTypeChoseController()
                controller.payTypes = payTypes
                controller.card = vipCard
                controller.modalPresentationStyle = .overCurrentContext
                self.modalPresentationStyle = .currentContext
                self.present(controller, animated: false, completion: nil)
                controller.payActionHandler = { model in
                    self.currentPayType = model
                    self.addOrder()
                    controller.dismiss(animated: false, completion: nil)
                }
            } else {
                XSAlert.show(type: .error, text: "当前金额没有可支付的通道")
            }
        }
        else if indexPath.section == 2 {
            let chat = ChartController()
            navigationController?.pushViewController(chat, animated: true)
        }
    }
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension GameChargeController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        if manager is UserOrderAddApi {
            var params = [String: Any]()
            params[UserOrderAddApi.kVc_id] = vipCards[selectedIndex].id
            if currentPayType != nil {
                params[UserOrderAddApi.kPay_id] = currentPayType!.id ?? ""
                params[VipCardsApi.kOrderType] = 4
            }
            return params
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is GameCardsApi {
            if let cardList = manager.fetchJSONData(UserReformer()) as? [VipCardModel] {
                vipCards = cardList
                if vipCards.count > 0 {
                    payTypes = vipCards[0].payment
                }
                selectedIndex = 0
                if (payTypes?.count ?? 0) > 0 {
                    paySelectedIndex = 0
                    currentPayType = payTypes![paySelectedIndex]
                }
                collView.reloadData()
            }
        }
        
        if manager is UserOrderAddApi {
            payBtn.isEnabled = true
            if let orderModel = manager.fetchJSONData(UserReformer()) as? OrderAddModel {
                if orderModel.link != nil {
                    goAlipay(orderModel)
                } else {
                    showServerWarningAlert(msg: "付款链接不正确")
                }
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        if manager is VipCardsApi {
            NicooErrorView.showErrorMessage(.noData, "暂无钻石套餐", on: view, topMargin: safeAreaTopHeight + 140) {
                self.loadData()
            }
        }
        if manager is UserOrderAddApi {
            payBtn.isEnabled = true
            showServerWarningAlert(msg: manager.errorMessage)
        }
    }
}
// MARK: - CLNavigationBarDelegate
extension GameChargeController:  CLNavigationBarDelegate  {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

extension GameChargeController {
    func layoutPages() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
     
        layoutRecordBtn()
//        payBtn.snp.makeConstraints { (make) in
//            make.leading.equalTo(25)
//            make.trailing.equalTo(-25)
//            make.bottom.equalTo( -safeAreaBottomHeight-20)
//            make.height.equalTo(48)
//        }
        collView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom)
            make.bottom.equalTo(-safeAreaBottomHeight)
        }
    }
    func layoutRecordBtn() {
        recordBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-12)
            make.centerY.equalToSuperview()
            make.width.equalTo(65)
            make.height.equalTo(35)
        }
    }
}
