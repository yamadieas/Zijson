//
//  GameModels.swift
//  KouWoPJ
//
//  Created by mac on 22/3/2021.
//  Copyright © 2021 AnakinChen Network Technology. All rights reserved.
//

import Foundation
import NicooNetwork

class GamePageModel: Codable {
    var ad: [AdHome]?
    var balance: String?
    /// 是否显示游戏绑定
    var game_is_open_bind: StrInt?
    /// 绑定后送多少钱
    var game_bind_money: StrInt?
    /// 当前用户是否已绑定
    var user_is_bind_game: StrInt?
    var list: [GameListModel]?
}

class GameListModel: Codable {
    var _id: Int?
    var name: String?
    var code: String?
    var category_code: String?
    var sort: Int?
    var is_recommend: Int?
    var image: String?
    var tag: String?
    var config: String?
    var is_disabled: Int?
    
    /// 游戏详情
    var type: String?
    var url: String?
    var keepalive_time: String? // 心跳包间隔时间
}





