//
//  GameApis.swift
//  KouWoPJ
//
//  Created by mac on 22/3/2021.
//  Copyright © 2021 AnakinChen Network Technology. All rights reserved.
//

import Foundation
import NicooNetwork

//MARK: - 游戏列表
class GameListApi: XSVideoBaseAPI {
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/game/module"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: -游戏充值卡 列表
class GameCardsApi: XSVideoBaseAPI {
    
    static let kOrderType = "order_type"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/game/price/list"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: -游戏详情
class GameDetailApi: XSVideoBaseAPI {
    
    static let kCode = "code"
    static let kDevice_type = "device_type"
    static let kDevice_info = "device_info"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/game/enter"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}


//MARK: -游戏操作
class GameActionApi: XSVideoBaseAPI {
    
    static let kAction = "action"
    
    static let kExit = "exit"
    static let kPing = "ping"
    
    var isExit: Bool = false
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/game/action"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}
