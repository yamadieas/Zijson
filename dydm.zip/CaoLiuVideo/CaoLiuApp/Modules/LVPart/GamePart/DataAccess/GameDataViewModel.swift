

import Foundation
import NicooNetwork

class GameDataViewModel: NSObject {
    
    var timerHodler = TipTimerMg()
    
    var params: [String: Any]?
    
    lazy var detailApi: GameDetailApi = {
        let a = GameDetailApi()
        a.paramSource = self
        a.delegate = self
        return a
    }()
    lazy var actionApi: GameActionApi = {
        let a = GameActionApi()
        a.paramSource = self
        a.delegate = self
        return a
    }()
    
    private var detailSuccessBlock: ((GameListModel) -> Void)?
    private var successBlock:((_ num: String) ->Void)?
    private var errorBlock: ((String) -> Void)?
    
    func loadGameDetailData(params: [String: Any]?,success: ((GameListModel) -> Void)?, failure: ((_ error: String) -> Void)?) {
        self.params = params
        detailSuccessBlock = success
        errorBlock = failure
        if !detailApi.isLoading {
            _ = detailApi.loadData()
        }
        
    }
    func loadGameActionData(params: [String: Any]?,success: ((_ b: String) -> Void)?, failure: ((_ error: String?) -> Void)?) {
        self.params = params
        if let action = params?[GameActionApi.kAction] as? String {
            actionApi.isExit = action == GameActionApi.kExit
        }
        successBlock = success
        errorBlock = failure
        if !actionApi.isLoading {
            _ = actionApi.loadData()
        }
    }
    
}
// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension GameDataViewModel: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        return params
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
       
        if manager is GameDetailApi {
            if let game = manager.fetchJSONData(UserReformer()) as? GameListModel {
               detailSuccessBlock?(game)
            }
        }
        if manager is GameActionApi {
            if actionApi.isExit {
                if let content = manager.response.content as? [String : Any],let data = content["data"] as? String {
                    if ConstValue.kIsEncryptoApi {
                        guard let encryptKey = ConstValue.kAllEncryptKeys[AppInfo.share().handShake!] as? String else {
                            DLog("没有找到可以使用的密钥 +++ 3,当作不加密处理")
                            return
                        }
                        let decodResultString = data.urlDecoded()
                        if !decodResultString.isEmpty {
                            if let decryptString = decodResultString.aes128DecryptString(withKey: encryptKey) {
                                successBlock?(decryptString.replacingOccurrences(of: "\"", with: ""))
                            }
                        } else {
                            successBlock?("0.00")
                        }
                    } else {
                        successBlock?(data)
                    }
                }
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        errorBlock?(manager.errorMessage)
    }
}

// MARK: - Layout
private extension GameListControlller {
    
    func layoutPageSubviews() {
        layoutCollection()
    }
    func layoutCollection() {
        collView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview().offset(0)
        }
    }
    
}
