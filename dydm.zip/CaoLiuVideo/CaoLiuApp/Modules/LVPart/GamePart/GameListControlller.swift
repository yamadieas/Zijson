

import UIKit
import MJRefresh
import NicooNetwork
import JXSegmentedView

extension GameListControlller: JXSegmentedListContainerViewListDelegate {
    func listView() -> UIView {
        return self.view
    }
}

class GameListControlller: UIViewController {
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.backgroundColor = ConstValue.kVcViewColor
        bar.navBackBlack = false
        bar.delegate = self
        bar.titleLabel.text = "游戏"
        return bar
    }()
    private let layout = UICollectionViewFlowLayout()
    lazy var collView: UICollectionView = {
        layout.sectionHeadersPinToVisibleBounds = true
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsVerticalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(BannerScrollCellNormal.classForCoder(), forCellWithReuseIdentifier: BannerScrollCellNormal.cellId)
        collection.register(GameItemCell.classForCoder(), forCellWithReuseIdentifier: GameItemCell.cellId)
        collection.register(GameChargeHeaderView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: GameChargeHeaderView.identifier)
        collection.mj_header = refreshView
        return collection
    }()
    lazy private var refreshView: MJRefreshNormalHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshNormalHeader(refreshingBlock: {
            weakSelf?.loadFirstPage()
        })
        mjRefreshHeader?.activityIndicatorViewStyle = .white
        mjRefreshHeader?.arrowView.image = ConstValue.refreshImg
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    private lazy var listApi: GameListApi =  {
        let api = GameListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    lazy var detailApi: GameDetailApi = {
        let a = GameDetailApi()
        a.paramSource = self
        a.delegate = self
        return a
    }()
    var cityHeader: CityChoseTipView?

    let viewModel = GameDataViewModel()
    
    /// 游戏所在位置，默认为独立页面
    var position: VCPosition = .OnePage
    var segIndex: Int = 0
    
    var gameModel = GamePageModel()
    var ads = [AdHome]()
    var gameList = [GameListModel]()
    
    var currentProvince: String?
    var currentCity: String?
    var userCode: String?
    
    var isShop: Bool = true
    
    var isFavor: Bool = false
    
    var firstIn: Bool = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if position != .OnePage || position != .InTabar {
            if #available(iOS 11.0, *) {
                collView.contentInsetAdjustmentBehavior = .never
            } else {
                self.automaticallyAdjustsScrollViewInsets = false
            }
        }
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(collView)
        if position == .OnePage || position == .InTabar {
            view.addSubview(navBar)
            if position == .OnePage {
                navBar.backButton.isHidden = false
            } else if position == .InTabar {
                navBar.backButton.isHidden = true
            }
        }
        layoutPageSubviews()
        loadData()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if position == .InVIPPart {
            NotificationCenter.default.post(name: Notification.Name.kVIPTopBarColotNotification, object: nil, userInfo: ["TopBarDarkColor": 0])
        } else if position == .InModule {
            NotificationCenter.default.post(name: Notification.Name.kMainTopBarColotNotification, object: nil, userInfo: ["AutoTopBarBgColor": 1, "SegIndex" :segIndex, "OffSetY" : Int(collView.contentOffset.y)])
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if position == .InVIPPart {
            collView.frame = CGRect(x: 0, y: statusBarHeight + 44, width: screenWidth, height: screenHeight - statusBarHeight - 94 - safeAreaBottomHeight)
        } else if position == .InModule {
            collView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight - safeAreaBottomHeight - 137 - statusBarHeight)
        } else if position == .InYuePa {
            collView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight - 93 - statusBarHeight - safeAreaBottomHeight)
        }
    }
    private func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = listApi.loadData()
    }
    private func loadFirstPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = listApi.loadData()
    }
    private func endRefreshing() {
        refreshView.endRefreshing()
    }
    
    private func goGameDetail(_ gameModel: GameListModel) {
        if let adHref = URL(string: gameModel.url ?? "") {
            let aavc = GameWebController(url: adHref)
            aavc.gameModel = gameModel
            aavc.gameExitCallBack = { [weak self]  b in
                self?.gameModel.balance = "\(b)"
                self?.collView.reloadData()
            }
            navigationController?.pushViewController(aavc, animated: false)
        }
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension GameListControlller: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if indexPath.section == 0 {
            return ads.count > 0 ? BannerScrollCellNormal.itemSize : .zero
        }
        return GameItemCell.itemSizeDouble
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if section == 0 {
            return UIEdgeInsets(top: 5, left: 0, bottom: 5, right: 0)
        }
        if section == 1 {
            return UIEdgeInsets(top: 5, left: 15, bottom: 8, right: 15)
        }
        return .zero
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        if section == 1 {
            return isFavor ? .zero : CGSize(width: screenWidth, height: 60)
        }
        return .zero
    }
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: GameChargeHeaderView.identifier, for: indexPath) as! GameChargeHeaderView
        header.setGameSend(gameModel.game_is_open_bind?.int == 1)
        if (gameModel.game_bind_money?.int ?? 0) > 0 {
            header.registTipLable.isHidden = gameModel.game_is_open_bind?.int == 1 ? false : true
            header.registTipLable.text = "送\(gameModel.game_bind_money?.int ?? 0)元"
        } else {
            header.registTipLable.isHidden = true
        }
        
        header.yuELable.text = "¥\(gameModel.balance ?? "0.00")"
        header.buttonTapHandler = { [weak self] id in
            if id == 1 {
                let vc = GameChargeController()
                vc.banlance = self?.gameModel.balance
                self?.navigationController?.pushViewController(vc, animated: true)
            } else if id == 2 {
                if let urlstr = UserModel.share().authInfo?.config?.rule?.game_withdraw_h5,
                   !urlstr.isEmpty {
                    self?.goInnerLink("urlself://\(urlstr)?balance=\(self?.gameModel.balance ?? "0.00")","game_withdraw")
                }
            } else if id == 3 {
                if self?.gameModel.user_is_bind_game?.int == 1 {
                    self?.showNearDialog(redTitle: "注册提示", message: "您已经注册过手机号码,请勿重复注册", okTitle: "好的", cancelTitle: nil, okHandler: {
                    }, cancelHandler: {
                        
                    })
                } else {
                    let vc = GameVerbPhoneController()
                    vc.refreshGameBalanceBlock = { [weak self] in
                        self?.loadData()
                    }
                    self?.navigationController?.pushViewController(vc, animated: true)
                }
            }
        }
        return header
    }
}
// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension GameListControlller: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return ads.count > 0 ? 1 : 0
        } else if section == 1 {
            return gameList.count
        }
        return 0
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: BannerScrollCellNormal.cellId, for: indexPath) as! BannerScrollCellNormal
            cell.setBanner(ads)
            cell.scrollItemClickHandler = { [weak self] index in
                guard let strongSelf = self else { return }
                if strongSelf.ads.count > index {
                    self?.goInnerLink(strongSelf.ads[index].link ?? "",strongSelf.ads[index].position)
                }
            }
            return cell
        } else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: GameItemCell.cellId, for: indexPath) as! GameItemCell
            let model = gameList[indexPath.item]
            cell.setModel(model)
            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        let model = gameList[indexPath.item]
        if indexPath.section == 1 {
            viewModel.loadGameDetailData(params: [GameDetailApi.kCode : model.code ?? "",GameDetailApi.kDevice_type: "ios", GameDetailApi.kDevice_info : UIDevice.current.iosType()]) { [weak self] (gmodel) in
                model.url = gmodel.url
                self?.goGameDetail(model)
            } failure: { (error) in
                XSAlert.show(type: .text, text: error)
            }
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension GameListControlller: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        endRefreshing()
        if manager is GameListApi {
            if let game = manager.fetchJSONData(UserReformer()) as?  GamePageModel {
                gameModel = game
                if let ads = game.ad {
                    self.ads = ads
                }
                if let games = game.list {
                    self.gameList = games
                }
                collView.reloadData()
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        endRefreshing()
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
    }
}

// MARK: - Layout
private extension GameListControlller {
    
    func layoutPageSubviews() {
        layoutCollection()
    }
    func layoutCollection() {
        if position == .OnePage || position == .InTabar {
            navBar.snp.makeConstraints { (make) in
                make.leading.trailing.top.equalToSuperview()
                make.height.equalTo(safeAreaTopHeight)
            }
            collView.snp.makeConstraints { (make) in
                make.top.equalTo(navBar.snp.bottom)
                make.leading.trailing.equalToSuperview()
                if position == .InTabar {
                    make.bottom.equalTo(-safeAreaBottomHeight - 49)
                } else {
                    make.bottom.equalTo(-safeAreaBottomHeight)
                }
            }
        } else {
            collView.snp.makeConstraints { (make) in
                make.top.equalToSuperview()
                make.leading.trailing.equalToSuperview()
                make.bottom.equalToSuperview().offset(0)
            }
        }
        
    }
}
// MARK: - CLNavigationBarDelegate
extension GameListControlller:  CLNavigationBarDelegate  {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}
