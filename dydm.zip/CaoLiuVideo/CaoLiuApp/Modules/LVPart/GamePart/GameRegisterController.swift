
import  UIKit

class GameVerbPhoneController: UIViewController {

    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.titleLabel.text = ""
        bar.lineView.backgroundColor = UIColor.clear
        bar.delegate = self
        return bar
    }()
    private let helloLable: UILabel = {
        let lable = UILabel()
        lable.textColor = UIColor.darkText
        lable.font = UIFont.boldSystemFont(ofSize: 25)
        lable.text = "Hello/抖友"
        return lable
    }()
    private lazy var loginView: LoginView = {
        guard let login = Bundle.main.loadNibNamed("LoginView", owner: nil, options: nil)?[0] as? LoginView else { return LoginView() }
        login.frame = CGRect(x: 0, y: 0, width: view.bounds.width, height: 500)
        login.isGameRergister(true)
        return login
    }()
    private let registerViewModel = RegisterLoginViewModel()
    var refreshGameBalanceBlock:(() ->Void)?
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        view.addSubview(navBar)
        view.addSubview(helloLable)
        view.addSubview(loginView)
        layoutPageSubviews()
        //addViewModelCallBackHandler()
        addloginViewActionHandler()
        loginView.loginBtn.setTitle("立即注册", for: .normal)
        loadImgCode()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    private func loadImgCode() {
        registerViewModel.imageCode(nil) { [weak self] imgCodeBase64 in
            guard let strongSelf = self else { return }
            strongSelf.loginView.setImageCode(imgCodeBase64)
        } failHandler: { error in
            /// 这里不会走
        }
    }
    
    private func addloginViewActionHandler() {
        loginView.sendCodeActionHandler = { [weak self] in
            guard let strongSelf = self else { return }
            if strongSelf.loginView.phoneNumber.text != nil && !strongSelf.loginView.phoneNumber.text!.isEmpty {
                strongSelf.sendCode()
            } else {
                XSAlert.show(type: .error, text: "请输入手机号码。")
            }
        }
        
        loginView.addPhoneActionHandler = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.addPhoneNumber()
        }
        loginView.changeImageCodeHandler = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.registerViewModel.imageCode(nil) { imgCodeBase64 in
                strongSelf.loginView.setImageCode(imgCodeBase64)
            } failHandler: { error in
                /// 这里不会走
            }
        }
    }
    
    private func addViewModelCallBackHandler() {
        registerViewModel.loadSendCodeApiSuccess = { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.loginView.codeBtn.isCounting = true
        }
        registerViewModel.loadSendCodeApiFail = { (msg) in
            XSAlert.show(type: .error, text: msg)
        }
        registerViewModel.loadRegisterApiSuccess = { [weak self] in
            XSAlert.show(type: .success, text: "注册成功")
            UserModel.share().user?.bind_mobile = self?.loginView.phoneNumber.text ?? ""
            self?.navigationController?.popViewController(animated: true)
        }
        registerViewModel.loadRegisterApiFail = { (msg) in
             XSAlert.show(type: .error, text: msg)
        }
    }
    
    private func sendCode() {
        if loginView.phoneNumber.text == nil || loginView.phoneNumber.text!.isEmpty  {
            XSAlert.show(type: .error, text: "请输入手机号。")
            return
        }
        if loginView.imageCodeTf.text == nil || loginView.imageCodeTf.text!.isEmpty {
            XSAlert.show(type: .error, text: "请输入图片验证码。")
            return
        }
        registerViewModel.sendCode([SendCodeApi.kMobile: loginView.phoneNumber.text!, SendCodeApi.kImgCode : loginView.imageCodeTf.text ?? ""], succeedHandler: { [weak self] in
            guard let strongSelf = self else { return }
            strongSelf.loginView.codeBtn.isCounting = true
        }) { (errorMsg) in
            XSAlert.show(type: .error, text: errorMsg)
        }
    }
    
    private func addPhoneNumber() {
        if loginView.phoneNumber.text == nil || loginView.phoneNumber.text!.isEmpty  {
            XSAlert.show(type: .error, text: "请输入手机号。")
            return
        }
        if loginView.imageCodeTf.text == nil || loginView.imageCodeTf.text!.isEmpty {
            XSAlert.show(type: .error, text: "请输入图片验证码。")
            return
        }
        if loginView.codeTF.text == nil || loginView.codeTF.text!.isEmpty {
            XSAlert.show(type: .error, text: "请输入短信验证码。")
            return
        }
        let params = [UserRegisterApi.kMobile: loginView.phoneNumber.text ?? "", UserRegisterApi.kCode: loginView.codeTF.text!]
        registerViewModel.isInGameRegist = true
        registerViewModel.reginsterUser(params, succeedHandler: { [weak self] in
            XSAlert.show(type: .success, text: "注册成功")
            UserModel.share().user?.bind_mobile = self?.loginView.phoneNumber.text ?? ""
            self?.refreshGameBalanceBlock?()
            self?.navigationController?.popViewController(animated: true)
        }) { (errorMsg) in
            XSAlert.show(type: .error, text: errorMsg)
        }
    }

}

// MARK: - CLNavigationBarDelegate
extension GameVerbPhoneController:  CLNavigationBarDelegate  {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

// MARK: - Layout
private extension GameVerbPhoneController {
    
    func layoutPageSubviews() {
        layoutNavBar()
        layoutHelloLable()
        layoutLoginView()
    }
    
    func layoutNavBar() {
        navBar.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo(ConstValue.kStatusBarHeight + 44)
        }
    }
    
    func layoutHelloLable() {
        helloLable.snp.makeConstraints { (make) in
            make.leading.equalTo(30)
            make.top.equalTo(navBar.snp.bottom).offset(50)
            make.height.equalTo(30)
        }
    }
    
    func layoutLoginView() {
        loginView.snp.makeConstraints { (make) in
            make.top.equalTo(helloLable.snp.bottom).offset(40)
            make.leading.trailing.equalTo(0)
            make.height.equalTo(350)
        }
    }
    
}

