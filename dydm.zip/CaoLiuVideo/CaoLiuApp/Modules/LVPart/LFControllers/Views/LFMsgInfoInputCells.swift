
import Foundation
import UIKit


class LFInfoInPut1Cell: UITableViewCell, UITextViewDelegate {
    
    static let cellId = "LFInfoInPut1Cell"
    
    let titleLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.boldSystemFont(ofSize: 16)
        lab.textAlignment = .left
        lab.textColor = .white
        return lab
    }()
    let placeHodlerLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.boldSystemFont(ofSize: 14)
        lab.textColor = .gray
        lab.numberOfLines = 0
        return lab
    }()
    lazy var textView: UITextView = {
        let v = UITextView()
        v.textColor = .white
        v.backgroundColor = .clear
        v.isScrollEnabled = false
        v.delegate = self
        v.font = UIFont.systemFont(ofSize: 14)
        return v
    }()
    let line: UIView = {
        let v = UIView()
        v.backgroundColor = ConstValue.kAppSepLineColor
        return v
    }()
    var holderText: String?
    var inputEnd:((_ text: String?) -> Void)?
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        selectedBackgroundView = UIView()
        contentView.addSubview(titleLab)
        contentView.addSubview(textView)
        contentView.addSubview(placeHodlerLab)
        contentView.addSubview(line)
        layoutPages()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setHolderText(_ text: String) {
        holderText = text
    }
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        placeHodlerLab.text = nil
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.tag > 100 {
           if textView.text == nil || textView.text.isEmpty {
                placeHodlerLab.text = holderText
                return
            }
        } else {
            if textView.text == nil || textView.text.isEmpty {
                placeHodlerLab.text = holderText
                return
            }
        }
        inputEnd?(textView.text)
    }
    func textViewDidChange(_ textView: UITextView) {
        if textView.tag > 30 {
            if textView.text.count >= textView.tag - 5 {
                XSAlert.show(type: .text, text: "最多输入\(textView.tag)字符")
                textView.endEditing(true)
            }
        } else if textView.tag == 0 {
            if textView.text.count >= 30 {
                XSAlert.show(type: .text, text: "最多输入30字符")
                textView.endEditing(true)
            }
        }
        tableView()?.beginUpdates()
        tableView()?.endUpdates()
    }
    
}
extension LFInfoInPut1Cell {
    func tableView() -> UITableView? {
        guard var view = self.superview else { return nil }
        while !(view is UITableView) {
            if view.superview != nil {
                view = view.superview!
            }
        }
        return view as? UITableView
    }
    func layoutPages() {
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.height.equalTo(20)
            make.top.equalTo(12)
            make.trailing.equalTo(-15)
        }
        textView.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-12)
            make.top.equalTo(titleLab.snp.bottom).offset(10)
            make.bottom.equalTo(-10)
        }
        placeHodlerLab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-10)
            make.top.equalTo(titleLab.snp.bottom).offset(10)
            make.bottom.equalTo(-10)
        }
        line.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalToSuperview()
            make.height.equalTo(0.6)
            make.bottom.equalToSuperview()
        }
    }
}



class LFInfoInPut2Cell: UITableViewCell,UITextViewDelegate {
    
    static let cellId = "LFInfoInPut2Cell"
    
    let titleLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.boldSystemFont(ofSize: 16)
        lab.textAlignment = .left
        lab.textColor = .white
        return lab
    }()
    let placeHodlerLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.boldSystemFont(ofSize: 14)
        lab.textColor = .gray
        lab.numberOfLines = 0
        return lab
    }()
    lazy var textView: UITextView = {
        let v = UITextView()
        v.textColor = .white
        v.backgroundColor = .clear
        v.isScrollEnabled = false
        v.delegate = self
        v.font = UIFont.systemFont(ofSize: 14)
        return v
    }()
    let line: UIView = {
        let v = UIView()
        v.backgroundColor = ConstValue.kAppSepLineColor
        return v
    }()
    var inputEnd:((_ text: String?) -> Void)?
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        selectedBackgroundView = UIView()
        contentView.addSubview(titleLab)
        contentView.addSubview(textView)
        contentView.addSubview(placeHodlerLab)
        contentView.addSubview(line)
        layoutPages()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        placeHodlerLab.text = nil
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text == nil || textView.text.isEmpty {
            placeHodlerLab.text = LFPushInfosController.placeHodlers[textView.tag]
            return
        }
        inputEnd?(textView.text)
    }
    func textViewDidChange(_ textView: UITextView) {
        tableView()?.beginUpdates()
        tableView()?.endUpdates()
    }
    
}

extension LFInfoInPut2Cell {
    func tableView() -> UITableView? {
        guard var view = self.superview else { return nil }
        while !(view is UITableView) {
            if view.superview != nil {
                view = view.superview!
            }
        }
        return view as? UITableView
    }
    func layoutPages() {
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.height.equalTo(40)
            make.top.equalTo(10)
            make.bottom.equalTo(-10)
        }
        textView.snp.makeConstraints { (make) in
            make.leading.equalTo(titleLab.snp.trailing).offset(15)
            make.trailing.equalTo(-10)
            make.centerY.equalTo(titleLab)
        }
        placeHodlerLab.snp.makeConstraints { (make) in
            make.leading.equalTo(titleLab.snp.trailing).offset(15)
            make.trailing.equalTo(-10)
            make.top.equalTo(10)
            make.bottom.equalTo(-10)
        }
        line.snp.makeConstraints { (make) in
            make.leading.equalTo(12)
            make.trailing.equalToSuperview()
            make.height.equalTo(0.6)
            make.bottom.equalToSuperview()
        }
    }
}



class LFInfoInPut3Cell: UITableViewCell,UITextViewDelegate {
    
    static let cellId = "LFInfoInPut3Cell"
    
    let tipLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.boldSystemFont(ofSize: 11)
        lab.textAlignment = .left
        lab.textColor = .groupTableViewBackground
        let change = Int(UserModel.share().authInfo?.config?.rule?.service_change ?? "5") ?? 5
        lab.text = "(服务定金: \(change)钻石抵扣1元)"
        return lab
    }()
    let titleLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.boldSystemFont(ofSize: 16)
        lab.textAlignment = .left
        lab.textColor = .white
        lab.text = "钻石:"
        return lab
    }()
    let placeHodlerLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.boldSystemFont(ofSize: 14)
        lab.textColor = .gray
        lab.numberOfLines = 0
        lab.textAlignment = .left
        lab.text = "请输入钻石数量10~5000"
        return lab
    }()
    lazy var textView: UITextView = {
        let v = UITextView()
        v.textColor = .white
        v.backgroundColor = .clear
        v.isScrollEnabled = false
        v.keyboardType = .decimalPad
        v.delegate = self
        v.font = UIFont.systemFont(ofSize: 14)
        return v
    }()
    let zheKouLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.boldSystemFont(ofSize: 12)
        lab.textAlignment = .left
        lab.textColor = .red
        lab.text = "服务时可抵扣(元): 0"
        return lab
    }()
    let line: UIView = {
        let v = UIView()
        v.backgroundColor = ConstValue.kAppSepLineColor
        return v
    }()
    var inputEnd:((_ text: String?) -> Void)?
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        selectedBackgroundView = UIView()
        contentView.addSubview(tipLab)
        contentView.addSubview(titleLab)
        contentView.addSubview(textView)
        contentView.addSubview(placeHodlerLab)
        contentView.addSubview(zheKouLab)
        contentView.addSubview(line)
        layoutPages()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        placeHodlerLab.text = nil
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text == nil || textView.text.isEmpty {
            placeHodlerLab.text = "请输入钻石数量10~5000"
            return
        }
        let change = Int(UserModel.share().authInfo?.config?.rule?.service_change ?? "5") ?? 5
        zheKouLab.text = "服务时可抵扣(元): \((Int(textView.text) ?? 0)/change)"
        inputEnd?(textView.text)
    }
    func textViewDidChange(_ textView: UITextView) {
        tableView()?.beginUpdates()
        tableView()?.endUpdates()
    }
    
}

extension LFInfoInPut3Cell {
    func tableView() -> UITableView? {
        guard var view = self.superview else { return nil }
        while !(view is UITableView) {
            if view.superview != nil {
                view = view.superview!
            }
        }
        return view as? UITableView
    }
    func layoutPages() {
        tipLab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-12)
            make.top.equalTo(10)
            make.height.equalTo(20)
        }
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.height.equalTo(40)
            make.width.equalTo(50)
            make.top.equalTo(tipLab.snp.bottom).offset(10)
        }
        textView.snp.makeConstraints { (make) in
            make.leading.equalTo(titleLab.snp.trailing).offset(15)
            make.trailing.equalTo(-10)
            make.centerY.equalTo(titleLab)
            make.height.equalTo(40)
        }
        placeHodlerLab.snp.makeConstraints { (make) in
            make.leading.equalTo(titleLab.snp.trailing).offset(10)
            make.trailing.equalTo(-10)
            make.top.equalTo(titleLab)
            make.bottom.equalTo(titleLab)
        }
        zheKouLab.snp.makeConstraints { (make) in
            make.leading.equalTo(12)
            make.trailing.equalTo(-12)
            make.top.equalTo(titleLab.snp.bottom).offset(5)
            make.height.equalTo(20)
            make.bottom.equalTo(-10)
        }
        line.snp.makeConstraints { (make) in
            make.leading.equalTo(12)
            make.trailing.equalToSuperview()
            make.height.equalTo(0.6)
            make.bottom.equalToSuperview()
        }
    }
}

class VideoChoseView: UIView {
    let title1lab: UILabel = {
        let lab = UILabel()
        lab.text = "MM视频（发布后可修改，最多1部)"
        lab.textColor = .white
        lab.font = UIFont.systemFont(ofSize: 14)
        return lab
    }()
    
    let title2lab: UILabel = {
        let lab = UILabel()
        lab.text = "MM照片*（发布后可修改，最多5张）"
        lab.textColor = .white
        lab.font = UIFont.systemFont(ofSize: 14)
        return lab
    }()
    lazy var videoAddBtn: UIButton = {
        let v = UIButton(type: .custom)
        v.setBackgroundImage(getImage("pushPictureAdd"), for: .normal)
        v.addTarget(self, action: #selector(addVideoClick), for: .touchUpInside)
        return v
    }()
    lazy var videoDelBtn: UIButton = {
        let v = UIButton(type: .custom)
        v.setBackgroundImage(getImage("deletePicture"), for: .normal)
        v.addTarget(self, action: #selector(deleteClick), for: .touchUpInside)
        v.isHidden = true
        return v
    }()
    let line1: UIView = {
        let v = UIView()
        v.backgroundColor = ConstValue.kAppSepLineColor
        return v
    }()
    let line2: UIView = {
        let v = UIView()
        v.backgroundColor = ConstValue.kAppSepLineColor
        return v
    }()
    var addBtnAction:(() -> Void)?
    var deletedAction:(() ->Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(title1lab)
        addSubview(line1)
        addSubview(videoAddBtn)
        addSubview(videoDelBtn)
        addSubview(title2lab)
        addSubview(line2)
        layoutSubs()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @objc func addVideoClick() {
        addBtnAction?()
    }
    @objc func deleteClick() {
        deletedAction?()
    }
    func layoutSubs() {
        title1lab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-12)
            make.top.equalTo(15)
            make.height.equalTo(20)
        }
        line1.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(title1lab.snp.bottom).offset(15)
            make.height.equalTo(0.6)
        }
        videoAddBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(line1).offset(15)
            make.height.width.equalTo((screenWidth-35)/3)
        }
        videoDelBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(videoAddBtn).offset(2)
            make.top.equalTo(videoAddBtn).offset(-2)
            make.height.width.equalTo(16)
        }
        title2lab.snp.makeConstraints { (make) in
            make.leading.equalTo(12)
            make.trailing.equalTo(-12)
            make.top.equalTo(videoAddBtn.snp.bottom).offset(30)
            make.height.equalTo(20)
        }
        line2.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(title2lab.snp.bottom).offset(15)
            make.height.equalTo(0.6)
        }
    }
}
