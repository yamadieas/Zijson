
import UIKit

class LFMsgListCell: UICollectionViewCell {
    static let cellId = "LFMsgListCell"
    static let itemSize = CGSize(width: screenWidth, height: 190)
    let shadowV: UIView = {
        let v = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth-20.0, height: 180))
        v.backgroundColor = ConstValue.kAppSepLineColor
        return v
    }()
    let coverImg: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
//        imageView.clipsToBounds = true
//        imageView.layer.cornerRadius = 3
//        imageView.layer.masksToBounds = true
        imageView.bounds = CGRect(x: 0, y: 0, width: 135, height: 180)
        return imageView
    }()
    let playIcon: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(white: 0.9, alpha: 0.5)
        view.layer.cornerRadius = 20
        view.layer.masksToBounds = true
        let img = UIImageView(image: UIImage(named: "pause"))
        img.isUserInteractionEnabled = true
        img.contentMode = .scaleAspectFit
        view.addSubview(img)
        img.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview().offset(2)
            make.height.width.equalTo(16)
        }
        view.isHidden = true
        return view
    }()
    let zanImgView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = getImage("icon_home_like_after")
        return imageView
    }()
    let zanCountLab: UILabel = {
        let titleLab = UILabel()
        titleLab.text = "0"
        titleLab.font = UIFont.systemFont(ofSize: 14)
        titleLab.textColor = .white
        return titleLab
    }()
    let titleLab: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.boldSystemFont(ofSize: 14)
        titleLab.textAlignment = .left
        titleLab.textColor = .white
        titleLab.numberOfLines = 1
        return titleLab
    }()
    let priceLab: UILabel = {
         let titleLab = UILabel()
         titleLab.font = UIFont.systemFont(ofSize: 13)
         titleLab.textAlignment = .left
         titleLab.textColor = .lightGray
         titleLab.numberOfLines = 1
         return titleLab
     }()
    let serversLab: UILabel = {
         let titleLab = UILabel()
         titleLab.font = UIFont.systemFont(ofSize: 13)
         titleLab.textAlignment = .left
         titleLab.textColor = .lightGray
         titleLab.numberOfLines = 1
         return titleLab
     }()
    let timelab: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.systemFont(ofSize: 13)
        titleLab.textAlignment = .left
        titleLab.textColor = .lightGray
        return titleLab
    }()
    let locationLab: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.systemFont(ofSize: 13)
        titleLab.textAlignment = .left
        titleLab.textColor = .lightGray
        return titleLab
    }()
    let authLab: UIButton = {
        let img = UIButton(type: .custom)
        img.titleLabel?.font = UIFont.systemFont(ofSize: 11)
        img.setTitleColor(.darkText, for: .normal)
        img.setTitle("官方认证", for: .normal)
        img.setBackgroundImage(getImage("LfauthButton"), for: .normal)
        img.isHidden = true
        return img
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(shadowV)
        shadowV.addSubview(coverImg)
        shadowV.addSubview(zanCountLab)
        shadowV.addSubview(zanImgView)
        shadowV.addSubview(titleLab)
        shadowV.addSubview(priceLab)
        shadowV.addSubview(serversLab)
        shadowV.addSubview(locationLab)
        shadowV.addSubview(timelab)
        shadowV.addSubview(authLab)
        shadowV.addSubview(playIcon)
        layoutPageSubViews()
      //  shadowV.addShadow(radius: 5, opacity: 0.3)
        let corners: UIRectCorner = [UIRectCorner.topLeft, UIRectCorner.bottomLeft]
        coverImg.corner(byRoundingCorners: corners, radii: 3)
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setLFMsgModel(_ model: LFMsgModel) {
        coverImg.kfSetVerticalImageWithUrl(model.cover)
        titleLab.text = model.title
        authLab.isHidden = model.is_attest != 1
        if let servers = model.serving {
            let serverStr = NSMutableString.init()
            for i in 0 ..< servers.count {
                if i == servers.count - 1 {
                    serverStr.append(servers[i])
                } else {
                    serverStr.append("\(servers[i]),")
                }
            }
            serversLab.attributedText = TextSpaceManager.configColorString(allString: "服务项目: \(serverStr as String)", attribStr: "服务项目:", .white, UIFont.systemFont(ofSize: 13), 0)
        }
        if let prices = model.serving_money {
            let priceStr = NSMutableString.init()
            for i in 0 ..< prices.count {
                if i == prices.count - 1 {
                    priceStr.append(prices[i])
                } else {
                    priceStr.append("\(prices[i]),")
                }
            }
            priceLab.attributedText = TextSpaceManager.configColorString(allString: "价格预览: \(priceStr as String)", attribStr: "价格预览:", .white, UIFont.systemFont(ofSize: 13), 0)
        }
        locationLab.attributedText = TextSpaceManager.configColorString(allString: "妹子坐标: \(model.province ?? "")\(model.city ?? "")", attribStr: "妹子坐标:", .white, UIFont.systemFont(ofSize: 13), 0)
        timelab.attributedText = TextSpaceManager.configColorString(allString: "发布时间: \(model.created_at ?? "--")", attribStr: "发布时间:", .white, UIFont.systemFont(ofSize: 13), 0)
        zanCountLab.text = getStringWithNumber(model.like_count ?? 0)
        if let videoCover = model.video, !videoCover.isEmpty {
            playIcon.isHidden = false
        } else {
            playIcon.isHidden = true
        }
    }
   
    private func layoutPageSubViews() {
        shadowV.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.trailing.equalTo(-10)
            make.top.equalTo(5)
            make.bottom.equalTo(-5)
        }
        coverImg.snp.makeConstraints { (make) in
            make.leading.top.bottom.equalToSuperview()
            make.width.equalTo(135)
        }
        zanCountLab.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.bottom.equalTo(coverImg).offset(-10)
        }
        zanImgView.snp.makeConstraints { (make) in
            make.centerY.equalTo(zanCountLab)
            make.trailing.equalTo(zanCountLab.snp.leading).offset(-3)
            make.width.height.equalTo(15)
        }
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(coverImg.snp.trailing).offset(10)
            make.trailing.equalTo(-2)
            make.height.equalTo(20)
            make.top.equalTo(7)
        }
        priceLab.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(titleLab)
            make.height.equalTo(20)
            make.top.equalTo(titleLab.snp.bottom).offset(7)
        }
        serversLab.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(titleLab)
            make.height.equalTo(20)
            make.top.equalTo(priceLab.snp.bottom).offset(7)
        }
        locationLab.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(titleLab)
            make.height.equalTo(20)
            make.top.equalTo(serversLab.snp.bottom).offset(7)
        }
        timelab.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(titleLab)
            make.height.equalTo(20)
            make.top.equalTo(locationLab.snp.bottom).offset(7)
        }
        authLab.snp.makeConstraints { (make) in
            make.centerY.equalTo(zanCountLab)
            make.leading.equalTo(titleLab)
            make.width.equalTo(70)
            make.height.equalTo(22)
        }
        playIcon.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.top.equalTo(10)
            make.height.width.equalTo(30)
        }
    }
}


class LFHightLevelListCell: UICollectionViewCell {
    static let cellId = "LFHightLevelListCell"
    static let itemSize = CGSize(width: (screenWidth - 40)/2, height: (screenWidth - 40)/2 * 5/4 + 60)
    let coverImg: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.clipsToBounds = true
        imageView.layer.cornerRadius = 7.5
        imageView.layer.masksToBounds = true
        imageView.bounds = CGRect(x: 0, y: 0, width: (screenWidth - 40)/2, height: (screenWidth - 40)/2 * 5/4)
        return imageView
    }()
    let playIcon: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(white: 0.9, alpha: 0.5)
        view.layer.cornerRadius = 15
        view.layer.masksToBounds = true
        let img = UIImageView(image: UIImage(named: "pause"))
        img.isUserInteractionEnabled = true
        img.contentMode = .scaleAspectFit
        view.addSubview(img)
        img.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview().offset(2)
            make.height.width.equalTo(12)
        }
        view.isHidden = true
        return view
    }()
    let titleLab: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.boldSystemFont(ofSize: 14)
        titleLab.textAlignment = .left
        titleLab.textColor = .white
        titleLab.numberOfLines = 1
        return titleLab
    }()
    let locationLab: UILabel = {
         let titleLab = UILabel()
         titleLab.font = UIFont.systemFont(ofSize: 13)
         titleLab.textAlignment = .left
         titleLab.textColor = .lightGray
         titleLab.numberOfLines = 1
         return titleLab
     }()
   
    let coverLayer: CAGradientLayer = {
        let gradientLayer = CAGradientLayer()
        gradientLayer.colors = [UIColor.clear.cgColor, UIColor(white: 0.0, alpha: 0.3).cgColor]
        gradientLayer.locations = [0.75, 1.0]
        return gradientLayer
    }()
    let menuImg: UIImageView = {
        let v = UIImageView(image: getImage("menu3Point"))
        v.isUserInteractionEnabled = true
        v.contentMode = .scaleAspectFit
        return v
    }()
    lazy var menuBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.addTarget(self, action: #selector(menuBtnClick), for: .touchUpInside)
        return btn
    }()
    var menuClick:(() ->Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.backgroundColor = ConstValue.kCoverBgColor
        contentView.addSubview(coverImg)
        contentView.addSubview(titleLab)
        contentView.addSubview(locationLab)
        contentView.addSubview(playIcon)
        contentView.addSubview(menuImg)
        contentView.addSubview(menuBtn)
        contentView.layer.cornerRadius = 7.5
        contentView.layer.masksToBounds = true
        layoutPageSubViews()
        coverLayer.frame = coverImg.bounds
        coverImg.layer.insertSublayer(coverLayer, at: 0)
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @objc func menuBtnClick() {
        menuClick?()
    }
    
    func setLFMsgModel(_ model: LFMsgModel) {
        coverImg.kfSetVerticalImageWithUrl(model.cover)
        titleLab.text = model.title
        if let p = model.province, !p.isEmpty {
            locationLab.text = "\(p)·\(model.city ?? "")"
        } else {
            locationLab.text = "\(model.city ?? "")"
        }
        if let videoCover = model.video, !videoCover.isEmpty {
            playIcon.isHidden = false
        } else {
            playIcon.isHidden = true
        }
    }
   
    private func layoutPageSubViews() {
        coverImg.snp.makeConstraints { (make) in
            make.leading.top.trailing.equalToSuperview()
            make.height.equalTo((screenWidth - 40)/2 * 5/4)
        }
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(5)
            make.trailing.equalTo(-2)
            make.height.equalTo(20)
            make.top.equalTo(coverImg.snp.bottom).offset(5)
        }
        locationLab.snp.makeConstraints { (make) in
            make.leading.equalTo(titleLab)
            make.trailing.equalTo(-5)
            make.height.equalTo(20)
            make.top.equalTo(titleLab.snp.bottom).offset(5)
        }
        playIcon.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.top.equalTo(10)
            make.height.width.equalTo(30)
        }
        menuImg.snp.makeConstraints { (make) in
            make.trailing.equalTo(-5)
            make.centerY.equalTo(locationLab)
            make.height.equalTo(5)
            make.width.equalTo(25)
        }
        menuBtn.snp.makeConstraints { (make) in
            make.centerY.equalTo(menuImg)
            make.trailing.equalTo(-5)
            make.height.equalTo(25)
            make.width.equalTo(40)
        }
    }
}

class LfInfoTextCell: UITableViewCell {
    
    static let cellId = "LfInfoTextCell"
    lazy var fakeButton: UIButton = {
        let btn = UIButton(type: .custom)
        btn.addTarget(self, action: #selector(textClick), for: .touchUpInside)
        return btn
    }()
    let textLab: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.systemFont(ofSize: 13)
        titleLab.textAlignment = .left
        titleLab.textColor = .lightGray
        titleLab.numberOfLines = 0
        return titleLab
    }()
    var textClickAction:(() ->Void)?
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = ConstValue.kVcViewColor
        contentView.addSubview(textLab)
        contentView.addSubview(fakeButton)
        let view = UIView()
        view.backgroundColor = UIColor.clear
        selectedBackgroundView = view
        textLab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-10)
            make.top.equalTo(7.5)
            make.bottom.equalTo(-10)
        }
        fakeButton.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(7.5)
            make.bottom.equalTo(-10)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @objc func textClick() {
        textClickAction?()
    }
}

class LfNOContactCell: UITableViewCell {
    
    static let cellId = "LfNOContactCell"
    
    lazy var fakeButton: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitleColor(.darkText, for: .normal)
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        btn.setTitle("私密信息，购买指定会员后可以查看", for: .normal)
        btn.borderRadius = 7.5
        btn.addTarget(self, action: #selector(textClick), for: .touchUpInside)
        btn.backgroundColor = UIColor.colorGradientChangeWithSize(size: CGSize(width: screenWidth - 30, height: 45), direction: .level, startColor: rgb(247, 219, 172), endColor: rgb(223, 180, 127))
        return btn
    }()
    var textClickAction:(() ->Void)?
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = .clear
        backgroundColor = .clear
        contentView.addSubview(fakeButton)
        let view = UIView()
        view.backgroundColor = UIColor.clear
        selectedBackgroundView = view
        fakeButton.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(7.5)
            make.bottom.equalTo(-10)
            make.height.equalTo(45)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @objc func textClick() {
        textClickAction?()
    }
}




class LfCommentCell: UITableViewCell {
    
    static let cellId = "LfCommentCell"
    let headerImg: UIImageView = {
        let v = UIImageView()
        v.layer.cornerRadius = 15
        v.layer.masksToBounds = true
        v.isUserInteractionEnabled = true
        return v
    }()
    let nameLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.boldSystemFont(ofSize: 14)
        lab.textAlignment = .left
        lab.textColor = .white
        return lab
    }()
    let textLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.systemFont(ofSize: 13)
        lab.textAlignment = .left
        lab.textColor = .lightGray
        lab.numberOfLines = 0
        return lab
    }()
    let timeLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.systemFont(ofSize: 12)
        lab.textAlignment = .left
        lab.textColor = .lightGray
        lab.numberOfLines = 0
        return lab
    }()
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = ConstValue.kVcViewColor
        contentView.addSubview(headerImg)
        contentView.addSubview(nameLab)
        contentView.addSubview(textLab)
        contentView.addSubview(timeLab)
        layoutPages()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setModel(_ model: LFCommentModel, _ hideTime: Bool? = false) {
        headerImg.kfsetHeader(model.user_info?.avatar)
        nameLab.text = model.user_info?.nick
        timeLab.text = model.time_string
        textLab.attributedText = TextSpaceManager.getAttributeStringWithString(model.comment_msg ?? "", lineSpace: 5)
        if (hideTime ?? false) {
            timeLab.snp.updateConstraints { (make) in
                make.height.equalTo(0)
                make.bottom.equalTo(0)
            }
        } else {
            timeLab.snp.updateConstraints { (make) in
                make.height.equalTo(18)
                make.bottom.equalTo(-10)
            }
        }
    }
    func layoutPages() {
        headerImg.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(6)
            make.height.width.equalTo(30)
        }
        nameLab.snp.makeConstraints { (make) in
            make.leading.equalTo(headerImg.snp.trailing).offset(10)
            make.centerY.equalTo(headerImg)
        }
        timeLab.snp.makeConstraints { (make) in
            make.leading.equalTo(headerImg)
            make.bottom.equalTo(-10)
            make.height.equalTo(18)
        }
        textLab.snp.makeConstraints { (make) in
            make.top.equalTo(headerImg.snp.bottom).offset(10)
            make.leading.equalTo(headerImg).offset(2)
            make.trailing.equalTo(-10)
            make.bottom.equalTo(timeLab.snp.top).offset(-10)
        }
    }
}



class LFPusherCell: UITableViewCell {
    
    static let cellId = "LFPusherCell"
    let headerImg: UIImageView = {
        let v = UIImageView()
        v.layer.cornerRadius = 15
        v.layer.masksToBounds = true
        v.isUserInteractionEnabled = true
        return v
    }()
    let nameLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.boldSystemFont(ofSize: 14)
        lab.textAlignment = .left
        lab.textColor = .white
        return lab
    }()
    lazy var userBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.tag = 3
        btn.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return btn
    }()
    lazy var sendMsgBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.backgroundColor = ConstValue.kStypeColor
        btn.tag = 1
        btn.layer.cornerRadius = 14.0
        btn.layer.masksToBounds = true
        btn.setTitle("私信TA", for: .normal)
        btn.setTitleColor(UIColor.white, for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        btn.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return btn
    }()
    lazy var allMsgBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.tag = 2
        btn.layer.cornerRadius = 14.0
        btn.layer.borderColor = ConstValue.kStypeColor.cgColor
        btn.layer.borderWidth = 0.8
        btn.layer.masksToBounds = true
        btn.setTitle("全部信息", for: .normal)
        btn.setTitleColor(ConstValue.kStypeColor, for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 13)
        btn.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return btn
    }()
    var actionHandler:((_ tag: Int) -> Void)?
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = ConstValue.kVcViewColor
        contentView.addSubview(headerImg)
        contentView.addSubview(nameLab)
        contentView.addSubview(userBtn)
        contentView.addSubview(allMsgBtn)
        contentView.addSubview(sendMsgBtn)
        layoutPages()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setModel(_ model: CLUserInfo?) {
        headerImg.kfsetHeader(model?.avatar)
        nameLab.text = model?.nick
    }
    @objc func buttonClick(_ sender: UIButton) {
        actionHandler?(sender.tag)
    }
    func layoutPages() {
        headerImg.snp.makeConstraints { (make) in
            make.leading.equalTo(12)
            make.top.equalTo(10)
            make.bottom.equalTo(-10)
            make.height.width.equalTo(30)
        }
        nameLab.snp.makeConstraints { (make) in
            make.leading.equalTo(headerImg.snp.trailing).offset(10)
            make.centerY.equalTo(headerImg)
        }
        userBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(headerImg)
            make.top.bottom.equalTo(headerImg)
            make.trailing.equalTo(nameLab)
        }
        allMsgBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.centerY.equalToSuperview()
            make.height.equalTo(28)
            make.width.equalTo(65)
        }
        sendMsgBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(allMsgBtn.snp.leading).offset(-10)
            make.centerY.equalToSuperview()
            make.height.equalTo(28)
            make.width.equalTo(65)
        }
    }
}



class LFPusherView: UIView {
    
    static let cellId = "LFPusherCell"
    let headerImg: UIImageView = {
        let v = UIImageView()
        v.borderRadius = 12.5
        v.isUserInteractionEnabled = true
        return v
    }()
    let nameLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.boldSystemFont(ofSize: 14)
        lab.textAlignment = .left
        lab.textColor = .white
        return lab
    }()
    lazy var userBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.tag = 2
        btn.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return btn
    }()
    lazy var sendMsgBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.backgroundColor = ConstValue.kStypeColor
        btn.tag = 1
        btn.borderRadius = 14
        btn.setTitle("私信TA", for: .normal)
        btn.setTitleColor(UIColor.white, for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 12)
        btn.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return btn
    }()
    
    var actionHandler:((_ tag: Int) -> Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = ConstValue.kVcViewColor
        addSubview(headerImg)
        addSubview(nameLab)
        addSubview(userBtn)
        addSubview(sendMsgBtn)
        layoutPages()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setModel(_ model: CLUserInfo?) {
        headerImg.kfsetHeader(model?.avatar)
        nameLab.text = model?.nick
    }
    @objc func buttonClick(_ sender: UIButton) {
        actionHandler?(sender.tag)
    }
    func layoutPages() {
        headerImg.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(10)
            make.bottom.equalTo(-10)
            make.height.width.equalTo(25)
        }
        nameLab.snp.makeConstraints { (make) in
            make.leading.equalTo(headerImg.snp.trailing).offset(10)
            make.centerY.equalTo(headerImg)
        }
        userBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(headerImg.snp.trailing)
            make.top.bottom.equalTo(headerImg)
            make.trailing.equalTo(nameLab)
        }
        sendMsgBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.centerY.equalToSuperview()
            make.height.equalTo(28)
            make.width.equalTo(65)
        }
    }
}

