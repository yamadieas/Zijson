

import UIKit


class LFDetailFooterView: UIView {
//    private let layout = UICollectionViewFlowLayout()
//    lazy var collView: UICollectionView = {
//        layout.sectionHeadersPinToVisibleBounds = true
//        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
//        collection.delegate = self
//        collection.dataSource = self
//        collection.showsVerticalScrollIndicator = false
//        collection.backgroundColor = UIColor.clear
//        collection.register(LFHightLevelListCell.classForCoder(), forCellWithReuseIdentifier: LFHightLevelListCell.cellId)
//
//        collection.mj_header = refreshView
//        collection.mj_footer = loadMoreView
//        return collection
//    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
