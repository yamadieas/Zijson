

import UIKit

class LFShopListCell: UICollectionViewCell {
    static let cellId = "LFShopListCell"
    static let itemSize = CGSize(width: screenWidth - 30, height: 180)
    let shadowV: UIView = {
        let v = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth-30.0, height: 180))
        v.backgroundColor = ConstValue.kCoverBgColor
        v.borderRadius = 7.5
        return v
    }()
    let coverImg: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.bounds = CGRect(x: 0, y: 0, width: 135, height: 180)
        return imageView
    }()
    let playIcon: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor(white: 0.9, alpha: 0.5)
        view.layer.cornerRadius = 20
        view.layer.masksToBounds = true
        let img = UIImageView(image: UIImage(named: "pause"))
        img.isUserInteractionEnabled = true
        img.contentMode = .scaleAspectFit
        view.addSubview(img)
        img.snp.makeConstraints { (make) in
            make.centerY.equalToSuperview()
            make.centerX.equalToSuperview().offset(2)
            make.height.width.equalTo(16)
        }
        view.isHidden = true
        return view
    }()
    let zanCountLab: UILabel = {
        let titleLab = UILabel()
        titleLab.text = "0"
        titleLab.font = UIFont.systemFont(ofSize: 11)
        titleLab.textColor = .white
        return titleLab
    }()
    let headerImg: UIImageView = {
        let imageView = UIImageView()
        imageView.contentMode = .scaleAspectFill
        imageView.borderRadius = 10.0
        return imageView
    }()
    let nameLab: UILabel = {
        let lab = UILabel()
        lab.font = UIFont.boldSystemFont(ofSize: 13)
        lab.textAlignment = .left
        lab.textColor = .white
        lab.numberOfLines = 1
        return lab
    }()
    let renIconImg: UIImageView = {
        let imageView = UIImageView()
        imageView.image = getImage("AuthStatuIcon")
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    let jingjiLab: UILabel = {
         let titleLab = UILabel()
         titleLab.font = UIFont.systemFont(ofSize: 13)
         titleLab.textAlignment = .left
         titleLab.textColor = rgb( 255 , 239 , 195)
         return titleLab
     }()
    let authIconImg: UIImageView = {
        let imageView = UIImageView()
        imageView.image = getImage("AuthMoneyIcon")
        imageView.contentMode = .scaleAspectFill
        return imageView
    }()
    let authMoneyLab: UILabel = {
         let titleLab = UILabel()
         titleLab.font = UIFont.systemFont(ofSize: 13)
         titleLab.textColor = rgb( 255 , 239 , 195)
         return titleLab
     }()
    let areaTitlelab: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.boldSystemFont(ofSize: 11)
        titleLab.textColor = .white
        return titleLab
    }()
    let citysLab: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.systemFont(ofSize: 12)
        titleLab.textColor = .lightGray
        titleLab.numberOfLines = 2
        return titleLab
    }()
    let mmCountLabel: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.systemFont(ofSize: 11)
        titleLab.textAlignment = .left
        titleLab.textColor = .white
        return titleLab
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        contentView.addSubview(shadowV)
        shadowV.addSubview(coverImg)
        shadowV.addSubview(zanCountLab)
        shadowV.addSubview(headerImg)
        shadowV.addSubview(nameLab)
        shadowV.addSubview(renIconImg)
        shadowV.addSubview(jingjiLab)
        shadowV.addSubview(authIconImg)
        shadowV.addSubview(authMoneyLab)
        shadowV.addSubview(areaTitlelab)
        shadowV.addSubview(citysLab)
        shadowV.addSubview(mmCountLabel)
        shadowV.addSubview(playIcon)
        layoutPageSubViews()
        let corners: UIRectCorner = [UIRectCorner.topLeft, UIRectCorner.bottomLeft]
        coverImg.corner(byRoundingCorners: corners, radii: 7.5)
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setShopModel(_ model: LFShopModel) {
        coverImg.kfSetVerticalImageWithUrl(model.top_mm_info?.cover)
        mmCountLabel.text = "MM\(model.mm_count ?? 0)人"
        headerImg.kfsetHeader(model.user_info?.avatar)
        nameLab.text = model.user_info?.nick
        jingjiLab.text = "官方认证经纪人"
        authMoneyLab.text = "已缴纳\(model.deposit_money ?? "0")保证金"
        areaTitlelab.text = "服务地区"
        citysLab.text = model.serving_area
        zanCountLab.text = "\(getStringWithNumber(model.like_count ?? 0))人想约"
        if let videoCover = model.top_mm_info?.video, !videoCover.isEmpty {
            playIcon.isHidden = false
        } else {
            playIcon.isHidden = true
        }
    }
   
    private func layoutPageSubViews() {
        shadowV.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
        coverImg.snp.makeConstraints { (make) in
            make.leading.top.bottom.equalToSuperview()
            make.width.equalTo(135)
        }
        zanCountLab.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.bottom.equalTo(coverImg).offset(-8)
        }
        mmCountLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(coverImg.snp.trailing).offset(10)
            make.centerY.equalTo(zanCountLab)
        }
        headerImg.snp.makeConstraints {
            $0.leading.equalTo(coverImg.snp.trailing).offset(10)
            $0.height.width.equalTo(20)
            $0.top.equalTo(7)
        }
        nameLab.snp.makeConstraints { (make) in
            make.leading.equalTo(headerImg.snp.trailing).offset(8)
            make.trailing.equalTo(-2)
            make.height.equalTo(20)
            make.centerY.equalTo(headerImg)
        }
        renIconImg.snp.makeConstraints {
            $0.centerX.equalTo(headerImg)
            $0.height.width.equalTo(18)
            $0.top.equalTo(headerImg.snp.bottom).offset(7)
        }
        jingjiLab.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(nameLab)
            make.height.equalTo(18)
            make.centerY.equalTo(renIconImg)
        }
        authIconImg.snp.makeConstraints { (make) in
            make.leading.equalTo(renIconImg)
            make.top.equalTo(renIconImg.snp.bottom).offset(7)
            make.height.width.equalTo(18)
        }
        authMoneyLab.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(nameLab)
            make.height.equalTo(18)
            make.centerY.equalTo(authIconImg)
        }
        areaTitlelab.snp.makeConstraints { (make) in
            make.leading.equalTo(headerImg)
            make.height.equalTo(20)
            make.top.equalTo(authIconImg.snp.bottom).offset(6)
        }
        citysLab.snp.makeConstraints { (make) in
            make.leading.equalTo(areaTitlelab)
            make.trailing.equalTo(-10)
            make.top.equalTo(areaTitlelab.snp.bottom).offset(3)
        }
        playIcon.snp.makeConstraints { (make) in
            make.center.equalTo(coverImg)
            make.height.width.equalTo(40)
        }
    }
}


class ShopDetailItemsCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 2
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShareOrFavorItemCell.cellId, for: indexPath) as! ShareOrFavorItemCell
        cell.iconImage.image = getImage([shopDetail?.is_like == 1 ? "icon_home_like_after" : "favorItemIcon","earnMoneyShareIcon"][indexPath.item])
        cell.titleLable.text = [getStringWithNumber(shopDetail?.shop_info?.like_count ?? 0), "分享"][indexPath.item]
        cell.tipsLable.text = ["喜欢就收藏一下","邀请好友.赚会员"][indexPath.item]
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: false)
        itemClickHandler?(indexPath.item)
    }
    var itemClickHandler:((_ index: Int) ->Void)?
    var shopDetail: LFShopDetail?
    
    static let cellId = "ShopDetailItemsCell"
    
    
    let layout: UICollectionViewFlowLayout = {
        let l = UICollectionViewFlowLayout()
        l.itemSize = ShareOrFavorItemCell.itemSize
        l.sectionInset = UIEdgeInsets(top: 0, left: 15, bottom: 0, right: 15)
        l.minimumLineSpacing = 10
        l.scrollDirection = .horizontal
        return l
    }()
    lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame: .zero, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsVerticalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(ShareOrFavorItemCell.classForCoder(), forCellWithReuseIdentifier: ShareOrFavorItemCell.cellId)
        return collection
    }()
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = .clear
        backgroundColor = .clear
        contentView.addSubview(collectionView)
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setModel(_ shop: LFShopDetail?) {
        self.shopDetail = shop
        collectionView.reloadData()
    }
    
}

class ShopDetailBannerCell: UITableViewCell, UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: BannerScrollInsert.cellId, for: indexPath) as! BannerScrollInsert
        cell.setBanner(ads)
        cell.scrollItemClickHandler = { [weak self] index in
            guard let strongSelf = self else { return }
            if strongSelf.ads.count > index {
                self?.adItemClick?(strongSelf.ads[index])
            }
        }
        return cell
    }
    
    static let cellId = "ShopDetailBannerCell"
    
    var ads = [AdHome]()
    var adItemClick:((_ link: AdHome) ->Void)?
        
    let layout: UICollectionViewFlowLayout = {
        let l = UICollectionViewFlowLayout()
        l.itemSize = BannerScrollInsert.itemSize
        l.sectionInset = UIEdgeInsets.zero
        l.scrollDirection = .horizontal
        return l
    }()
    lazy var collectionView: UICollectionView = {
        let collection = UICollectionView(frame:.zero, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsVerticalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(BannerScrollInsert.classForCoder(), forCellWithReuseIdentifier: BannerScrollInsert.cellId)
        return collection
    }()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        contentView.backgroundColor = .clear
        backgroundColor = .clear
        contentView.addSubview(collectionView)
        collectionView.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setAds(_ models: [AdHome]?) {
        if let ad = models {
            ads = ad
            collectionView.reloadData()
        }
    }
}
