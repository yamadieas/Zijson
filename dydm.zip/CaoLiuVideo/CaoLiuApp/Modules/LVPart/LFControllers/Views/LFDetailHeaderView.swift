
import UIKit

class LFDetailHeaderView: UIView {
    private let layout: UICollectionViewFlowLayout = {
        let l = UICollectionViewFlowLayout()
        l.scrollDirection = .horizontal
        l.itemSize = CGSize(width: screenWidth, height: screenWidth * 4/3)
        l.minimumInteritemSpacing = 0
        l.minimumLineSpacing = 0
        l.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        return l
    }()
    lazy var collView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect.zero, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsHorizontalScrollIndicator = false
        collection.isPagingEnabled = true
        collection.bounces = false
        collection.backgroundColor = .darkText
        collection.register(PictureDetailCell.classForCoder(), forCellWithReuseIdentifier: PictureDetailCell.cellId)
        return collection
    }()
    let indexNumber: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.textAlignment = .center
        label.backgroundColor = UIColor(white: 0, alpha: 0.5)
        label.layer.cornerRadius = 10
        label.layer.masksToBounds = true
        label.font = UIFont.systemFont(ofSize: 12)
        return label
    }()
   
    let titleLab: UILabel = {
        let v = UILabel()
        v.textColor = UIColor.white
        v.numberOfLines = 0
        v.font = UIFont.boldSystemFont(ofSize: 14)
        return v
    }()
    let pusherView: LFPusherView = {
        let v = LFPusherView()
        return v
    }()
    let authImage: UIImageView = {
        let v = UIImageView()
        v.contentMode = .scaleAspectFit
        return v
    }()
    let authStatu: UILabel = {
        let v = UILabel()
        v.textColor = rgb(255, 239, 195)
        v.font = UIFont.boldSystemFont(ofSize: 13)
        return v
    }()
    let authMoneyImage: UIImageView = {
        let v = UIImageView()
        v.contentMode = .scaleAspectFit
        return v
    }()
    let authMoneyInfo: UILabel = {
        let v = UILabel()
        v.textColor = rgb(255, 239, 195)
        v.font = UIFont.boldSystemFont(ofSize: 13)
        return v
    }()

    var lfModel: LFMsgModel?
    var pictures = [String]()
    
    var actionHandler:((_ actionId: Int) -> Void)?
    var pictureTapHandler:((_ index: Int) -> Void)?
    var videoTapHandler:((_ index: Int) -> Void)?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setUpUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUpUI() {
        addSubview(collView)
        addSubview(indexNumber)
        addSubview(titleLab)
        addSubview(pusherView)
        addSubview(authImage)
        addSubview(authMoneyImage)
        addSubview(authStatu)
        addSubview(authMoneyInfo)
        layoutPage()
    }
    @objc func payActionClick(_ sender: UIButton) {
        if sender.tag == 0 {
            return
        }
        actionHandler?(sender.tag)
    }
    
    func setLfInfo(_ model: LFShopDetail) {
        self.lfModel = model.top_mm_info
        if let pics = model.top_mm_info?.images {
            indexNumber.isHidden = pics.count == 0
            if pics.count > 0 {
                if let video = lfModel?.video, !video.isEmpty {
                    indexNumber.text = "1/\(pics.count + 1)"
                } else {
                    indexNumber.text = "1/\(pics.count)"
                }
            }
            pictures = pics
        } else {
            indexNumber.isHidden = true
        }
        pusherView.setModel(model.user_info)
        pusherView.actionHandler = { [weak self] index in
            self?.actionHandler?(index)
        }
        titleLab.attributedText = TextSpaceManager.getAttributeStringWithString(model.top_mm_info?.title ?? "", lineSpace: 5)
        authImage.image = getImage("AuthStatuIcon")
        authStatu.text = "官方认证经纪人"
        authMoneyImage.image = getImage("AuthMoneyIcon")
        authMoneyInfo.text = "已缴纳\(model.shop_info?.deposit_money ?? "")保证金"
        collView.reloadData()
    }
    
}
// MARK: - UICollectionViewDelegate
extension LFDetailHeaderView: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if let video = lfModel?.video, !video.isEmpty {
            return pictures.count + 1
        }
        return pictures.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PictureDetailCell.cellId, for: indexPath) as! PictureDetailCell
        cell.imgV.contentMode = .scaleAspectFill
        cell.showCover()
        if let video = lfModel?.video, !video.isEmpty {
            if indexPath.item == 0 {
                cell.imgV.kfSetVerticalImageWithUrl(pictures[indexPath.item])
                cell.playIcon.isHidden = false
            } else {
                cell.playIcon.isHidden = true
                cell.imgV.kfSetVerticalImageWithUrl(pictures[indexPath.item - 1])
            }
        } else {
            cell.playIcon.isHidden = true
            cell.imgV.kfSetVerticalImageWithUrl(pictures[indexPath.item])
        }
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if let video = lfModel?.video, !video.isEmpty {
            if indexPath.item == 0 {
                videoTapHandler?(indexPath.item)
            } else {
                pictureTapHandler?(indexPath.item - 1)
            }
        } else {
            pictureTapHandler?(indexPath.item)
        }
        
    }
}

// MARK: UIScrollViewDelegate
extension LFDetailHeaderView: UIScrollViewDelegate {
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
         let offsetX = scrollView.contentOffset.x
        if let video = lfModel?.video, !video.isEmpty {
            indexNumber.text = "\(Int(offsetX/screenWidth) + 1)/\(pictures.count + 1)"
        } else {
            indexNumber.text = "\(Int(offsetX/screenWidth) + 1)/\(pictures.count)"
        }
         
    }
}

// MARK: Layout
extension LFDetailHeaderView {
    func layoutPage() {
        collView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.leading.trailing.equalToSuperview()
            make.height.equalTo(screenWidth * 4/3)
        }
        indexNumber.snp.makeConstraints { (make) in
            make.trailing.equalTo(-15)
            make.bottom.equalTo(collView).offset(-12)
            make.height.equalTo(20)
            make.width.equalTo(40)
        }
        titleLab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(indexNumber.snp.leading).offset(-10)
            make.bottom.equalTo(collView).offset(-12)
        }
        pusherView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(collView.snp.bottom).offset(5)
            make.height.equalTo(45)
        }
        authImage.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalTo(pusherView.snp.bottom).offset(15)
            make.height.width.equalTo(18)
        }
        authStatu.snp.makeConstraints { (make) in
            make.leading.equalTo(authImage.snp.trailing).offset(5)
            make.centerY.equalTo(authImage)
        }
        authMoneyImage.snp.makeConstraints { (make) in
            make.leading.equalTo(authStatu.snp.trailing).offset(20)
            make.centerY.equalTo(authImage)
        }
        authMoneyInfo.snp.makeConstraints { (make) in
            make.leading.equalTo(authMoneyImage.snp.trailing).offset(5)
            make.centerY.equalTo(authMoneyImage)
        }
    }
}


class LFOrderView: UIView {
    lazy var orderbtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.backgroundColor = ConstValue.kStypeColor
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        btn.setTitle("立即预约", for: .normal)
        btn.layer.cornerRadius = 22.5
        btn.layer.masksToBounds = true
        btn.addTarget(self, action: #selector(orderBtnclick), for: .touchUpInside)
        return btn
    }()
    let orderCoin: UILabel = {
        let v = UILabel()
        v.textColor = .white
        v.font = UIFont.boldSystemFont(ofSize: 17)
        return v
    }()
    let moneyLab: UILabel = {
        let v = UILabel()
        v.textColor = UIColor.lightGray
        v.font = UIFont.systemFont(ofSize: 13)
        return v
    }()
    var orderAction:(() ->Void)?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(orderbtn)
        addSubview(orderCoin)
        addSubview(moneyLab)
        layoutpages()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @objc func orderBtnclick() {
        orderAction?()
    }
    func setModel(_ model: LFMsgModel) {
        orderCoin.text = "服务定金: \(model.decide_coins ?? 0)钻石"
        let change = Int(UserModel.share().authInfo?.config?.rule?.service_change ?? "5") ?? 5
        moneyLab.text = "可在服务时抵扣 \((model.decide_coins ?? 0) / change)元"
    }
    func layoutpages() {
        orderbtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-12)
            make.centerY.equalToSuperview()
            make.height.equalTo(45)
            make.width.equalTo(120)
        }
        orderCoin.snp.makeConstraints { (make) in
            make.leading.equalTo(16)
            make.top.equalTo(orderbtn)
            make.trailing.equalTo(orderbtn.snp.leading).offset(-12)
        }
        moneyLab.snp.makeConstraints { (make) in
            make.leading.equalTo(orderCoin)
            make.bottom.equalTo(orderbtn)
            make.trailing.equalTo(orderCoin)
        }
    }
}
