
import UIKit
import MJRefresh
import NicooNetwork
import JXPagingView

class LFMsgListController: UIViewController {
    private let layout = UICollectionViewFlowLayout()
    lazy var collView: UICollectionView = {
        layout.sectionHeadersPinToVisibleBounds = true
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsVerticalScrollIndicator = false
        collection.backgroundColor = UIColor.clear
        collection.register(LFHightLevelListCell.classForCoder(), forCellWithReuseIdentifier: LFHightLevelListCell.cellId)
        collection.register(CityChoseTipView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: CityChoseTipView.identifier)
        collection.mj_header = refreshView
        collection.mj_footer = loadMoreView
        return collection
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
        loadmore?.setTitle("", for: .idle)
        loadmore?.setTitle("已經到底了", for: .noMoreData)
        loadmore?.stateLabel.font = ConstValue.kRefreshLableFont
        return loadmore!
    }()
    lazy private var refreshView: MJRefreshNormalHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshNormalHeader(refreshingBlock: {
            weakSelf?.loadFirstPage()
        })
        mjRefreshHeader?.activityIndicatorViewStyle = .white
        mjRefreshHeader?.arrowView.image = ConstValue.refreshImg
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    private lazy var lfMsgListApi: LFMMListApi =  {
        let api = LFMMListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var lfMsgDelApi: LFMsgDeleteApi =  {
        let api = LFMsgDeleteApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    var cityHeader: CityChoseTipView?
    var listViewDidScrollCallback: ((UIScrollView) -> ())?
    let viewModel = VideoViewModel()
    
    var lfCityModel: LFModuleModel?
    var cityModels = [LFLocalModel]()
    var lfModels = [LFMsgModel]()
    
    var currentProvince: String?
    var currentCity: String?
    var shopModel: LFShopModel?
    
    var currentLFModel: LFMsgModel?
    
    var isShopInfo: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(collView)
        layoutPageSubviews()
        loadData()
    }
    private func loadData() {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = lfMsgListApi.loadData()
    }
    private func loadFirstPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = lfMsgListApi.loadData()
    }
    private func loadNextPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        let _ = lfMsgListApi.loadNextPage()
    }
    private func endRefreshing() {
        refreshView.endRefreshing()
        loadMoreView.endRefreshing()
    }
   
}

extension LFMsgListController {
    func goCitysChose() {
        let vc = CityChoseController()
        if isShopInfo {
            vc.isUserSearch = false
        } else {
            vc.isUserSearch = cityModels.count == 0 /// 没有地区表示是用户搜索
        }
        vc.lfCityModels = cityModels
        vc.choseCityCallBack = { [weak self] (p, c) in
            self?.currentProvince = p
            self?.currentCity = c
            self?.loadData()
            vc.dismiss(animated: false, completion: nil)
        }
        vc.modalPresentationStyle = .fullScreen
        present(vc, animated: false, completion: nil)
    }
    func showActionSheet(_ model: LFMsgModel) {
        let sheet = UIAlertController.init(title: nil, message: "\(model.title ?? "")", preferredStyle: .actionSheet)
        sheet.view.tintColor = UIColor.darkText
        let action1 = UIAlertAction(title: "编辑", style: .default) { (alert) in
            let push = LFPushInfosController()
            push.inputModel = model
            push.isEdit = true
            self.navigationController?.pushViewController(push, animated: true)
        }
        let action2 = UIAlertAction(title: "删除", style: .default) { (alert) in
            self.deleteLf(model)
        }
        let action3 = UIAlertAction(title: "取消", style: .cancel, handler: nil)
        sheet.addAction(action2)
        sheet.addAction(action1)
        sheet.addAction(action3)
        present(sheet, animated: true, completion: nil)
    }
    private func deleteLf(_ model: LFMsgModel) {
        currentLFModel = model
        showDialog(title: nil, message: "\n确认删除当前约啪信息？\n", okTitle: "删除", cancelTitle: "取消", okHandler: {
            _ = self.lfMsgDelApi.loadData()
        }, cancelHandler: nil)
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension LFMsgListController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return LFHightLevelListCell.itemSize
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsets(top: 10, left: 15, bottom: 5, right: 15)
    }

    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
        return CityChoseTipView.headerSizeSg
    }
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: CityChoseTipView.identifier, for: indexPath) as! CityChoseTipView
        if currentProvince != nil {
            if currentCity != nil {
                header.setTitle("\(currentProvince!) · \(currentCity!)")
            } else {
                header.setTitle("\(currentProvince!)")
            }
        } else {
            if currentCity != nil {
               header.setTitle("\(currentCity!)")
            } else {
               header.setTitle("全部")
            }
        }
        header.cityItemTapHandler = { [weak self] in
            self?.goCitysChose()
        }
        cityHeader  = header
        return header
    }
}
// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension LFMsgListController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return lfModels.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LFHightLevelListCell.cellId, for: indexPath) as! LFHightLevelListCell
        let model = lfModels[indexPath.item]
        cell.setLFMsgModel(model)
        if isShopInfo {
            cell.menuImg.isHidden = true
            cell.menuBtn.isHidden = true
        } else {
            cell.menuImg.isHidden = cityModels.count == 0
            cell.menuBtn.isHidden = cityModels.count == 0
        }
        if cityModels.count > 0 {
            cell.menuClick = { [weak self] in
                self?.showActionSheet(model)
            }
        }
       
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        let model = lfModels[indexPath.item]
        let vc = LFMMShowCcontroller()
        vc.lfmodel = model
        navigationController?.pushViewController(vc, animated: true)
    }
}

// MARK: - UIScrollViewDelegate
extension LFMsgListController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        listViewDidScrollCallback?(scrollView)
    }
}

extension LFMsgListController: JXPagingViewListViewDelegate {
    func listView() -> UIView {
        return self.view
    }
    
    func listScrollView() -> UIScrollView {
        return collView
    }
    
    func listViewDidScrollCallback(callback: @escaping (UIScrollView) -> ()) {
        listViewDidScrollCallback = callback
    }
}
// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension LFMsgListController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is LFMsgDeleteApi {
            var params = [String : Any]()
            params[LFMsgDeleteApi.kfloor_id] = currentLFModel?.id
            return params
        }
        if manager is LFMMListApi {
            var params = [String : Any]()
            if currentProvince != nil && !currentProvince!.isEmpty {
                params[LFMMListApi.kProvince] = currentProvince
            }
            if currentCity != nil && !currentCity!.isEmpty {
                if currentCity == "全部" {
                    params[LFMMListApi.kCity] = nil
                } else {
                    params[LFMMListApi.kCity] = currentCity
                }
                
            }
            params[LFMMListApi.kShopCode] = shopModel?.code
            return params
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        endRefreshing()
        if manager is LFMMListApi {
            if let datas = manager.fetchJSONData(VideoReformer()) as? [LFMsgModel] {
                if lfMsgListApi.pageNumber == 1 {
                    lfModels = datas
                    if lfModels.count == 0 {
                        NicooErrorView.showErrorMessage(.noData, on: view, topMargin: 50) {
                            self.loadData()
                        }
                    }
                } else {
                    lfModels.append(contentsOf: datas)
                }
                loadMoreView.isHidden = datas.count == 0
                collView.reloadData()
            }
        }
        if manager is LFMsgDeleteApi {
            XSAlert.show(type: .text, text: "删除成功")
            lfModels.removeAll { (model) -> Bool in
                return model.id == self.currentLFModel?.id
            }
            collView.reloadData()
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        endRefreshing()
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: 60) {
            self.loadData()
        }
    }
}

// MARK: - Layout
private extension LFMsgListController {
    
    func layoutPageSubviews() {
        layoutCollection()
    }
    func layoutCollection() {
        collView.snp.makeConstraints { (make) in
            make.top.equalToSuperview()
            make.leading.trailing.equalToSuperview()
            make.bottom.equalToSuperview().offset(0)
        }
    }
    
}
// MARK: - CLNavigationBarDelegate
extension LFMsgListController:  CLNavigationBarDelegate  {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}
