
import UIKit
import NicooNetwork

class CityChoseController: CLBaseViewController {

    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.navBackBlack = false
        bar.titleLabel.text = "选择地区"
        bar.delegate = self
        return bar
    }()
    private lazy var tableP: UITableView = {
        let table = UITableView()
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.showsHorizontalScrollIndicator = false
        table.allowsSelection = true
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.register(CityItemCell.classForCoder(), forCellReuseIdentifier: CityItemCell.cellId)
        return table
    }()
    private lazy var tableC: UITableView = {
        let table = UITableView()
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.showsHorizontalScrollIndicator = false
        table.allowsSelection = true
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.register(CityItemCell.classForCoder(), forCellReuseIdentifier: CityItemCell.cellId)
        return table
    }()
    let vLine: UIView = {
        let v = UIView()
        v.backgroundColor = ConstValue.kAppSepLineColor
        return v
    }()
    private lazy var lfCityApi: LFLocalListApi =  {
        let api = LFLocalListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
 
    var isUserSearch: Bool = false

    var lfCityModels = [LFLocalModel]()
    var pSelectedIndex: Int = 0
    var sonSelectedIndex: Int = -1
    
    var choseCityCallBack:((_ province: String?, _ city: String?) ->Void)?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpNavBar()
        setUpUI()
        if lfCityModels.count == 0 {
            loadCityData()
        }
    }

    func setUpNavBar() {
        view.addSubview(navBar)
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
    }
    func setUpUI() {
        view.addSubview(tableP)
        view.addSubview(vLine)
        view.addSubview(tableC)
        tableP.snp.makeConstraints { (make) in
            make.leading.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom)
            make.width.equalTo(130)
            make.bottom.equalToSuperview()
        }
        vLine.snp.makeConstraints { (make) in
            make.leading.equalTo(tableP.snp.trailing)
            make.top.equalTo(navBar.snp.bottom)
            make.width.equalTo(0.6)
            make.bottom.equalToSuperview()
        }
        tableC.snp.makeConstraints { (make) in
            make.leading.equalTo(vLine.snp.trailing)
            make.top.equalTo(navBar.snp.bottom)
            make.trailing.equalToSuperview().offset(-(screenWidth - 130)/4)
            make.bottom.equalToSuperview()
        }
    }

    private func loadCityData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        lfCityApi.isUserSearch = self.isUserSearch
        let _ = lfCityApi.loadData()
    }
    
}

extension CityChoseController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if tableView == tableP {
            return lfCityModels.count
        } else if tableView == tableC {
            if lfCityModels.count > pSelectedIndex {
                return isUserSearch ? lfCityModels[pSelectedIndex].search_son_city?.count ?? 0 : lfCityModels[pSelectedIndex].son_city?.count ?? 0
            }
        }
        return 0
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 35
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: CityItemCell.cellId, for: indexPath) as! CityItemCell
        if tableView == tableP {
            cell.cityLable.text = lfCityModels[indexPath.row].province
            cell.cityLable.backgroundColor = pSelectedIndex == indexPath.row ? ConstValue.kAppSepLineColor : .clear
        } else if tableView == tableC {
            if isUserSearch {
                if let sonCitys = lfCityModels[pSelectedIndex].search_son_city {
                    cell.cityLable.text = sonCitys[indexPath.row].city
                    cell.cityLable.backgroundColor = sonSelectedIndex == indexPath.row ? ConstValue.kAppSepLineColor : .clear
                }
            } else {
                if let sonCitys = lfCityModels[pSelectedIndex].son_city {
                    cell.cityLable.text = sonCitys[indexPath.row].city
                    cell.cityLable.backgroundColor = sonSelectedIndex == indexPath.row ? ConstValue.kAppSepLineColor : .clear
                }
            }
            
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if tableView == tableP {
            pSelectedIndex = indexPath.row
            sonSelectedIndex = -1
            tableP.reloadData()
            tableC.reloadData()
            if lfCityModels.count > pSelectedIndex {
                let p = lfCityModels[pSelectedIndex].province
                if p == "全部" {
                    choseCityCallBack?(nil,nil)
                }
            }
        } else if tableView == tableC {
            sonSelectedIndex = indexPath.row
            tableC.reloadData()
            /// 这里回调
            var p: String? = nil
            var c: String? = nil
            if lfCityModels.count > pSelectedIndex {
                p = lfCityModels[pSelectedIndex].province
                if isUserSearch {
                    if let cs = lfCityModels[pSelectedIndex].search_son_city, cs.count > sonSelectedIndex {
                        c = cs[sonSelectedIndex].city
                    }
                } else {
                    if let cs = lfCityModels[pSelectedIndex].son_city, cs.count > sonSelectedIndex {
                        c = cs[sonSelectedIndex].city
                    }
                }
            }
            choseCityCallBack?(p,c)
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension CityChoseController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is LFLocalListApi {
            if let module = manager.fetchJSONData(VideoReformer()) as? [LFLocalModel] {
                lfCityModels = module
                if isUserSearch {
                    let allCity = LFLocalModel()
                    allCity.province = "全部"
                    allCity.search_son_city = nil
                    lfCityModels.insert(allCity, at: 0)
                }
                tableP.reloadData()
                tableC.reloadData()
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
    }
}


extension CityChoseController: CLNavigationBarDelegate {
    func backAction() {
        dismiss(animated: false, completion: nil)
    }
}

class CityItemCell: UITableViewCell {
     static let cellId = "CityItemCell"
    let cityLable: UILabel = {
        let v = UILabel()
        v.font = UIFont.systemFont(ofSize: 14)
        v.textAlignment = .center
        v.textColor = .white
        return v
    }()
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = .clear
        contentView.backgroundColor = .clear
        contentView.addSubview(cityLable)
        cityLable.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}
