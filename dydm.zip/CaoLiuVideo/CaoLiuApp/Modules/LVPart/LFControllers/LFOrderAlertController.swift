
import UIKit

class LFOrderAlertController: UIViewController {

    let alertView: UIView = {
        let v = UIView()
        v.backgroundColor = UIColor.white
        v.layer.cornerRadius = 25
        v.layer.masksToBounds = true
        return v
    }()
    let userHeader: UIImageView = {
        let img = UIImageView()
        img.isUserInteractionEnabled = true
        img.layer.cornerRadius = 15
        img.layer.masksToBounds = true
        return img
    }()
    let nickName: UILabel = {
        let lab = UILabel()
        lab.textColor = UIColor.darkText
        lab.font = UIFont.systemFont(ofSize: 14)
        return lab
    }()
   
    let pinfoName: UILabel = {
        let lab = UILabel()
        lab.textColor = UIColor.darkText
        lab.textAlignment = .center
        lab.numberOfLines = 0
        lab.font = UIFont.systemFont(ofSize: 14)
        return lab
    }()
    let coinsLab: UILabel = {
        let lab = UILabel()
        lab.textColor = ConstValue.kStypeColor
        lab.textAlignment = .center
        lab.font = UIFont.systemFont(ofSize: 17)
        return lab
    }()
    let moneyLab: UILabel = {
        let lab = UILabel()
        lab.textColor = UIColor.gray
        lab.textAlignment = .center
        lab.font = UIFont.systemFont(ofSize: 13)
        return lab
    }()
    let tipslab: UILabel = {
        let lab = UILabel()
        lab.textColor = UIColor.gray
        lab.textAlignment = .center
        lab.numberOfLines = 0
        lab.font = UIFont.systemFont(ofSize: 13)
        return lab
    }()
    lazy var commitBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitle("立即预约", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        btn.layer.cornerRadius = 24
        btn.layer.masksToBounds = true
        btn.backgroundColor = ConstValue.kStypeColor
        btn.addTarget(self, action: #selector(commit), for: .touchUpInside)
        return btn
    }()
    var lfModel: LFMsgModel?
    
    var commitHandler:(() -> Void)?
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(white: 0, alpha: 0.95)

        view.addSubview(alertView)
        view.addSubview(coinsLab)
        view.addSubview(moneyLab)
        view.addSubview(pinfoName)
        view.addSubview(userHeader)
        view.addSubview(nickName)
        view.addSubview(tipslab)
        view.addSubview(commitBtn)
        coinsLab.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
        }
        moneyLab.snp.makeConstraints { (make) in
            make.top.equalTo(coinsLab.snp.bottom).offset(10)
            make.centerX.equalTo(coinsLab)
        }
        tipslab.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(moneyLab.snp.bottom).offset(25)
            make.width.equalTo(235)
        }
        commitBtn.snp.makeConstraints { (make) in
            make.top.equalTo(tipslab.snp.bottom).offset(24)
            make.height.equalTo(48)
            make.centerX.equalToSuperview()
            make.width.equalTo(250)
        }
        pinfoName.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(coinsLab.snp.top).offset(-28)
            make.width.equalTo(200)
        }
        nickName.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview().offset(25)
            make.bottom.equalTo(pinfoName.snp.top).offset(-35)
        }
        userHeader.snp.makeConstraints { (make) in
            make.trailing.equalTo(nickName.snp.leading).offset(-5)
            make.centerY.equalTo(nickName)
            make.height.width.equalTo(30)
        }
        alertView.snp.makeConstraints { (make) in
            make.top.equalTo(userHeader.snp.top).offset(-28)
            make.leading.equalTo(tipslab).offset(-40)
            make.trailing.equalTo(tipslab).offset(40)
            make.bottom.equalTo(commitBtn.snp.bottom).offset(28)
        }
        setLfModel()
    }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
       self.dissMiss()
    }
    @objc func commit() {
        commitHandler?()
    }
    func setLfModel() {
        userHeader.kfsetHeader(lfModel?.user_info?.avatar)
        nickName.text = lfModel?.user_info?.nick
        pinfoName.attributedText = TextSpaceManager.getAttributeStringWithString("该商家已在本平台完成信息认证\n在线预约可享受优惠折扣", lineSpace: 5, .center)
        coinsLab.text = "服务定金：\(lfModel?.decide_coins ?? 0)钻石"
        let change = Int(UserModel.share().authInfo?.config?.rule?.service_change ?? "5") ?? 5
        moneyLab.text = "可在服务时抵扣\((lfModel?.decide_coins ?? 0)/change)元"
        let returnCoins = Int(UserModel.share().authInfo?.config?.rule?.service_return_rate ?? "0") ?? 0
        let coins = (lfModel?.decide_coins ?? 0)/returnCoins
        tipslab.attributedText = TextSpaceManager.getAttributeStringWithString("提示：服务完成后，在约啪订单发布约啪体验可获得\(coins)钻石奖励", lineSpace: 5, .center)
    }
    /// 弹框消失
    func dissMiss() {
        self.dismiss(animated: false, completion: nil)
    }

}


class OrderSuccessController: CLBaseViewController {
    let successImg: UIImageView = {
        let img = UIImageView(image: LGConfig.getImage("followSuccess"))
        img.contentMode = .scaleAspectFit
        img.layer.cornerRadius = 40
        img.layer.masksToBounds = true
        img.backgroundColor = UIColor.gray
        return img
    }()
    let infoText: UILabel = {
        let lab = UILabel()
        lab.textAlignment = .center
        lab.text = "预约成功"
        lab.font = UIFont.boldSystemFont(ofSize: 24)
        lab.textColor = .white
        return lab
    }()
    let desText: UILabel = {
        let lab = UILabel()
        lab.textAlignment = .center
        lab.numberOfLines = 0
        lab.text = "快去添加商家联系方式\n或发私信为您安排服务"
        lab.font = UIFont.systemFont(ofSize: 15)
        lab.textColor = .lightGray
        return lab
    }()
    let tiplab: UILabel = {
        let lab = UILabel()
        lab.textAlignment = .left
        lab.numberOfLines = 0
        lab.font = UIFont.systemFont(ofSize: 15)
        lab.textColor = .lightGray
        return lab
    }()
    lazy var sendAgainBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitleColor(ConstValue.kStypeColor, for: .normal)
        btn.setTitle("继续预约", for: .normal)
        btn.layer.cornerRadius = 24
        btn.layer.masksToBounds = true
        btn.layer.borderColor = ConstValue.kStypeColor.cgColor
        btn.layer.borderWidth = 1
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        btn.tag = 1
        btn.addTarget(self, action: #selector(btnClick(_:)), for: .touchUpInside)
        return btn
    }()
    lazy var myBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitleColor(.white, for: .normal)
        btn.backgroundColor = ConstValue.kStypeColor
        btn.layer.cornerRadius = 24
        btn.layer.masksToBounds = true
        btn.setTitle("约啪订单", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        btn.tag = 2
        btn.addTarget(self, action: #selector(btnClick(_:)), for: .touchUpInside)
        return btn
    }()
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    var infoModel: LFMsgModel?
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(navBar)
        view.addSubview(successImg)
        view.addSubview(infoText)
        view.addSubview(desText)
        view.addSubview(sendAgainBtn)
        view.addSubview(myBtn)
        view.addSubview(tiplab)
        layoutToppart()
        layoutSubs()
      
        let returnCoins = Int(UserModel.share().authInfo?.config?.rule?.service_return_rate ?? "0") ?? 0
        let coins = (infoModel?.decide_coins ?? 0)/returnCoins
        tiplab.text = "提示：服务完成后，在约啪订单发布约啪体验可获得\(coins)钻石奖励"
    }
    @objc func btnClick(_ sender: UIButton) {
        if sender.tag == 1 {
            navigationController?.popViewController(animated: true)
        } else if sender.tag == 2 {
            let vc = LFOrdersController()
            navigationController?.pushViewController(vc, animated: true)
        }
    }
    func layoutSubs() {
        successImg.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom).offset(100)
            make.width.height.equalTo(80)
        }
        infoText.snp.makeConstraints { (make) in
            make.leading.equalTo(40)
            make.trailing.equalTo(-40)
            make.top.equalTo(successImg.snp.bottom).offset(20)
        }
        desText.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(infoText)
            make.top.equalTo(infoText.snp.bottom).offset(20)
        }
        myBtn.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(infoText)
            make.bottom.equalTo(-40)
            make.height.equalTo(48)
        }
        sendAgainBtn.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(infoText)
            make.bottom.equalTo(myBtn.snp.top).offset(-15)
            make.height.equalTo(48)
        }
        tiplab.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(sendAgainBtn)
            make.bottom.equalTo(sendAgainBtn.snp.top).offset(-15)
        }
    }
    func layoutToppart() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
    }

}

extension OrderSuccessController: CLNavigationBarDelegate {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}
