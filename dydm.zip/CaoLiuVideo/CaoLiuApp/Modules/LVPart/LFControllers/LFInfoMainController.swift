
import UIKit
import JXSegmentedView

class LFInfoMainController: CLBaseViewController {

    var titles = [String]()
    let dataSource = JXSegmentedTitleDataSource()
    let segmentedView = JXSegmentedView()
    lazy var listContainerView: JXSegmentedListContainerView! = {
        return JXSegmentedListContainerView(dataSource: self)
    }()
    
    let list0 = LFShopListController()
    let list1 = LFShopListController()
    let list2 = LFShopListController()
    
    var channels = [ChannelModel]()
    private let viewModel = VideoViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = ConstValue.kVcViewColor
        titles = ["想约","经纪人","认证女神"]
        loadChannels()
    }
    func loadChannels() {
        NicooErrorView.removeErrorMeesageFrom(view)
        viewModel.loadChannelListData([ChannelListApi.kPosition: 2]) { [weak self] (models) in
            self?.channels = models
            self?.setUpPage()
        } failHandler: { [weak self] (error) in
            guard let strongSelf = self else { return }
            NicooErrorView.showErrorMessage(.noNetwork, on: strongSelf.view) {
                strongSelf.loadChannels()
            }
        }
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        listContainerView.frame = CGRect(x: 0, y: statusBarHeight + 44, width: screenWidth, height: screenHeight)
    }
    func setUpPage() {
        var titleHave = [String]()
        if channels.count > 0 {
            let strs = channels.map { (model) -> String in
                return model.title ?? "未知"
            }
            titleHave.append(contentsOf: strs)
        }
        titles.append(contentsOf: titleHave)
        dataSource.titles = titles
        dataSource.titleNormalFont = UIFont.boldSystemFont(ofSize: 16)
        dataSource.titleSelectedFont = UIFont.boldSystemFont(ofSize: 20)
        dataSource.titleNormalColor = UIColor(white: 1, alpha: 0.75)
        dataSource.titleSelectedColor = .white
        dataSource.itemSpacing = 20
        dataSource.isItemSpacingAverageEnabled = false
        segmentedView.defaultSelectedIndex = 1
        listContainerView.defaultSelectedIndex = 1
        segmentedView.frame = CGRect(x: 0, y: statusBarHeight, width: screenWidth, height: 44)
        segmentedView.dataSource = dataSource
        
        view.addSubview(listContainerView)
        view.addSubview(segmentedView)
        segmentedView.listContainer = listContainerView
       
    }
}
extension LFInfoMainController: JXSegmentedListContainerViewDataSource {
    func numberOfLists(in listContainerView: JXSegmentedListContainerView) -> Int {
        if let titleDataSource = segmentedView.dataSource as? JXSegmentedBaseDataSource {
            return titleDataSource.dataSource.count
        }
        return 0
    }

    func listContainerView(_ listContainerView: JXSegmentedListContainerView, initListAt index: Int) -> JXSegmentedListContainerViewListDelegate {
        if index == 0 {
            list0.isShop = false
            list0.isFavor = true
            return list0
        } else if index == 1 {
            list1.isShop = true
            return list1
        } else if index == 2 {
            list2.isShop = false
            return list2
        } else {
            let channel = channels[index - 3]
            let type = channel.type ?? ModulePageType.Module
            if type == .Module {
               if let urlstr = channel.url, !urlstr.isEmpty, let url = URL(string: urlstr) {
                   let h5VC = AAViewController.init(url: url)
                   h5VC.position = .InYuePa
                   h5VC.segIndex = index
                   return h5VC
               }
            } else if type == .H5 {
                let vc = GameListControlller()
                vc.position = .InYuePa
                return vc
            }
            let defaultVC = AAViewController(url: URL(string: UserModel.share().authInfo?.config?.sys?.share_url ?? "")!)
            defaultVC.position = .InYuePa
            return defaultVC
        }
    }
}

