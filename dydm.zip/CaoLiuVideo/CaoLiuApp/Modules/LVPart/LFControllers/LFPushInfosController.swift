
import UIKit
import NicooNetwork
import AssetsLibrary
import Photos


class LFPushInfosController: CLBaseViewController {
    
    static let infoTitles = ["MM简介(30字内)","地区 *","是否设为推荐"]
    static let placeHodlers = ["MM昵称、年龄、身材、服务等","",""]
   
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    private lazy var pushBtn: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = ConstValue.kStypeColor
        button.titleLabel?.font = UIFont.systemFont(ofSize: 14)
        button.setTitle("发布", for: .normal)
        button.layer.cornerRadius = 15
        button.layer.masksToBounds = true
        button.addTarget(self, action: #selector(pushBtnClick(_:)), for: .touchUpInside)
        return button
    }()
    private lazy var tableView: UITableView = {
        let table = UITableView.init(frame: .zero, style: .grouped)
        table.backgroundColor = UIColor.clear
        table.showsVerticalScrollIndicator = false
        table.delegate = self
        table.dataSource = self
        table.separatorStyle = .none
        table.register(LFInfoInPut1Cell.classForCoder(), forCellReuseIdentifier: LFInfoInPut1Cell.cellId)
         table.register(LFInfoInPut2Cell.classForCoder(), forCellReuseIdentifier: LFInfoInPut2Cell.cellId)
        table.register(LFInfoInPut3Cell.classForCoder(), forCellReuseIdentifier: LFInfoInPut3Cell.cellId)
        table.register(UINib(nibName: "SettingCell", bundle: Bundle.main), forCellReuseIdentifier: SettingCell.cellId)
        return table
    }()
    let footView: UIView = {
        let v = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 165 + (screenWidth-35)))
        v.backgroundColor = ConstValue.kVcViewColor
        return v
    }()
    
    private lazy var videoChoseView: VideoChoseView = {
        let view = VideoChoseView.init(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 130 + (screenWidth-35)/3))
        return view
    }()
    private lazy var photoView: PhotoChoseView = {
        let view = PhotoChoseView.init(frame: CGRect(x: 0, y: 0, width: ConstValue.kScreenWdith, height: (screenWidth-35) * 2/3 + 5))
        view.backgroundColor = UIColor.clear
        view.customLayout.itemSize = CGSize(width: (screenWidth - 35)/3, height: (screenWidth - 35)/3)
        view.customLayout.scrollDirection = .vertical
        view.customLayout.minimumLineSpacing = 5
        view.customLayout.minimumInteritemSpacing = 5
        view.maxCount = 5
        return view
    }()
    private lazy var lfInfoApi: LFMsgDetailApi =  {
        let api = LFMsgDetailApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var videoUpLoad: UploadVideoTool = {
        let upload = UploadVideoTool()
        upload.delegate = self
        return upload
    }()
    private lazy var imageUpLoad: UploadImageTool = {
        let upload = UploadImageTool()
        upload.delegate = self
        return upload
    }()
    private lazy var pushApi: LFInfoPushApi = {
        let api = LFInfoPushApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    var lfModelId: Int?
    var comments = [LFCommentModel]()
    var currentProvince: String?
    var currentCity: String?
    var inputModel: LFMsgModel?
    var canSave: Bool = false
    var isEdit: Bool = false
    var commitImageNames = [String]()
    var commitVideoUrl: URL?
       
    /// 上传第几张图
    var uploadImageIndex: Int = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        navBar.titleLabel.text = "发布的约啪信息"
        view.addSubview(navBar)
        navBar.navBarView.addSubview(pushBtn)
        view.addSubview(tableView)
        footView.addSubview(videoChoseView)
        footView.addSubview(photoView)
        layoutPageSubviews()
        tableView.tableFooterView = footView
        if isEdit {
            pushBtn.setTitle("重新发布", for: .normal)
            pushBtn.snp.updateConstraints { (make) in
                make.width.equalTo(80)
            }
            if let images = inputModel?.images, images.count > 0 {
                photoView.setUrlPictures(images)
            }
            if let video = inputModel?.video, !video.isEmpty {
                videoChoseView.videoAddBtn.kfSetHorizontalBackgroundImageWithUrl(inputModel?.cover)
            }
        }
        photoView.addPictureAction = { [weak self] in
            self?.openLocalPhotoAlbum()
        }
        photoView.deletePictureAction = { [weak self]  in
            guard let strongSelf = self else { return }
            if strongSelf.inputModel?.isLocal ?? false {
                strongSelf.canSave = true
            }
            strongSelf.inputModel?.images = strongSelf.photoView.pictureUrls
        }
        videoChoseView.addBtnAction = { [weak self] in
            self?.choseVideoFromLibrary()
        }
        videoChoseView.deletedAction = { [weak self] in
            try? FileManager.sharedInstance.removeItem(at: FileManager.videoExportURL)
            self?.inputModel?.video = nil
            self?.videoChoseView.videoDelBtn.isHidden = true
            self?.videoChoseView.videoAddBtn.setBackgroundImage(LGConfig.getImage("pushPictureAdd"), for: .normal)
        }
        if inputModel?.isLocal ?? false { // 本地草稿
            if let localDatas = UserDefaults.standard.value(forKey: UserDefaults.kLocalLFImageDatas) as? [Data] {
                var localImages = [UIImage]()
                for data in localDatas {
                    if let image = UIImage.init(data: data) {
                        localImages.append(image)
                    }
                }
                if localImages.count > 0 {
                    photoView.setPictures(localImages)
                }
                if FileManager.sharedInstance.fileExists(atPath: FileManager.videoExportPath) {
                    if localImages.count > 0 {
                        videoChoseView.videoAddBtn.setBackgroundImage(localImages[0], for: .normal)
                    } else {
                        if let videoFirstImg = getVideoFirstImage() {
                            videoChoseView.videoAddBtn.setBackgroundImage(videoFirstImg, for: .normal)
                        }
                    }
                }
            } else {
                if FileManager.sharedInstance.fileExists(atPath: FileManager.videoExportPath) {
                    if let videoFirstImg = getVideoFirstImage() {
                        videoChoseView.videoAddBtn.setBackgroundImage(videoFirstImg, for: .normal)
                    }
                }
            }
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = false
    }
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        self.navigationController?.interactivePopGestureRecognizer?.isEnabled = true
    }
    func loadLfInfo() {
         XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        _ = lfInfoApi.loadData()
    }
    @objc func pushBtnClick(_ sender: UIButton) {
        tapScaleDownAnimation(sender)
        if inputModel == nil {
            XSAlert.show(type: .text, text: "请完善信息")
            return
        }
        if inputModel!.title == nil || inputModel!.title!.isEmpty {
            XSAlert.show(type: .text, text: "请填写标题")
            return
        }
        if inputModel!.city == nil || inputModel!.city!.isEmpty {
            XSAlert.show(type: .text, text: "请选择城市")
            return
        }
        if (photoView.pictures.count + photoView.pictureUrls.count) == 0 {
            XSAlert.show(type: .text, text: "请选择MM图片")
            return
        }
        if photoView.pictures.count > 0 { // 如果选择了本地图片
            uploadImage(0)
        } else {
            if commitVideoUrl != nil { // 选择视频，上传
                /// 上传视频
                XSProgressHUD.showProgress(msg: "视频上传中...", onView: view, animated: false)
                videoUpLoad.upload(FileManager.videoExportURL)
            } else { // 没有选择视频， 不需要上传
                commitPush()
            }
        }
    }
    /// 从相册选择视频
    func choseVideoFromLibrary() {
        UserModel.share().isPushLF = true
        let storyboard: UIStoryboard = UIStoryboard(name: "Thumbnail", bundle: nil)
        let vc: ThumbnailViewController = storyboard.instantiateViewController(withIdentifier: "Thumbnail") as! ThumbnailViewController
        vc.videoChoseHandler = { (asset) in
            DLog("videoChoseHandler.asset= \(asset)")
            self.libraryVideoEditor(asset: asset)
        }
        vc.modalPresentationStyle = .fullScreen
        self.present(vc, animated: true, completion: nil)
    }
    /// 选择视频编辑
    private func libraryVideoEditor(asset: PHAsset) {
        switch asset.mediaType {
        case .video:
            let storyboard: UIStoryboard = UIStoryboard(name: "VT", bundle: nil)
            let vc: VTViewController = storyboard.instantiateViewController(withIdentifier: "VT") as! VTViewController
            vc.asset = asset
            vc.sourceType = .Source_Library
            vc.applyCheckDoneActionHandler = { [weak self] image in
                guard let strongself = self else {
                    return
                }
                strongself.videoChoseView.videoAddBtn.setBackgroundImage(image, for: .normal)
                
                strongself.commitVideoUrl = FileManager.videoExportURL
                strongself.videoChoseView.videoDelBtn.isHidden = false
                if !strongself.isEdit {
                    strongself.canSave = true
                }
               // self?.videoUpLoad.upload(FileManager.videoExportURL)
            }
            //vc.camareVideoPath = FileManager.videoExportURL
            self.navigationController?.pushViewController(vc, animated: false)
        default:
            break
        }
    }
    func commitPush() {
        NicooErrorView.removeErrorMeesageFrom(view)
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        pushApi.isEdit = isEdit
        _ = pushApi.loadData()
    }

    // MARK: - 相册选图
    private func openLocalPhotoAlbum() {
        _ = self.jh_presentPhotoVC(5 - self.photoView.pictures.count - self.photoView.pictureUrls.count, completeHandler: {  [weak self]  items in
            guard let strongSelf = self else { return }
            if items.count == 0 { return }
            var pictures = strongSelf.photoView.pictures
            for item in items {
                let _ = item.originalImage({ (originImage) in
                    pictures.append(originImage)
                })
            }
            //strongSelf.uploadView.uploadButton.isEnabled = pictures.count > 0
            strongSelf.photoView.setPictures(pictures)
            if !strongSelf.isEdit {
                strongSelf.canSave = true
            }
        })
    }
    /// 开始上床
    private func uploadImage(_ currentIndex: Int) {
        
        if photoView.pictures.count > currentIndex {
            imageUpLoad.upload(photoView.pictures[currentIndex])
        } else {
           // 图片上传完成
            XSProgressHUD.hide(for: view, animated: false)
            if inputModel == nil {
                inputModel = LFMsgModel()
            }
            var oldPictureUrl = photoView.pictureUrls
            oldPictureUrl.append(contentsOf: commitImageNames)
            inputModel?.images = oldPictureUrl
            if commitVideoUrl != nil { // 选择视频，上传
                /// 上传视频
                XSProgressHUD.showProgress(msg: "视频上传中...", onView: view, animated: false)
                videoUpLoad.upload(FileManager.videoExportURL)
            } else { // 没有选择视频， 不需要上传
                commitPush()
            }
        }
    }

}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension LFPushInfosController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 0
    }
   
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        return nil
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if section == 0 {
            return 80
        }
        return 0
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        if section == 0  {
            let v = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 80))
            v.backgroundColor = ConstValue.kVcViewColor
            let v1 = UIView(frame: CGRect(x: 15, y: 7.5, width: screenWidth-30, height: 65))
            v1.backgroundColor = ConstValue.kCoverBgColor
            v1.borderRadius = 7
            let l = UILabel(frame: CGRect(x: 10, y: 0, width: screenWidth-50, height: 65))
            l.backgroundColor = .clear
            l.textColor = .lightGray
            l.numberOfLines = 3
            l.font = UIFont.systemFont(ofSize: 12)
            l.attributedText = TextSpaceManager.getAttributeStringWithString(" 推荐资料将在详情页顶部展示，如没有推荐信息，将设置第一个MM资料为推荐信息，当前资料设为推荐后，将取消其他资料的推荐", lineSpace: 3, .left)
            v.addSubview(v1)
            v1.addSubview(l)
            return v
        }
        return nil
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.row == 1 {
            return 70
        }
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 60.0
        return tableView.rowHeight
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return LFPushInfosController.infoTitles.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.row == 1 {
            let cell = tableView.dequeueReusableCell(withIdentifier: LFInfoInPut2Cell.cellId, for: indexPath) as! LFInfoInPut2Cell
            cell.titleLab.text = LFPushInfosController.infoTitles[indexPath.row]
            cell.placeHodlerLab.text = LFPushInfosController.placeHodlers[indexPath.row]
            cell.textView.tag = indexPath.row
            cell.accessoryType = .disclosureIndicator
            cell.accessoryView = UIImageView(image: getImage("arrowRightIndecator"))
            cell.textView.isEditable = false
            cell.textView.isUserInteractionEnabled = false
            if let p = inputModel?.province, !p.isEmpty {
                cell.textView.text = "\(p)·\(inputModel?.city ?? "")"
            } else {
                cell.textView.text = inputModel?.city
            }
            return cell
        } else if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: LFInfoInPut1Cell.cellId, for: indexPath) as! LFInfoInPut1Cell
            cell.setHolderText(LFPushInfosController.placeHodlers[indexPath.row])
            cell.titleLab.text = LFPushInfosController.infoTitles[indexPath.row]
            cell.placeHodlerLab.text = LFPushInfosController.placeHodlers[indexPath.row]
            cell.textView.tag = indexPath.row
            cell.textView.text = inputModel?.title
            if inputModel?.title != nil && !inputModel!.title!.isEmpty {
                cell.placeHodlerLab.text = nil
            }
            cell.inputEnd = { [weak self] text in
                if self?.inputModel == nil {
                    self?.inputModel = LFMsgModel()
                }
                self?.canSave = true
                self?.inputModel?.title = text
            }
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: SettingCell.cellId, for: indexPath) as! SettingCell
        
            cell.iconImage.image = nil
            cell.titleLab.font = UIFont.boldSystemFont(ofSize: 16)
            cell.titleLab.text = LFPushInfosController.infoTitles[indexPath.row]
            cell.setIconImage(true)
            cell.titleLedtM.constant = 0
            cell.accessoryType = .none
            cell.accessoryView = nil
            cell.swichBtn.isHidden = false
            cell.swichBtn.isOn = (inputModel?.is_top ?? 1) == 1
            if cell.swichBtn.isOn {
                cell.swichBtn.thumbTintColor = ConstValue.kStypeColor
            } else {
                cell.swichBtn.thumbTintColor = UIColor.white
            }
            cell.switchValueChangeHandler = { [weak self] in
                if self?.inputModel == nil {
                    self?.inputModel = LFMsgModel()
                }
                self?.canSave = true
                if cell.swichBtn.isOn {
                    cell.swichBtn.thumbTintColor = ConstValue.kStypeColor
                    self?.inputModel?.is_top = 1
                } else {
                    cell.swichBtn.thumbTintColor = UIColor.white
                    self?.inputModel?.is_top = 0
                }
            }
            return cell
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: true)
        if indexPath.row == 1 {
            let vc = CityChoseController()
            vc.choseCityCallBack = { [weak self] (p, c) in
                self?.currentProvince = p
                self?.currentCity = c
                if self?.inputModel != nil {
                    self?.inputModel?.province = p
                    self?.inputModel?.city = c
                } else {
                    self?.inputModel = LFMsgModel()
                    self?.inputModel?.province = p
                    self?.inputModel?.city = c
                }
                self?.tableView.reloadData()
                vc.dismiss(animated: false, completion: nil)
            }
            vc.modalPresentationStyle = .fullScreen
            self.present(vc, animated: false, completion: nil)
        }
    }
    
}
// MARK: - UploadImageDelegate
extension LFPushInfosController: UploadImageDelegate {
    
    func paramsForAPI(_ uploadImageTool: UploadImageTool) -> [String : String]? {
        XSProgressHUD.showProgress(msg: "图片上传中...", onView: view, animated: false)
        return nil
    }
    
    func uploadImageMethod(_ uploadImageTool: UploadImageTool) -> String {
        let dateNow = Date()
        let timeInterval: TimeInterval = dateNow.timeIntervalSince1970
        let timeStamp = Int(timeInterval)
        let platform = "I"
        let signString = String(format: "%@%d%@", platform, timeStamp, "pb5pe0MXChXsic0N")
        let sign = (signString.md5()?.uppercased() ?? "") as String
        DLog("signString == \(signString)")
        return "/upload?dir=publish_image&platform=\(platform)&timestamp=\(timeStamp)&sign=\(sign)"
    }
    
    func uploadImageSuccess(_ uploadImageTool: UploadImageTool, resultDic: [String : Any]?) {
        if let result = resultDic?["result"] as? [String: Any], let path = result["file_path"] as? String {
            commitImageNames.append(path)
            uploadImageIndex = uploadImageIndex + 1
            uploadImage(uploadImageIndex)
        } else {
            XSAlert.show(type: .error, text: "图片上傳失敗")
        }
    }
    
    func uploadImageFailed(_ uploadImageTool: UploadImageTool, errorMessage: String?) {
        XSProgressHUD.hide(for: view, animated: false)
        XSAlert.show(type: .error, text: "图片上傳失敗")
    }
    
    func uploadFailedByTokenError() {
        XSProgressHUD.hide(for: view, animated: false)
    }
    
}
// MARK: - UploadVideoDelegate
extension LFPushInfosController: UploadVideoDelegate {
    
    func uploadVideoMethod(_ uploadVideoTool: UploadVideoTool) -> String {
        let dateNow = Date()
        let timeInterval: TimeInterval = dateNow.timeIntervalSince1970
        let timeStamp = Int(timeInterval)
        let platform = "I"
        let signString = String(format: "%@%d%@", platform, timeStamp, "pb5pe0MXChXsic0N")
        let sign = (signString.md5()?.uppercased() ?? "") as String
        DLog("signString == \(signString)")
        return "/upload?dir=publish_video&platform=\(platform)&timestamp=\(timeStamp)&sign=\(sign)"
    }
    
    func uploadVideoSuccess(_ uploadVideoTool: UploadVideoTool, resultDic: [String : Any]?) {
        if let videoFileInfo = resultDic?["result"] as? [String: String], let path = videoFileInfo["file_path"] {
            XSProgressHUD.hide(for: view, animated: false)
            if inputModel == nil {
                inputModel = LFMsgModel()
            }
            inputModel?.video = path
            commitPush()
        }
    }
    
    func uploadVideoProgress(_ progress: Double) {
       DLog("videoUploadProgress: \(progress)")
    }
    
    func uploadVideoFailed(_ uploadVideoTool: UploadVideoTool, errorMessage: String?) {
        XSProgressHUD.hide(for: view, animated: false)
        XSAlert.show(type: .error, text: "视频上传失败！")
    }
    
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension LFPushInfosController: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is LFInfoPushApi {
            var params = [String: Any]()
            params[LFInfoPushApi.kTitle] = inputModel?.title
            params[LFInfoPushApi.kCity] = inputModel?.city
            params[LFInfoPushApi.kProvince] = inputModel?.province
            params[LFInfoPushApi.kCover] = inputModel?.images?[0]
            params[LFInfoPushApi.kVideo] = inputModel?.video
            params[LFInfoPushApi.kIs_top] = inputModel?.is_top ?? 1
            if let images = inputModel?.images, images.count > 0 {
                let mmString = NSMutableString()
                for i in 0 ..< images.count {
                    if i == images.count - 1 {
                        mmString.append(images[i])
                    } else {
                        mmString.append("\(images[i]),")
                    }
                }
                params[LFInfoPushApi.kImages] =  mmString as String
            }
            if isEdit && inputModel?.id != nil {
                 params[LFInfoPushApi.kFloor_id] = inputModel?.id
            }
            return params
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is LFInfoPushApi {
            if let lfInfo = manager.fetchJSONData(VideoReformer()) as? LFMsgModel {
                if (inputModel?.isLocal ?? false) { // 草稿上传
                    UserDefaults.standard.removeObject(forKey: UserDefaults.kLocalLFInfoParams)
                }
                FileManager.sharedInstance.remove(atPath: FileManager.videoExportPath)
                let vc = PushSuccessController()
                vc.infoModel = lfInfo
                navigationController?.pushViewController(vc, animated: true)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        XSAlert.show(type: .text, text: "发布失败！")
    }
}

// MARK: - Description
private extension LFPushInfosController {
    func layoutPageSubviews() {
        layoutToppart()
        layoutPushBtn()
        layoutTableView()
        layoutVideoAddView()
        layoutPhotoView()
    }
    func layoutTableView() {
        tableView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom)
            make.bottom.equalToSuperview()
        }
    }
    func layoutPhotoView() {
        photoView.snp.makeConstraints { (make) in
            make.leading.equalTo(12)
            make.trailing.equalTo(-12)
            make.top.equalTo(videoChoseView.snp.bottom).offset(15)
            make.bottom.equalTo(-15)
        }
    }
    func layoutVideoAddView() {
        videoChoseView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(130 + (screenWidth-35)/3)
        }
    }
    func layoutToppart() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
    }
    func layoutPushBtn() {
        pushBtn.snp.makeConstraints { (make) in
            make.trailing.equalTo(-12)
            make.centerY.equalToSuperview()
            make.height.equalTo(30)
            make.width.equalTo(58)
        }
    }
}
extension LFPushInfosController: CLNavigationBarDelegate {
    func backAction() {
        if canSave {
            showAlertSave()
        } else {
            navigationController?.popViewController(animated: true)
        }
    }
}


extension LFPushInfosController {
    func showAlertSave() {
        if inputModel == nil {
            navigationController?.popViewController(animated: true)
            return
        }
        let alert = UIAlertController(title: "取消发布", message: "\n不会保存当前编辑的内容", preferredStyle: .alert)
        let actionSave = UIAlertAction.init(title: "取消", style: .default) { (action) in
            FileManager.sharedInstance.remove(atPath: FileManager.videoExportPath)
            self.navigationController?.popViewController(animated: true)
        }
        let actionCancle = UIAlertAction.init(title: "继续发布", style: .default) { (action) in
           
        }
        alert.addAction(actionCancle)
        alert.addAction(actionSave)
        present(alert, animated: true, completion: nil)
    }
    func saveLocalModelDatas() {
        if self.inputModel == nil { return }
        var params = [String: Any]()
        params[LFInfoPushApi.kTitle] = inputModel?.title
        params[LFInfoPushApi.kCity] = inputModel?.city
        params[LFInfoPushApi.kProvince] = inputModel?.province
        if let imgs = inputModel!.images, imgs.count > 0 {
            params[LFInfoPushApi.kCover] = imgs[0]
        }
        params[LFInfoPushApi.kVideo] = inputModel?.video
        params[LFInfoPushApi.kImages] = inputModel?.images
        params[LFInfoPushApi.kCreate_at] = Date.getLocalDateStrWithDate(date: Date())
        UserDefaults.standard.set(params, forKey: UserDefaults.kLocalLFInfoParams)
        if photoView.pictures.count > 0 {
            var localImageDatas = [Data]()
            for img in photoView.pictures {
                if let data = img.pngData() {
                    localImageDatas.append(data)
                }
            }
            UserDefaults.standard.set(localImageDatas, forKey: UserDefaults.kLocalLFImageDatas)
        } else {
            UserDefaults.standard.set(nil, forKey: UserDefaults.kLocalLFImageDatas)
        }
        navigationController?.popViewController(animated: true)
    }
    // 截取视频第一帧 图片
    func getVideoFirstImage() -> UIImage? {
        let urlAsset = AVURLAsset(url: FileManager.videoExportURL)
        let seconds = urlAsset.duration.seconds
        DLog("second: \(seconds)")
        //生成视频截图
        let generator = AVAssetImageGenerator(asset: urlAsset)
        generator.appliesPreferredTrackTransform = true
        generator.maximumSize = CGSize(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        let time = CMTimeMakeWithSeconds(0.0,preferredTimescale: 900)
        var actualTime:CMTime = CMTimeMake(value: 0,timescale: 1)
        if let imageRef:CGImage = try? generator.copyCGImage(at: time, actualTime: &actualTime) {
            let frameImg = UIImage(cgImage: imageRef)
            //显示截图
            return frameImg
        }
        return nil
    }
}
