
import UIKit

class PushSuccessController: CLBaseViewController {
    let successImg: UIImageView = {
        let img = UIImageView(image: LGConfig.getImage("followSuccess"))
        img.contentMode = .scaleAspectFit
        img.layer.cornerRadius = 40
        img.layer.masksToBounds = true
        img.backgroundColor = UIColor.lightGray
        return img
    }()
    let infoText: UILabel = {
        let lab = UILabel()
        lab.textAlignment = .center
        lab.text = "发布成功"
        lab.font = UIFont.boldSystemFont(ofSize: 24)
        lab.textColor = .white
        return lab
    }()
    let desText: UILabel = {
        let lab = UILabel()
        lab.textAlignment = .center
        lab.numberOfLines = 0
        lab.text = "已发布，预计5分钟后在约啪展示…"
        lab.font = UIFont.systemFont(ofSize: 15)
        lab.textColor = .lightGray
        return lab
    }()
    let tiplab: UILabel = {
        let lab = UILabel()
        lab.textAlignment = .left
        lab.numberOfLines = 0
        lab.text = "温馨提示：获得官方认证的发布者，发布信息无需审核直接展示，快去认证吧"
        lab.font = UIFont.systemFont(ofSize: 15)
        lab.textColor = .lightGray
        return lab
    }()
    lazy var sendAgainBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitleColor(ConstValue.kStypeColor, for: .normal)
        btn.setTitle("继续发布", for: .normal)
        btn.layer.cornerRadius = 24
        btn.layer.masksToBounds = true
        btn.layer.borderColor = ConstValue.kStypeColor.cgColor
        btn.layer.borderWidth = 1
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        btn.tag = 1
        btn.addTarget(self, action: #selector(btnClick(_:)), for: .touchUpInside)
        return btn
    }()
    lazy var myBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitleColor(.white, for: .normal)
        btn.backgroundColor = ConstValue.kStypeColor
        btn.layer.cornerRadius = 24
        btn.layer.masksToBounds = true
        btn.setTitle("我的约啪", for: .normal)
        btn.titleLabel?.font = UIFont.systemFont(ofSize: 15)
        btn.tag = 2
        btn.addTarget(self, action: #selector(btnClick(_:)), for: .touchUpInside)
        return btn
    }()
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.navBackBlack = false
        bar.delegate = self
        return bar
    }()
    var infoModel: LFMsgModel?
    override func viewDidLoad() {
        super.viewDidLoad()
        view.addSubview(navBar)
        view.addSubview(successImg)
        view.addSubview(infoText)
        view.addSubview(desText)
        view.addSubview(sendAgainBtn)
        view.addSubview(myBtn)
        view.addSubview(tiplab)
        layoutToppart()
        layoutSubs()
        if infoModel?.is_attest == 1 {
            tiplab.isHidden = true
        }
    }
    @objc func btnClick(_ sender: UIButton) {
        if sender.tag == 1 {
            navigationController?.popViewController(animated: true)
        } else if sender.tag == 2 {
            goback()
        }
    }
    func layoutSubs() {
        successImg.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom).offset(100)
            make.width.height.equalTo(80)
        }
        infoText.snp.makeConstraints { (make) in
            make.leading.equalTo(40)
            make.trailing.equalTo(-40)
            make.top.equalTo(successImg.snp.bottom).offset(20)
        }
        desText.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(infoText)
            make.top.equalTo(infoText.snp.bottom).offset(20)
        }
        myBtn.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(infoText)
            make.bottom.equalTo(-40)
            make.height.equalTo(48)
        }
        sendAgainBtn.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(infoText)
            make.bottom.equalTo(myBtn.snp.top).offset(-15)
            make.height.equalTo(48)
        }
        tiplab.snp.makeConstraints { (make) in
            make.leading.trailing.equalTo(sendAgainBtn)
            make.bottom.equalTo(sendAgainBtn.snp.top).offset(-15)
        }
    }
    func layoutToppart() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
    }
}

extension PushSuccessController: CLNavigationBarDelegate {
    func backAction() {
        goback()
    }
    func goback() {
        if let vcs = navigationController?.viewControllers {
            let allVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: ShopInfoController.self)
            }
            if allVcs.count > 0 {
                let userVc = allVcs[0] as! ShopInfoController
                navigationController?.popToViewController(userVc, animated: true)
            } else {
                navigationController?.popToRootViewController(animated: true)
            }
        }
    }
}



