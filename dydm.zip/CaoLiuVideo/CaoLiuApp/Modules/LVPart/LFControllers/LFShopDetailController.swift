
import UIKit
import NicooNetwork
import MJRefresh
import AVKit

class LFShopDetailController: CLBaseViewController {

    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.backgroundColor = .clear
        bar.navBackBlack = false
        bar.lineView.isHidden = true
        bar.layer.masksToBounds = true
        bar.delegate = self
        return bar
    }()
   
    lazy var tableView: UITableView = {
        let table = UITableView.init(frame: CGRect.zero, style: .plain)
        table.showsVerticalScrollIndicator = false
        table.backgroundColor = UIColor.clear
        table.separatorStyle = .none
        table.allowsSelection = false
        table.bounces = false
        table.delegate = self
        table.dataSource = self
        
        table.register(ShopDetailItemsCell.classForCoder(), forCellReuseIdentifier: ShopDetailItemsCell.cellId)
        table.register(ShopDetailBannerCell.classForCoder(), forCellReuseIdentifier: ShopDetailBannerCell.cellId)
        table.register(LfInfoTextCell.classForCoder(), forCellReuseIdentifier: LfInfoTextCell.cellId)
        table.register(LfNOContactCell.classForCoder(), forCellReuseIdentifier: LfNOContactCell.cellId)
        table.register(LfCommentCell.classForCoder(), forCellReuseIdentifier: LfCommentCell.cellId)
        table.register(LFPusherCell.classForCoder(), forCellReuseIdentifier: LFPusherCell.cellId)
        table.register(CommunityTextCell.classForCoder(), forCellReuseIdentifier: CommunityTextCell.cellId)
        table.register(CommunitySinglePictureCell.classForCoder(), forCellReuseIdentifier: CommunitySinglePictureCell.cellId)
        table.register(CommunityImagesCell.classForCoder(), forCellReuseIdentifier: CommunityImagesCell.cellId)
        table.mj_footer = loadMoreView
        return table
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadMore = MJRefreshAutoNormalFooter(refreshingBlock: {
            //weakSelf?.loadNextPage()
        })
        loadMore?.isHidden = true
        loadMore?.stateLabel.font = ConstValue.kRefreshLableFont
        return loadMore!
    }()
    lazy var tableHeader: LFDetailHeaderView = {
        let v = LFDetailHeaderView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenWidth * 4/3 + 95))
        v.backgroundColor = ConstValue.kVcViewColor
        return v
    }()
    let footView: UIView = {
        let v = UIView.init(frame: CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight - safeAreaTopHeight))
        v.backgroundColor = ConstValue.kVcViewColor
        return v
    }()
    private lazy var shopInfoApi: LFShopDetailApi =  {
        let api = LFShopDetailApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    var serverInfos = [String]()
    
    var shopDetail = LFShopDetail()
    
    var shopModel: LFShopModel?
    
    var lfModel = LFMsgModel()
    
    let userViewModel = UserInfoViewModel()
    
    /// 讨论区
    var lfComments = [LFCommentModel]()
    
    var listViewController = LFMsgListController()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        if #available(iOS 11.0, *) {
            tableView.contentInsetAdjustmentBehavior = .never
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
        view.addSubview(tableView)
        view.addSubview(navBar)
        layoutPageSub()
        loadShopDetail()
        tableView.tableHeaderView = tableHeader
        tableView.tableFooterView = footView
    }
    private func loadShopDetail() {
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: false)
        _ = shopInfoApi.loadData()
    }
   
    func showCoinsAlert() {
        showDialog(title: "温馨提示", message: "\n你的钻石不足，请前去充值", okTitle: "立即充值", cancelTitle: "取消", okHandler: {
            let vc = CoinsCardsController()
            vc.isCoins = true
            self.navigationController?.pushViewController(vc, animated: true)
        }, cancelHandler: nil)
    }
    func setLfModelInfo() {
        tableHeader.setLfInfo(shopDetail)
        tableHeader.pictureTapHandler = { [weak self] index in
            self?.showPictureBower(index,self?.shopDetail.top_mm_info?.images)
        }
        tableHeader.videoTapHandler = { [weak self] _ in
            self?.playVideo()
        }
        tableHeader.actionHandler = { [weak self] actionId in
            if actionId == 1 { // 私信
                if UserModel.share().user?.is_vip == "y" {
                    self?.goChatWith()
                } else {
                    self?.showDialog(title: nil, message: "\n购买高级会员后才可发私信\n\n", okTitle: "开通VIP", cancelTitle: "取消", okHandler: {
                        let vc = VipCardsController()
                        self?.navigationController?.pushViewController(vc, animated: true)
                    }, cancelHandler: nil)
                }
            } else if actionId == 2 { // 用户点击
                //self?.goUserCenter(self?.shopDetail.user_info)
            }
        }
    }

    /// 点赞
    func addFavorOrNot(_ isFavor: Bool) {
        let likeCount = shopDetail.shop_info?.like_count ?? 0
        var favorCount = 0
        if isFavor {  // 不是点赞
            favorCount = likeCount + 1
        } else {
            favorCount = likeCount > 0 ? likeCount - 1 : 0
        }
        shopDetail.shop_info?.like_count = favorCount
        shopDetail.is_like = isFavor ? 1 : 0
        tableView.reloadRows(at: [IndexPath.init(row: 0, section: 0)], with: .none)
        userViewModel.addMsgFavor([UserFavorAddApi.kMsg_Id: shopModel?.id ?? 0])
    }
    func playVideo() {
        if let Url = URL(string: shopDetail.top_mm_info?.video ?? "") {
            let playerVc = AVPlayerViewController()
            playerVc.player = AVPlayer(url: Url)
            playerVc.player?.play()
            playerVc.modalPresentationStyle = .fullScreen
            self.present(playerVc, animated: false, completion: nil)
        } else {
            XSAlert.show(type: .text, text: "视频地址不正确")
        }
        
    }
    func showCoinBuyAlert(_ msg: String) {
        showDialog(title: "温馨提示", message: "\n\(msg)", okTitle: "立即充值", cancelTitle: "取消", okHandler: {
            let vc = CoinsCardsController()
            vc.isCoins = true
            self.navigationController?.pushViewController(vc, animated: true)
        }, cancelHandler: nil)
    }
    func showPictureBower(_ index: Int,_ images: [String]?) {
        guard let pictures = images else { return }
        if pictures.count <= index { return }
        let loader = JXKingfisherLoader()
        // 数据源
        let source = JXNetworkingDataSource(photoLoader: loader, numberOfItems: { () -> Int in
            return pictures.count
        }, placeholder: { index -> UIImage? in
            return LGConfig.getImage("playCellBg")
        }) { index -> String? in
            return pictures[index]
        }
        let delegate = JXNumberPageControlDelegate()
        let trans = JXPhotoBrowserZoomTransitioning { (browser, index, view) -> UIView? in
            return nil
        }
        JXPhotoBrowser(dataSource: source, delegate: delegate, transDelegate: trans)
            .show(pageIndex: index)
    }
    func goUserCenter(_ user: CLUserInfo?) {
        if let vcs = navigationController?.viewControllers {
            let allVcs = vcs.filter { (vc) -> Bool in
                return vc.isKind(of: UserMCenterController.self)
            }
            if allVcs.count > 0 {
                navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                    return vc.isKind(of: UserMCenterController.self)
                })
            }
            let userCenter = UserMCenterController()
            userCenter.userCode = user?.code
            navigationController?.pushViewController(userCenter, animated: true)
        }
    }
    func goChatWith() {
        if shopDetail.user_info?.code == nil {
            XSAlert.show(type: .error, text: "用户code为空")
            return
        }
        if shopDetail.user_info?.code == UserModel.share().user?.code {
            XSAlert.show(type: .error, text: "不能私信自己。")
            return
        }
        let chat = ChatUser2UserController()
        chat.toUser = shopDetail.user_info
        navigationController?.pushViewController(chat, animated: true)
    }
}

// MARK: - UITableViewDelegate, UITableViewDataSource
extension LFShopDetailController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath.section == 0 {
            return ShareOrFavorItemCell.itemSize.height + 10
        } else if indexPath.section == 2 && indexPath.row == 1 {
            return (shopDetail.ad?.count ?? 0) == 0 ? 0 : BannerScrollInsert.itemSize.height + 10
        }
        tableView.rowHeight = UITableView.automaticDimension
        tableView.estimatedRowHeight = 60.0
        return tableView.rowHeight
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 4
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        } else if section == 1 {
            return 2
        } else if section == 2 {
            return 2
        } else if section == 3 {
            return lfComments.count == 0 ? 1 : lfComments.count
        }
        return 0
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        if section == 0 {
            return 0
        }
        return 40
    }
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        if section == 3 {
            return 40
        }
        return 0
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        if section == 3 {
            let v = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 40))
            v.backgroundColor = .clear
            let line = UIView(frame: CGRect(x: 0, y: 0, width: screenWidth, height: 0.5))
            line.backgroundColor = ConstValue.kAppSepLineColor
            let lab = UILabel(frame: CGRect(x: 15, y: 5, width: screenWidth - 30, height: 30))
            lab.textColor = .white
            lab.font = UIFont.boldSystemFont(ofSize: 13)
            lab.text = "MM\(shopDetail.shop_info?.mm_count ?? 0)人·可提供以下地区的服务"
            v.addSubview(line)
            v.addSubview(lab)
            return v
        }
        return nil
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        if section == 0 {
            return nil
        } else {
            guard let header = Bundle.main.loadNibNamed("ModulesHeaderView", owner: nil, options: nil)?[0] as? ModulesHeaderView else {
                return nil
            }
            header.backgroundColor = ConstValue.kVcViewColor
            header.titleLab.font = UIFont.boldSystemFont(ofSize: 14)
            header.titleLab.text = ["联系方式","服务介绍","评论区 (\(shopDetail.comment_count ?? 0))"][section - 1]
            if section == 3 || section == 1 {
                header.moreBtn.isHidden = false
                header.arrowRightimg.isHidden = section == 1
                header.moreLabel.isHidden = false
                header.moreLabel.text = section == 1 ? "《抖阴约啪服务指南》" : "参与讨论"
                header.moreLabel.textColor = section == 1 ? ConstValue.kStypeColor : .lightGray
                header.moreActionHandler = { [weak self] in
                    if section == 1 {
                        let license = LicenseController()
                        let urlstr = UserModel.share().authInfo?.config?.rule?.cheat_h5 ?? ""
                        license.urlString = urlstr
                        license.navTitle = "约啪防骗指南"
                        self?.navigationController?.pushViewController(license, animated: true)
                    } else {
                        let vc = LFCommentsController()
                        vc.lfModelId = self?.shopDetail.top_mm_info?.id
                        self?.navigationController?.pushViewController(vc, animated: true)
                    }
                }
            } else {
                header.moreBtn.isHidden = true
                header.arrowRightimg.isHidden = true
                header.moreLabel.isHidden = true
                header.moreLabel.text = nil
                header.moreLabel.textColor = .lightGray
            }
            header.frame = CGRect(x: 0, y: 0, width: screenWidth, height: 50)
            return header
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            let cell = tableView.dequeueReusableCell(withIdentifier: ShopDetailItemsCell.cellId, for: indexPath) as! ShopDetailItemsCell
            cell.setModel(shopDetail)
            cell.itemClickHandler = { [weak self] index in
                if index == 0 {
                    self?.addFavorOrNot(self?.shopDetail.is_like == 0)
                } else if index == 1 {
                    let shareVc = ShareContentController()
                    self?.navigationController?.pushViewController(shareVc, animated: true)
                }
            }
            return cell
        } else if indexPath.section == 1 {
            if indexPath.row == 0 {
                if shopDetail.is_look_contact == 1 {
                    let cell = tableView.dequeueReusableCell(withIdentifier: LfInfoTextCell.cellId, for: indexPath) as! LfInfoTextCell
                    cell.textLab.textColor = rgb(255, 239, 195)
                    cell.textLab.attributedText = TextSpaceManager.getAttributeStringWithString("\(shopDetail.shop_info?.contact ?? "")", lineSpace: 5, .left)
                    return cell
                } else {
                    let cell = tableView.dequeueReusableCell(withIdentifier: LfNOContactCell.cellId, for: indexPath) as! LfNOContactCell
                    cell.textClickAction = { [weak self] in
                        let vip = VipCardsController()
                        self?.navigationController?.pushViewController(vip, animated: true)
                    }
                    return cell
                }
            } else if indexPath.row == 1 {
                let cell = tableView.dequeueReusableCell(withIdentifier: LfInfoTextCell.cellId, for: indexPath) as! LfInfoTextCell
                cell.textLab.textColor = .lightGray
                cell.textLab.attributedText = TextSpaceManager.getAttributeStringWithString("\(UserModel.share().authInfo?.config?.rule?.shop_tips ?? "")", lineSpace: 5, .left)
                return cell
            }
        } else if indexPath.section == 2 {
            if indexPath.row == 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: LfInfoTextCell.cellId, for: indexPath) as! LfInfoTextCell
                cell.textLab.textColor = .white
                cell.textLab.attributedText = TextSpaceManager.getAttributeStringWithString("\(shopDetail.shop_info?.serving_intro ?? "")",lineSpace: 5, .left)
                return cell
            } else if indexPath.row == 1 {
                let cell = tableView.dequeueReusableCell(withIdentifier: ShopDetailBannerCell.cellId, for: indexPath) as! ShopDetailBannerCell
                cell.setAds(shopDetail.ad)
                cell.adItemClick = { [weak self] ad in
                    self?.goInnerLink(ad.link ?? "",ad.position)
                }
                return cell
            }
           
        } else if indexPath.section == 3 {
            if lfComments.count == 0 {
                let cell = tableView.dequeueReusableCell(withIdentifier: LfInfoTextCell.cellId, for: indexPath) as! LfInfoTextCell
                cell.textLab.text = "暂无评论"
                cell.textLab.textAlignment = .center
                return cell
            } else {
                let cell = tableView.dequeueReusableCell(withIdentifier: LfCommentCell.cellId, for: indexPath) as! LfCommentCell
                let model = lfComments[indexPath.row]
                cell.setModel(model, true)
                return cell
            }
        }
        return UITableViewCell()
    }
}
extension LFShopDetailController: UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        let thresholdDistance: CGFloat = screenWidth * 4/3 - safeAreaTopHeight
        var percent = offsetY/thresholdDistance
        percent = max(0, min(1, percent))
        navBar.backgroundColor = UIColor(red: 27/255.0, green: 27/255.0, blue: 40/255.0, alpha: percent)
        if offsetY > (screenWidth * 4/3 - safeAreaTopHeight) {
            navBar.titleLabel.text = "商家详情"
            navBar.backgroundColor = ConstValue.kCoverBgColor
            navBar.navBackBlack = false
            navBar.backButton.backgroundColor = .clear
        } else {
            navBar.titleLabel.text = ""
            navBar.backgroundColor = .clear
            navBar.navBackBlack = false
            navBar.backButton.backgroundColor = UIColor(white: 0, alpha: 0.2)
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension LFShopDetailController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is LFShopDetailApi {
            return [LFShopDetailApi.kShop_code: shopModel?.code ?? "", VipCardsApi.kIsvip: UserModel.share().user?.is_vip == "y" ? 1 : 0,LFMsgListApi.kChannel: UserModel.share().user?.channel ?? ""]
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is LFShopDetailApi {
            if let lfInfo = manager.fetchJSONData(VideoReformer()) as? LFShopDetail {
                shopDetail = lfInfo
                if let comments = shopDetail.comments_data, comments.count > 0 {
                    lfComments = comments
                }
                if let citys = shopDetail.mm_citydata {
                    listViewController.cityModels = citys
                }
                listViewController.shopModel = shopModel
                listViewController.isShopInfo = true
                addChild(listViewController)
                footView.addSubview(listViewController.view)
                listViewController.view.snp.makeConstraints { (make) in
                    make.edges.equalToSuperview()
                }
                setLfModelInfo()
                tableView.reloadData()
            } else {
                XSAlert.show(type: .text, text: "数据出错了")
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
    }
}

extension LFShopDetailController {
    func layoutPageSub() {
        layoutToppart()
        layoutTable()
    }
    func layoutToppart() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
    }
    func layoutTable() {
        tableView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.bottom.equalTo(0)
        }
    }
   
    
}
// MARK: - CLNavigationBarDelegate
extension LFShopDetailController: CLNavigationBarDelegate  {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}
