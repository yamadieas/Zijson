
import UIKit

/// 一张图片
class CommunitySinglePictureCell: UITableViewCell {

    static let cellId = "CommunitySinglePictureCell"
    
    lazy var userView: CommunityListUser = {
        let view = CommunityListUser(frame: CGRect.zero)
        return view
    }()
    lazy var bottomView: CommunityBottomView = {
        if let view = Bundle.main.loadNibNamed("CommunityBottomView", owner: nil, options: nil)?[0] as? CommunityBottomView {
            return view
        }
        return CommunityBottomView()
    }()
    let contentLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.white
        label.font = UIFont.systemFont(ofSize: 14)
        label.numberOfLines = 0
        return label
    }()
    let imageSingle: UIImageView = {
        let image = UIImageView()
        image.isUserInteractionEnabled = true
        image.contentMode = .scaleAspectFill
        image.layer.cornerRadius = 2.0
        image.layer.masksToBounds = true
        image.clipsToBounds = true
        image.backgroundColor = UIColor.clear
        return image
    }()
    lazy var tapGesture: UITapGestureRecognizer = {
        let tap = UITapGestureRecognizer(target: self, action: #selector(tapImage))
        return tap
    }()
    
    var resizeCell:(()->Void)?
    var imageClickHandler:(()->Void)?
    var bottomActionHandler:((_ actionId: Int)->Void)?
    var userViewActionHandler:((_ actionId: Int)->Void)?
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        backgroundColor = UIColor.clear
        contentView.backgroundColor = UIColor.clear
        contentView.addSubview(userView)
        contentView.addSubview(contentLabel)
        contentView.addSubview(imageSingle)
        contentView.addSubview(bottomView)
        layoutPageSubviews()
        imageSingle.addGestureRecognizer(tapGesture)
        selectionStyle = .none
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    func setImageWith(_ urlString: String) {
        imageSingle.kfSetHorizontalImageWithUrl(urlString)
    }
    @objc private func tapImage() {
        imageClickHandler?()
    }
    
    func setModel(_ model: LFCommentModel, _ hideBottom: Bool? = false) {
        userView.headerImage.kfsetHeader(model.user_info?.avatar)
        userView.nameLabel.text = model.user_info?.nick
        userView.timeLabel.text = model.time_string
        let rankType = model.user_info?.rank_type ?? 0
        userView.vipImg.isHidden = rankType == 0
        userView.vipImg.image = getImage("vipRank\(rankType)")
        userView.updateWidthVipTips(rankType)
        contentLabel.attributedText = TextSpaceManager.getAttributeStringWithString(model.comment_msg ?? "", lineSpace: 5)
        if let resource = model.comment_image,resource.count > 0 {
            setImageWith(resource[0])
        }
        bottomView.lfimage.kfSetVerticalImageWithUrl(model.floor_info?.cover)
        bottomView.lfTitle.text = model.floor_info?.title
        if let p = model.floor_info?.province, !p.isEmpty {
            bottomView.location.text = "\(p)·\(model.floor_info?.city ?? "")"
        } else {
            bottomView.location.text = model.floor_info?.city
        }
        if let prices = model.floor_info?.serving_money {
            let priceStr = NSMutableString.init()
            for i in 0 ..< prices.count {
                if i == prices.count - 1 {
                    priceStr.append(prices[i])
                } else {
                    priceStr.append("\(prices[i]),")
                }
            }
            bottomView.lfPrice.text = "\(priceStr)"
        }
        userView.userItemClickHandler = { [weak self] id in
            self?.userViewActionHandler?(id)
        }
        bottomView.itemActionHandler = { [weak self] id in
            self?.bottomActionHandler?(id)
        }
        if (hideBottom ?? false) {
            bottomView.snp.updateConstraints { (make) in
                make.height.equalTo(0)
            }
        } else {
            bottomView.snp.updateConstraints { (make) in
                make.height.equalTo(CommunityBottomView.height)
            }
        }
    }
    
}

// MARK: - layout
private extension CommunitySinglePictureCell {
    func layoutPageSubviews() {
        layoutUserView()
        layoutBottomView()
        layoutImageSingle()
        layoutContentLabel()
    }
    func layoutUserView() {
        userView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(10)
            make.height.equalTo(CommunityListUser.height)
        }
    }
    func layoutBottomView() {
        bottomView.snp.makeConstraints { (make) in
            make.bottom.equalTo(-10)
            make.leading.equalTo(10)
            make.trailing.equalTo(-10)
            make.height.equalTo(CommunityBottomView.height)
        }
    }
    func layoutContentLabel() {
        contentLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.trailing.equalTo(-10)
            make.top.equalTo(userView.snp.bottom).offset(5)
            make.bottom.equalTo(imageSingle.snp.top).offset(-10)
        }
    }
    func layoutImageSingle() {
        let width: CGFloat = (screenWidth - 30)/2
        let height: CGFloat = width*1.39
        imageSingle.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.height.equalTo(height)
            make.width.equalTo(width)
            make.bottom.equalTo(bottomView.snp.top).offset(-10)
        }
    }
}
