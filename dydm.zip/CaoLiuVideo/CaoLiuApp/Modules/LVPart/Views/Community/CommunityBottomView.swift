

import UIKit

class CommunityBottomView: UIView {

    static let height: CGFloat = 75.0

    @IBOutlet weak var lfimage: UIImageView!
    @IBOutlet weak var lfTitle: UILabel!
    @IBOutlet weak var lfPrice: UILabel!
    @IBOutlet weak var location: UILabel!
    
    @IBOutlet weak var clickButton: UIButton!
    
    /// actionId : 1.话题点击 2.评论点击 3.分享点击 4.点赞
    var itemActionHandler:((_ actiionId: Int) ->Void)?
   
    override func awakeFromNib() {
        superview?.awakeFromNib()
        backgroundColor = ConstValue.kAppSepLineColor
    }
    @IBAction func btnClick(_ sender: UIButton) {
        itemActionHandler?(sender.tag)
    }
    
}
