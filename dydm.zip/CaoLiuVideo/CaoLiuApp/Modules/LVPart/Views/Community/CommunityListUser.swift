
import UIKit

class CommunityListUser: UICollectionReusableView {
    
    static let reuseId = "CommunityListUser"
    static let height: CGFloat = 70.0
    
    let headerImage: UIImageView = {
        let header = UIImageView()
        header.layer.cornerRadius = 24.0
        header.contentMode = .scaleAspectFill
        header.layer.masksToBounds = true
        header.image = LGConfig.getImage("defaultHeader")
        header.isUserInteractionEnabled = true
        return header
    }()
    let nameLabel: UILabel = {
        let label = UILabel()
        label.textColor = UIColor.white
        label.font = UIFont.boldSystemFont(ofSize: 13)
        return label
    }()
    let vipImg: UIImageView = {
        let v = UIImageView()
        v.isUserInteractionEnabled = true
        v.contentMode = .scaleAspectFit
        v.isHidden = true
        return v
    }()
   
    let timeLabel: UILabel = {
        let label = UILabel()
        label.textColor = .lightGray
        label.font = UIFont.systemFont(ofSize: 11)
        return label
    }()
    lazy var fakeUserClickButton: UIButton = {
        let button = UIButton(type: .custom)
        button.addTarget(self, action: #selector(userClick), for: .touchUpInside)
        return button
    }()
    /// actionId: 1. 用户点击 2.删除动态 3.对用户添加关注
    var userItemClickHandler:((_ actionId: Int)->Void)?

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = UIColor.clear
        addSubview(headerImage)
        addSubview(nameLabel)
        addSubview(vipImg)
        addSubview(timeLabel)
        addSubview(fakeUserClickButton)
        layoutPageSubviews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func updateWidthVipTips(_ vipType: Int) {
        if vipType != 6 {
            vipImg.snp.updateConstraints { (make) in
                make.width.equalTo(52)
            }
        } else {
            vipImg.snp.updateConstraints { (make) in
                make.width.equalTo(75)
            }
        }
    }
    
    @objc func addFollowButtonClick(_ sender: UIButton) {
        userItemClickHandler?(3)
    }
    @objc func deleteButtonClick(_ sender: UIButton) {
        userItemClickHandler?(2)
    }
    @objc func userClick() {
        userItemClickHandler?(1)
    }
    @objc func checkButtonClick() {
        userItemClickHandler?(4)
    }
    
}

// MARK: - Layout
private extension CommunityListUser {
    func layoutPageSubviews() {
        layoutHeaderImage()
        layoutNamelabel()
        layoutVipImage()
        layoutTimeLabel()
        layoutFakeUserClickButton()
        
    }
    func layoutHeaderImage() {
        headerImage.snp.makeConstraints { (make) in
            make.leading.equalTo(10)
            make.centerY.equalToSuperview()
            make.height.width.equalTo(48)
        }
    }
    func layoutNamelabel() {
        nameLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(headerImage.snp.trailing).offset(12)
            make.top.equalTo(headerImage.snp.top).offset(5)
            make.height.equalTo(20)
        }
    }
    func layoutVipImage() {
        vipImg.snp.makeConstraints { (make) in
            make.leading.equalTo(nameLabel.snp.trailing).offset(7)
            make.centerY.equalTo(nameLabel)
            make.height.equalTo(20)
            make.width.equalTo(52)
        }
    }
    func layoutTimeLabel() {
        timeLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(nameLabel)
            make.top.equalTo(nameLabel.snp.bottom).offset(5)
            make.height.equalTo(18)
        }
    }
    func layoutFakeUserClickButton() {
        fakeUserClickButton.snp.makeConstraints { (make) in
            make.leading.top.bottom.equalTo(headerImage)
            make.trailing.equalTo(vipImg.snp.trailing)
        }
    }
}
