
import UIKit

class VideoCountDataView: UIView {
    
    let zanImgView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = getImage("hotTipIcon")
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    let zanCountLab: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.systemFont(ofSize: 11)
        titleLab.textColor = .white
        return titleLab
    }()
    let playImgView: UIImageView = {
        let imageView = UIImageView()
        imageView.image = getImage("PlayCountItem")
        imageView.contentMode = .scaleAspectFit
        return imageView
    }()
    let playCountLab: UILabel = {
        let titleLab = UILabel()
        titleLab.font = UIFont.systemFont(ofSize: 11)
        titleLab.textColor = .white
        return titleLab
    }()
    let durationLab: UILabel = {
        let la = UILabel()
        la.textColor = .white
        la.font = UIFont.systemFont(ofSize: 11)
        return la
    }()
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(zanImgView)
        addSubview(zanCountLab)
        addSubview(playImgView)
        addSubview(playCountLab)
        addSubview(durationLab)
        layoutpages()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func layoutpages() {
        zanImgView.snp.makeConstraints { (make) in
            make.leading.equalTo(8)
            make.bottom.equalTo(-8)
            make.height.equalTo(12)
            make.width.equalTo(8)
        }
        zanCountLab.snp.makeConstraints { (make) in
            make.leading.equalTo(zanImgView.snp.trailing).offset(3)
            make.centerY.equalTo(zanImgView)
        }
        playImgView.snp.makeConstraints { (make) in
            make.leading.equalTo(zanCountLab.snp.trailing).offset(15)
            make.centerY.equalTo(zanCountLab)
            make.height.width.equalTo(10)
        }
        playCountLab.snp.makeConstraints { (make) in
            make.leading.equalTo(playImgView.snp.trailing).offset(3)
            make.centerY.equalTo(playImgView)
        }
        durationLab.snp.makeConstraints { (make) in
            make.trailing.equalTo(-6)
            make.centerY.equalTo(zanCountLab)
        }
    }
}
