
import UIKit

class DetailInfoView: UICollectionReusableView {
    
    static let reuseId = "DetailInfoView"
    
    let infoLab: ActiveLabel = {
        let lable = ActiveLabel()
        lable.textColor = .white
        lable.backgroundColor = .clear
        lable.numberOfLines = 0
        lable.font = UIFont.boldSystemFont(ofSize: 14)
        return lable
    }()
    let countsLab: UILabel = {
        let lable = UILabel()
        lable.textColor = .lightGray
        lable.font = UIFont.systemFont(ofSize: 13)
        return lable
    }()
    var tagClickAction:((SearchHotTips) ->())?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(infoLab)
        addSubview(countsLab)
        layoutSubs()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setModel(_ video: VideoNew?,_ tagColor: UIColor? = ConstValue.kStypeColor) {
        countsLab.text = "热度\(getStringWithNumber(video?.hot ?? 0)) · 时长\(PlayerView.formatTimDuration(duration: video?.duration ?? 0)) · \(getStringWithNumber(video?.play ?? 0))次播放 · \(video?.is_free == 1 ? "免费" : (video?.coins ?? 0) > 0 ? "付费" : "VIP")"
        infoLab.attributedText = TextSpaceManager.getAttributeStringWithString("\(video?.title ?? "")", lineSpace: 4, .left)
        if let cateTitles = video?.category, cateTitles.count > 0 {
            let tagString = NSMutableString()
            for model in cateTitles {
                tagString.append(" #\(model.title ?? "")")
            }
            infoLab.attributedText = TextSpaceManager.getAttributeStringWithString("\(video?.title ?? "")".appending(tagString as String), lineSpace: 4, .left)
        }
        infoLab.customize { [weak self] (label) in
            label.hashtagColor = tagColor ?? rgb(30, 65, 255)
            label.hashtagSelectedColor = .lightGray
            label.lineSpacing = 4
            label.handleHashtagTap { (str) in
                DLog("tag str = \(str)")
                if let models = video?.category?.filter({ (tag) -> Bool in
                    return tag.title == str
                }), models.count > 0 {
                    self?.tagClickAction?(models[0])
                }
            }
        }
    }
    private func layoutSubs() {
        countsLab.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-10)
            make.bottom.equalTo(-10)
            make.height.equalTo(20)
        }
        infoLab.snp.makeConstraints { (make) in
            make.top.equalTo(12)
            make.bottom.equalTo(countsLab.snp.top).offset(-8)
            make.trailing.equalTo(-15)
            make.leading.equalTo(15)
        }
        
    }
}


class DetailTimerView: UICollectionReusableView {
    
    static let reuseId = "DetailTimerView"
    
    let infoLab: UILabel = {
        let lable = UILabel()
        lable.textColor = .darkText
        lable.textAlignment = .center
        lable.numberOfLines = 2
        lable.font = UIFont.boldSystemFont(ofSize: 15)
        lable.borderRadius = 7.5
        lable.backgroundColor = UIColor.colorGradientChangeWithSize(size: CGSize(width: screenWidth - 30, height: 45), direction: .level, startColor: rgb(247, 219, 172), endColor: rgb(223, 180, 127))
        return lable
    }()
    lazy var tipsButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor.clear
        button.addTarget(self, action: #selector(clickAction(_:)), for: .touchUpInside)
        return button
    }()
    var tipsTimer = TipTimerMg()
    var clickAction:(() ->())?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(infoLab)
        addSubview(tipsButton)
        layoutSubs()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setCountDown(_ countDown: CountDown) {
        infoLab.text = "\(countDown.countdown_intro ?? "")"
        if var time = countDown.countdown_time, time > 0 {
            if let display = countDown.countdown_display, display != 1 {
                infoLab.text = "\(countDown.countdown_intro ?? "")"
                return
            }
          
            tipsTimer.releaseTimer()
            tipsTimer.timer = Timer.every(1.0.seconds) { [weak self] in
                guard let strongSelf = self else { return }
                time = time - 1
                if time > 1 {
                    countDown.countdown_time = time
                    let times1 = LGConfig.timeDuration(duration: time)
                    strongSelf.infoLab.text = "\(countDown.countdown_intro ?? "") \(times1)"
                } else {
                    strongSelf.tipsTimer.releaseTimer()
                    strongSelf.infoLab.text = "\(countDown.countdown_intro ?? "")"
                }
            }
            RunLoop.current.add(tipsTimer.timer!, forMode: .common)
        }
    }
    @objc func clickAction(_ sender: UIButton) {
        clickAction?()
    }
    private func layoutSubs() {
        infoLab.snp.makeConstraints { (make) in
            make.bottom.equalToSuperview()
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.height.equalTo(45)
        }
        tipsButton.snp.makeConstraints { (make) in
            make.edges.equalToSuperview()
        }
    }
}


class UserVipTipView: UICollectionReusableView {
    static let reuseId = "UserVipTipView"
    lazy var coinUserButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor.clear
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        button.borderRadius = 22
        button.bordercolor = rgb(229, 177, 117)
        button.borderWidth = 1.0
        button.tag = 1
        button.setTitleColor(rgb(229, 177, 117), for: .normal)
        button.addTarget(self, action: #selector(clickAction(_:)), for: .touchUpInside)
        return button
    }()
    lazy var coinVipButton: UIButton = {
        let button = UIButton(type: .custom)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 15)
        button.borderRadius = 22
        button.tag = 2
        button.backgroundColor = ConstValue.kStypeColor
        button.addTarget(self, action: #selector(clickAction(_:)), for: .touchUpInside)
        return button
    }()
    let tipsLabel: UILabel = {
        let lab = UILabel()
        lab.textAlignment = .center
        lab.font = UIFont.boldSystemFont(ofSize: 15)
        lab.textColor = .white
        lab.borderRadius = 22
        lab.backgroundColor = ConstValue.kStypeColor
        return lab
    }()
    lazy var tipsButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor.clear
        button.tag = 3
        button.addTarget(self, action: #selector(clickAction(_:)), for: .touchUpInside)
        return button
    }()
    
    var clickAction:((_ actionId: Int) ->())?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(tipsLabel)
        addSubview(tipsButton)
        addSubview(coinUserButton)
        addSubview(coinVipButton)
        layoutSubs()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setModel(_ video: VideoNew?) {
        if let authError = video?.auth_error {
            self.isHidden = false
            if authError.key == 1001 {
                setVipOrCoins(false)
                tipsLabel.rz_colorfulConfer { (confer) in
                    confer.text("开通VIP观看完整版")?.font(UIFont.boldSystemFont(ofSize: 15))
                }
            } else if authError.key == 1002 {
                if UserModel.share().user?.is_vip == "y" {
                    setVipOrCoins(false)
                    tipsLabel.rz_colorfulConfer { (confer) in
                        confer.text("VIP\(video?.vip_coins ?? 0)钻石")?.font(UIFont.boldSystemFont(ofSize: 15))
                        confer.text(" 原价\(video?.coins ?? 0)钻石 ")?.font(UIFont.boldSystemFont(ofSize: 14)).strikethroughStyle(.single).strikethroughColor(.white)
                    }
                } else {
                    setVipOrCoins(true)
                    coinUserButton.setTitle("\(video?.coins ?? 0)钻石购买", for: .normal)
                    coinVipButton.setTitle("VIP价\(video?.vip_coins ?? 0)钻石", for: .normal)
                }
            }
        } else {
            self.isHidden = true
        }
    }
    func setVipOrCoins(_ tipHiden: Bool) {
        coinVipButton.isHidden = !tipHiden
        coinUserButton.isHidden = !tipHiden
        tipsButton.isHidden = tipHiden
        tipsLabel.isHidden = tipHiden
    }
    @objc func clickAction(_ sender: UIButton) {
        clickAction?(sender.tag)
    }
    private func layoutSubs() {
        tipsLabel.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview()
            make.bottom.equalTo(-20)
            make.width.equalTo(250)
            make.height.equalTo(44)
        }
        tipsButton.snp.makeConstraints { (make) in
            make.edges.equalTo(tipsLabel)
        }
        
        coinUserButton.snp.makeConstraints { (make) in
            make.leading.equalTo(30)
            make.bottom.equalTo(-20)
            make.width.equalTo((screenWidth - 80)/2)
            make.height.equalTo(44)
        }
        coinVipButton.snp.makeConstraints { (make) in
            make.trailing.equalTo(-30)
            make.bottom.equalTo(-20)
            make.width.equalTo((screenWidth - 80)/2)
            make.height.equalTo(44)
        }
    }
}

class UserShorVipView: UIView {
   
    lazy var coinUserButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor(white: 0, alpha: 0.2)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 12)
        button.borderRadius = 15
        button.bordercolor = .white
        button.borderWidth = 1
        button.tag = 1
        button.setTitleColor(.white, for: .normal)
        button.addTarget(self, action: #selector(clickAction(_:)), for: .touchUpInside)
        return button
    }()
    lazy var coinVipButton: UIButton = {
        let button = UIButton(type: .custom)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 12)
        button.borderRadius = 15
        button.bordercolor = .white
        button.borderWidth = 1
        button.tag = 2
        button.backgroundColor = UIColor(white: 0, alpha: 0.2)
        button.addTarget(self, action: #selector(clickAction(_:)), for: .touchUpInside)
        return button
    }()
    let tipsLabel: UILabel = {
        let lab = UILabel()
        lab.textAlignment = .center
        lab.font = UIFont.boldSystemFont(ofSize: 12)
        lab.textColor = .white
        lab.borderRadius = 15
        lab.bordercolor = .white
        lab.borderWidth = 1
        lab.backgroundColor = UIColor(white: 0, alpha: 0.2)
        return lab
    }()
    lazy var tipsButton: UIButton = {
        let button = UIButton(type: .custom)
        button.backgroundColor = UIColor.clear
        button.tag = 3
        button.addTarget(self, action: #selector(clickAction(_:)), for: .touchUpInside)
        return button
    }()
    
    var clickAction:((_ actionId: Int) ->())?
    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(tipsLabel)
        addSubview(tipsButton)
        addSubview(coinUserButton)
        addSubview(coinVipButton)
        layoutSubs()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func setModel(_ video: VideoNew?) {
        if let authError = video?.auth_error {
            self.isHidden = false
            if authError.key == 1001 {
                setVipOrCoins(false)
                tipsLabel.rz_colorfulConfer { (confer) in
                    confer.text("  开通VIP观看完整版  ")?.font(UIFont.boldSystemFont(ofSize: 12))
                }
            } else if authError.key == 1002 {
                if UserModel.share().user?.is_vip == "y" {
                    setVipOrCoins(false)
                    tipsLabel.rz_colorfulConfer { (confer) in
                        confer.text("  VIP\(video?.vip_coins ?? 0)钻石")?.font(UIFont.boldSystemFont(ofSize: 12))
                        confer.text("  原价\(video?.coins ?? 0)钻石")?.font(UIFont.boldSystemFont(ofSize: 11)).strikethroughStyle(.single).strikethroughColor(.white)
                    }
                } else {
                    setVipOrCoins(true)
                    coinUserButton.setTitle("  \(video?.coins ?? 0)钻石购买  ", for: .normal)
                    coinVipButton.setTitle("  VIP价\(video?.vip_coins ?? 0)钻石  ", for: .normal)
                }
            }
        } else {
            self.tag = 154
            self.isHidden = true
        }
    }
    func setVipOrCoins(_ tipHiden: Bool) {
        coinVipButton.isHidden = !tipHiden
        coinUserButton.isHidden = !tipHiden
        tipsButton.isHidden = tipHiden
        tipsLabel.isHidden = tipHiden
    }
    @objc func clickAction(_ sender: UIButton) {
        clickAction?(sender.tag)
    }
    private func layoutSubs() {
        tipsLabel.snp.makeConstraints { (make) in
            make.leading.equalToSuperview()
            make.centerY.equalToSuperview()
            make.height.equalTo(30)
        }
        tipsButton.snp.makeConstraints { (make) in
            make.edges.equalTo(tipsLabel)
        }
        
        coinUserButton.snp.makeConstraints { (make) in
            make.leading.equalToSuperview()
            make.centerY.equalToSuperview()
            make.height.equalTo(30)
        }
        coinVipButton.snp.makeConstraints { (make) in
            make.leading.equalTo(coinUserButton.snp.trailing).offset(15)
            make.centerY.equalToSuperview()
            make.height.equalTo(30)
        }
    }
}

class CoinsBuyAlert: UIView {
    
    static private let kAlertViewWidth: CGFloat = 269.5
    static private let kAlertViewHeight: CGFloat = 125
    
    public var itemButtonClick:(() ->Void)?
    let vipLabel: UILabel = {
        let lable = UILabel()
        lable.numberOfLines = 1
        lable.textColor = rgb(228, 183, 119)
        lable.font = UIFont.boldSystemFont(ofSize: 15)
        lable.textAlignment = .center
        lable.borderWidth = 0.5
        lable.bordercolor = rgb(48, 52, 68)
        return lable
    }()
    let normalLabell: UILabel = {
        let lable = UILabel()
        lable.numberOfLines = 1
        lable.textColor = rgb(228, 183, 119)
        lable.font = UIFont.boldSystemFont(ofSize: 15)
        lable.textAlignment = .center
        lable.borderWidth = 0.5
        lable.bordercolor = rgb(48, 52, 68)
        return lable
    }()
    let tipsLabel: UILabel = {
        let lable = UILabel()
        lable.numberOfLines = 2
        lable.font = UIFont.boldSystemFont(ofSize: 12)
        lable.textAlignment = .center
        lable.textColor = .lightGray
        return lable
    }()
    let titleLable: UILabel = {
        let lable = UILabel()
        lable.numberOfLines = 1
        lable.textColor = .white
        lable.font = UIFont.boldSystemFont(ofSize: 14)
        lable.textAlignment = .center
        return lable
    }()
    let actionButton: UIButton = {
        let button = UIButton(type: .custom)
        button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        button.setTitleColor(.white, for: .normal)
        button.backgroundColor = ConstValue.kStypeColor
        button.borderRadius = 22
        button.addTarget(self, action: #selector(buttonClick(_:)), for: .touchUpInside)
        return button
    }()
    private let alertView: UIView = {
        let alertView = UIView()
        alertView.backgroundColor = ConstValue.kCoverBgColor
        alertView.layer.cornerRadius = 15
        alertView.layer.masksToBounds = true
        return alertView
    }()
    private let topFakeView: UIImageView = {
        let alertView = UIImageView()
        alertView.backgroundColor = .clear
        alertView.isUserInteractionEnabled = false
        return alertView
    }()
    lazy var tap: UITapGestureRecognizer = {
        let t = UITapGestureRecognizer.init(target: self, action: #selector(tap(_:)))
        return t
    }()
    
    deinit {
        DLog("弹框被释放")
    }
    
    public init(frame: CGRect, buttonTitle: String,vipMsg: String, normalMsg: String, tipsMsg: String ,titleMsg: String) {
        super.init(frame: frame)
        
        self.backgroundColor = UIColor(white: 0, alpha: 0.6)
        titleLable.text = titleMsg
        titleLable.text = titleMsg
        vipLabel.text = vipMsg
        normalLabell.text = normalMsg
        tipsLabel.text = tipsMsg
        actionButton.setTitle(buttonTitle, for: .normal)
        alertView.addSubview(topFakeView)
        alertView.addSubview(titleLable)
        alertView.addSubview(vipLabel)
        alertView.addSubview(normalLabell)
        alertView.addSubview(tipsLabel)
        alertView.addSubview(actionButton)
        addSubview(alertView)
        layoutPageSubviews()
        self.addGestureRecognizer(tap)
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    @objc func buttonClick(_ sender: UIButton) {
        itemButtonClick?()
        hideFromWindow()
    }
    @objc func tap(_ sender: UIGestureRecognizer) {
        let touchPoint = sender.location(in: self)
        if alertView.frame.contains(touchPoint) {
            DLog("点击在弹框中")
            return
        }
        hideFromWindow()
    }
    func layoutPageSubviews() {
        alertView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.width.equalTo(269.5)
            make.height.equalTo(260)
        }
        topFakeView.snp.makeConstraints { (make) in
            make.top.leading.trailing.equalToSuperview()
            make.bottom.equalTo(-60)
        }
        titleLable.snp.makeConstraints { (make) in
            make.top.equalTo(20)
            make.height.equalTo(20)
            make.leading.equalTo(10)
            make.trailing.equalTo(-10)
        }
        vipLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(30)
            make.trailing.equalTo(-30)
            make.top.equalTo(titleLable.snp.bottom).offset(20)
            make.height.equalTo(40)
        }
        normalLabell.snp.makeConstraints { (make) in
            make.leading.equalTo(30)
            make.trailing.equalTo(-30)
            make.top.equalTo(vipLabel.snp.bottom).offset(10)
            make.height.equalTo(40)
        }
        tipsLabel.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-15)
            make.top.equalTo(normalLabell.snp.bottom).offset(28)
            make.bottom.equalTo(actionButton.snp.top).offset(-10)
        }
        actionButton.snp.makeConstraints { (make) in
            make.leading.equalTo(20)
            make.trailing.equalTo(-20)
            make.bottom.equalTo(-20)
            make.height.equalTo(40)
        }
        
    }
    /// 展示
    func showInWindow() {
        if let window = UIApplication.shared.keyWindow {
            var hasAdd: Bool = false
            window.subviews.forEach { (view) in
                if view is CoinsBuyAlert  {
                    hasAdd = true
                }
            }
            if !hasAdd {
                window.addSubview(self)
                self.snp.makeConstraints { (make) in
                    make.edges.equalToSuperview()
                }
            }
        }
    }
    
    /// 隐藏
    func hideFromWindow() {
        if self.superview != nil {
            self.removeFromSuperview()
        }
    }
}



