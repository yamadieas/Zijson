
import UIKit

class DetailSegHeader: UICollectionReusableView {
    static let reuseId = "DetailSegHeader"
    lazy var userTapBtn: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitle("更多TA的视频", for: .normal)
        btn.setTitleColor(UIColor.white, for: .normal)
        btn.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
        return btn
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        addSubview(userTapBtn)
        layoutPageSub()
    }
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    func layoutPageSub() {
        userTapBtn.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.top.equalToSuperview()
            make.bottom.equalTo(-8)
        }
    }

}
