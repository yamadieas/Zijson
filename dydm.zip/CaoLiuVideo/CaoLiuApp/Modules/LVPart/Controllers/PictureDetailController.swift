
import UIKit
import NicooNetwork

class PictureDetailController: CLBaseViewController {
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    private lazy var navBar: CLNavigationBar = {
        let bar = CLNavigationBar()
        bar.backgroundColor = .darkText
        bar.navBackBlack = false
        bar.titleLabel.textAlignment = .left
        bar.lineView.isHidden = true
        bar.titleLabel.textColor = .white
        bar.titleLabel.font = UIFont.systemFont(ofSize: 16)
        bar.delegate = self
        return bar
    }()
    let indexNumber: UILabel = {
        let label = UILabel()
        label.textColor = .white
        label.textAlignment = .right
        label.font = UIFont.systemFont(ofSize: 16)
        return label
    }()
    let bottomView: UIView = {
        let view = UIView()
        view.backgroundColor = UIColor.darkText
        return view
    }()
    lazy var favorItem: DYControltem = {
        let item = DYControltem(frame: CGRect.zero)
        item.iconImage = "icon_home_like_before"
        item.title = "0"
        item.msgLable.textColor = .white
        item.iconButton.snp.updateConstraints { (make) in
            make.width.height.equalTo(30)
        }
        return item
    }()
    lazy var shareItem: DYControltem = {
        let item = DYControltem(frame: CGRect.zero)
        item.iconImage = "pictureVip"
        item.title = "賺會員"
        item.msgLable.textColor = .white
        item.iconButton.snp.updateConstraints { (make) in
            make.height.equalTo(30)
            make.width.equalTo(35)
        }
        return item
    }()
    private let layout: UICollectionViewFlowLayout = {
        let l = UICollectionViewFlowLayout()
        l.scrollDirection = .horizontal
        l.itemSize = CGSize(width: screenWidth, height: screenHeight - safeAreaTopHeight - 72)
        l.minimumInteritemSpacing = 0
        l.minimumLineSpacing = 0
        l.sectionInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        return l
    }()
    lazy var collView: UICollectionView = {
        let collection = UICollectionView(frame: CGRect.zero, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.showsHorizontalScrollIndicator = false
        collection.isPagingEnabled = true
        collection.backgroundColor = .clear
        collection.register(PictureDetailCell.classForCoder(), forCellWithReuseIdentifier: PictureDetailCell.cellId)
        return collection
    }()
    
    private lazy var pictureInfoApi: PictureDetailApi =  {
        let api = PictureDetailApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    var picture: PictureModel?
    var pictures = [String]()
    var currentIndex: Int = 1
    var lastContentOffSet: CGFloat = 0
    
    let userViewModel = UserInfoViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .darkText
        navBar.titleLabel.text = picture?.source_title
        setUpUI()
        loadData()
    }
    
    private func setUpUI() {
        view.addSubview(navBar)
        navBar.addSubview(indexNumber)
        view.addSubview(bottomView)
        view.addSubview(collView)
        bottomView.addSubview(favorItem)
        bottomView.addSubview(shareItem)
        layoutPageSubs()
        favorItem.itemClickHandle = { [weak self] _ in
            guard let strSelf = self else { return }
            self?.addFavorOrNot(!strSelf.favorItem.iconButton.isSelected)
        }
        shareItem.itemClickHandle = { [weak self] _ in
            let shareVc = ShareContentController()
            self?.navigationController?.pushViewController(shareVc, animated: true)
        }
    }
    private func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: true)
        let _ = pictureInfoApi.loadData()
    }
    private func showCoinBuyAlert() {
        guard let coins = picture?.coins else { return }
        var model = ConvertCardAlertModel()
        if coins <= 0  { // vip提示
            let succModel = ConvertCardAlertModel(title: nil, msgInfo: "当前图集为会员专享", commitTitle: "開通會員，观看完整图集", success: true)
            model = succModel
        } else {
            let failedModel = ConvertCardAlertModel(title: nil, msgInfo: "当前图集需钻石解锁", commitTitle: "\(coins)钻石,解锁看完整图集", success: false)
            model = failedModel
        }
        let controller = AlertManagerController(alertModel: model)
        controller.modalPresentationStyle = .overCurrentContext
        controller.view.backgroundColor = UIColor(white: 0.0, alpha: 0.8)
        controller.touchDissMiss = true
        present(controller, animated: false, completion: nil)
        controller.commitActionHandler = {
            if coins > 0 {  // 钻石够买
                self.buyCoinsPictures()
            } else {
                let vipvc = VipCardsController()
                self.navigationController?.pushViewController(vipvc, animated: true)
            }
        }
    }
    
    /// 点赞
    func addFavorOrNot(_ isFavor: Bool) {
        let likeCount = picture?.like_count ?? 0
        var favorCount = 0
        if isFavor {  // 不是点赞
            favorCount = likeCount + 1
        } else {
            favorCount = likeCount > 0 ? likeCount - 1 : 0
        }
        picture?.like_count = favorCount
        picture?.is_like = isFavor ? 1 : 0
        favorItem.iconButton.isSelected = isFavor
        favorItem.iconImage = isFavor ? "icon_home_like_after" : "icon_home_like_before"
        favorItem.title = getStringWithNumber(favorCount)
        userViewModel.addPictureFavor([UserFavorAddApi.kPicture_id: picture?.id ?? 0])
    }
    /// 金币购买图集
    func buyCoinsPictures() {
        XSProgressHUD.showCycleProgress(msg: "支付中...", onView: view, animated: false)
        userViewModel.coinsBuyImgs(params: [UseBuyImgsApi.kPicId: picture?.id ?? 0] , succeedHandler: { [weak self] _ in
            guard let strongSelf = self else { return }
            XSProgressHUD.hide(for: strongSelf.view, animated: true)
            XSAlert.show(type: .success, text: "恭喜您支付成功")
            if let userCoins = UserModel.share().user?.coins, let vCoins = strongSelf.picture?.coins, userCoins >= vCoins {
                UserModel.share().user?.coins = userCoins - vCoins
                NotificationCenter.default.post(name: Notification.Name.kUserBasicalInformationChanged, object: nil)
            }
            strongSelf.picture?.coins = 0
            strongSelf.picture?.free_count = "\(strongSelf.pictures.count)"
            strongSelf.picture?.is_free_all = 1
            strongSelf.collView.reloadData()
        }) { [weak self] (failMsg) in
            guard let strongSelf = self else { return }
            strongSelf.showCoinBuyAlert(failMsg)
            XSProgressHUD.hide(for: strongSelf.view, animated: true)
        }
    }
    func showCoinBuyAlert(_ msg: String) {
        let failedModel = ConvertCardAlertModel(title: nil, msgInfo: msg, success: false)
        let controller = AlertManagerController(cardModel: failedModel)
        controller.modalPresentationStyle = .overCurrentContext
        controller.view.backgroundColor = UIColor(white: 0.0, alpha: 0.7)
        controller.touchDissMiss = true
        present(controller, animated: false, completion: nil)
        controller.commitActionHandler = {
            let vipVC = CoinsCardsController()
            vipVC.isCoins = true
            self.navigationController?.pushViewController(vipVC, animated: true)
        }
    }

}
// MARK: - UICollectionViewDelegate
extension PictureDetailController: UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        var pics = self.pictures
        if picture?.is_free_all == 0 {
            guard let freeCount = Int(picture?.free_count ?? "0") else { return pics.count }
            if pics.count < freeCount {
                XSAlert.show(type: .text, text: "傻逼，数据都配错了")
                return pics.count
            }
            var imgFrees = [String]()
            for i in 0 ..< freeCount {
                let img = pics[i]
                imgFrees.append(img)
            }
            pics = imgFrees
        }
        return pics.count
    }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: PictureDetailCell.cellId, for: indexPath) as! PictureDetailCell
        cell.imgV.kfSetVerticalImageWithUrl(pictures[indexPath.item])
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        // 网图加载器
        var pics = self.pictures
        if pics.count <= indexPath.item { return }
        if picture?.is_free_all == 0 {
            guard let freeCount = Int(picture?.free_count ?? "0") else { return }
            var imgFrees = [String]()
            for i in 0 ..< freeCount {
                let img = pics[i]
                imgFrees.append(img)
            }
            pics = imgFrees
        }
        let loader = JXKingfisherLoader()
        // 数据源
        let source = JXNetworkingDataSource(photoLoader: loader, numberOfItems: { () -> Int in
            return pics.count
        }, placeholder: { index -> UIImage? in
            return LGConfig.getImage("playCellBg")
        }) { index -> String? in
            return pics[index]
        }
        // 视图代理，实现了数字页码指示器
        let delegate = JXNumberPageControlDelegate() 
        // 转场动画
        let trans = JXPhotoBrowserZoomTransitioning { (browser, index, view) -> UIView? in
            return nil
        }
        // 打开浏览器
        JXPhotoBrowser(dataSource: source, delegate: delegate, transDelegate: trans)
            .show(pageIndex: indexPath.item)
    }
}

// MARK: UIScrollViewDelegate
extension PictureDetailController: UIScrollViewDelegate {

    func scrollViewDidScroll(_ scrollView: UIScrollView) {
         if picture?.is_free_all == 1 { return }
        let offsetX = scrollView.contentOffset.x
        let offSet = offsetX - lastContentOffSet
        lastContentOffSet = offsetX
        if offSet > 0 && offsetX > 0 {
            if let freeCstr = picture?.free_count, let freeC = Int(freeCstr) {
                if offsetX + screenWidth > CGFloat(freeC) * screenWidth {
                    showCoinBuyAlert()
                }
            }
        }
    }

    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        if picture?.is_free_all == 1 {
            let offsetX = scrollView.contentOffset.x
            indexNumber.text = "\(Int(offsetX/screenWidth) + 1)/\(pictures.count)"
            return
        }
        if let freeCstr = picture?.free_count, let freeC = Int(freeCstr) {
            let offsetX = scrollView.contentOffset.x
            if offsetX + screenWidth > CGFloat(freeC) * screenWidth {
                collView.scrollToItem(at: IndexPath(item: freeC - 1, section: 0), at: .centeredHorizontally, animated: false)
                indexNumber.text = "\(freeC)/\(pictures.count)"
            } else {
                indexNumber.text = "\(Int(offsetX/screenWidth) + 1)/\(pictures.count)"
            }
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension PictureDetailController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is PictureDetailApi {
            return [PictureDetailApi.kPicId : picture?.id ?? 0]
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is PictureDetailApi {
            if let pictureInfo = manager.fetchJSONData(VideoReformer()) as? PictureModel, let pics = pictureInfo.images, pics.count > 0 {
                picture = pictureInfo
                pictures = pics
                collView.reloadData()
                indexNumber.text = "1/\(pictures.count)"
                favorItem.title = getStringWithNumber(picture?.like_count ?? 0)
                favorItem.iconButton.isSelected = pictureInfo.is_like == 1
                favorItem.iconImage = pictureInfo.is_like == 1 ? "icon_home_like_after" : "icon_home_like_before"
                if pictureInfo.is_free_all != 1 && pictureInfo.free_count == "1" {
                    showCoinBuyAlert()
                }
            } else {
                XSAlert.show(type: .text, text: "暫無圖片")
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        if manager is PictureDetailApi {
            NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: safeAreaTopHeight, clickHandler: {
                self.loadData()
            })
        }
    }
}

extension PictureDetailController {
    func layoutPageSubs() {
        navBar.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(safeAreaTopHeight)
        }
        bottomView.snp.makeConstraints { (make) in
            make.leading.trailing.bottom.equalToSuperview()
            make.height.equalTo(UIDevice.current.isiPhoneXSeriesDevices() ? 88 : 72)
        }
        collView.snp.makeConstraints { (make) in
            make.leading.trailing.equalToSuperview()
            make.top.equalTo(navBar.snp.bottom)
            make.bottom.equalTo(bottomView.snp.top)
        }
        indexNumber.snp.makeConstraints { (make) in
            make.trailing.equalTo(-10)
            make.centerY.equalTo(navBar.titleLabel)
            make.width.equalTo(50)
        }
        shareItem.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview().offset(60)
            make.centerY.equalToSuperview().offset(UIDevice.current.isiPhoneXSeriesDevices() ? -15 : 0)
            make.width.height.equalTo(50)
        }
        favorItem.snp.makeConstraints { (make) in
            make.centerX.equalToSuperview().offset(-60)
            make.centerY.equalToSuperview().offset(UIDevice.current.isiPhoneXSeriesDevices() ? -15 : 0)
            make.width.height.equalTo(50)
        }
    }
   
}

// MARK: - CLNavigationBarDelegate
extension PictureDetailController: CLNavigationBarDelegate  {
    func backAction() {
        navigationController?.popViewController(animated: true)
    }
}

