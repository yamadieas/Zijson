
import UIKit
import NicooNetwork
import MJRefresh
import JXSegmentedView

extension FocusVideoController: JXSegmentedListContainerViewListDelegate {
    func listView() -> UIView {
        return self.view
    }
}
class FocusVideoController: UIViewController {
    
    lazy var collectionView: UICollectionView = {
        let layout = WaterfallMutiSectionFlowLayout()
        layout.sectionHeadersPinToVisibleBounds = true
        layout.delegate = self
        let collection = UICollectionView(frame: self.view.bounds, collectionViewLayout: layout)
        collection.delegate = self
        collection.dataSource = self
        collection.backgroundColor = UIColor.clear
        collection.register(ShortVideoCell.classForCoder(), forCellWithReuseIdentifier: ShortVideoCell.cellId)
        collection.register(LongVideoCell.classForCoder(), forCellWithReuseIdentifier: LongVideoCell.cellId)
        collection.register(UserRecScrollCell.classForCoder(), forCellWithReuseIdentifier: UserRecScrollCell.cellId)
        collection.register(SegmentItemView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: SegmentItemView.identifier)
        collection.register(SegmentItemView.classForCoder(), forSupplementaryViewOfKind: UICollectionView.elementKindSectionFooter, withReuseIdentifier: SegmentItemView.identifier)
        collection.mj_footer = loadMoreView
        collection.mj_header = refreshView
        return collection
    }()
    lazy private var loadMoreView: MJRefreshAutoNormalFooter = {
        weak var weakSelf = self
        let loadmore = MJRefreshAutoNormalFooter(refreshingBlock: {
            weakSelf?.loadNextPage()
        })
        loadmore?.setTitle("", for: .idle)
        loadmore?.setTitle("已經到底了", for: .noMoreData)
        loadmore?.stateLabel.font = ConstValue.kRefreshLableFont
        return loadmore!
    }()
    
    lazy private var refreshView: MJRefreshNormalHeader = {
        weak var weakSelf = self
        let mjRefreshHeader = MJRefreshNormalHeader(refreshingBlock: {
            weakSelf?.loadFirstPage()
        })
        mjRefreshHeader?.activityIndicatorViewStyle = .white
        mjRefreshHeader?.arrowView.image = ConstValue.refreshImg
        mjRefreshHeader?.stateLabel.font = ConstValue.kRefreshLableFont
        mjRefreshHeader?.lastUpdatedTimeLabel.font = ConstValue.kRefreshLableFont
        return mjRefreshHeader!
    }()
    private lazy var videoApi: VideoAttentionListApi =  {
        let api = VideoAttentionListApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var anchorApi: RelationActorApi =  {
        let api = RelationActorApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    
    /// 所在page的索引
    var segIndex: Int = 0
   
    var cateModels = [VideoNew]()
    var userModels = [CLUserInfo]()
    /// 用户id
    var userId: Int?
    var segmentIndex: Int = 0
    
    let userViewModel = UserInfoViewModel()
    
    /// 是否弹起短视频播放页
    var isPresentPlay: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        view.addSubview(collectionView)
        layoutPageSubviews()
        loadAnchorData()
        loadData()
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        NotificationCenter.default.post(name: Notification.Name.kMainTopBarColotNotification, object: nil, userInfo: ["AutoTopBarBgColor": 0])
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        collectionView.frame = CGRect(x: 0, y: 0, width: screenWidth, height: screenHeight - safeAreaBottomHeight - 137 - statusBarHeight)
    }
    private func goUserCenter(_ user: CLUserInfo?) {
        let userCenter = UserMCenterController()
        userCenter.userCode = user?.code
        navigationController?.pushViewController(userCenter, animated: true)
    }

}

// MARK: - Private - Funcs
private extension FocusVideoController {
    
    func loadAnchorData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: true)
        let _ = anchorApi.loadData()
    }
    func loadData() {
        NicooErrorView.removeErrorMeesageFrom(view)
        XSProgressHUD.showCycleProgress(msg: nil, onView: view, animated: true)
        let _ = videoApi.loadData()
    }
    func refreshData() {
        loadAnchorData()
        loadFirstPage()
    }
    func loadFirstPage() {
        NicooErrorView.removeErrorMeesageFrom(view)
        _ = videoApi.loadData()
    }
    func loadNextPage() {
        let _ = videoApi.loadNextPage()
    }
    func addUserFocus(_ userCode: String) {
        if userCode == UserModel.share().user?.code {
            XSAlert.show(type: .error, text: "不能关注自己")
            return
        }
        userViewModel.followAddOrCancelSuccessHandler = {[weak self]  isAdd in
            guard let strongSelf = self else { return }
            NotificationCenter.default.post(name: NSNotification.Name.kHomeRefreshAttentionStateNotification, object: nil, userInfo: ["code": userCode, "statu" : 1])
            strongSelf.refreshData()
        }
        userViewModel.followOrCancelFailureHandler = { (isAdd, msg) in
            XSAlert.show(type: .error, text: msg)
        }
        userViewModel.loadAddFollowApi([UserAddFollowApi.kUserId: userCode])
    }
    func endRefreshing() {
        collectionView.mj_footer.endRefreshing()
        collectionView.mj_header.endRefreshing()
    }
    func succeedRequest(_ models: [VideoNew]) {
        if videoApi.pageNumber == 1 {
            cateModels = models
            if cateModels.count == 0 {
                NicooErrorView.showErrorMessage(.noData, "妳還沒有关注過的視頻\n快去关注吧", on: view, topMargin: safeAreaTopHeight + UserRecScrollCell.itemSize.height) {
                    self.loadData()
                }
            }
        } else {
            cateModels.append(contentsOf: models)
        }
        loadMoreView.isHidden = models.count == 0
        endRefreshing()
        collectionView.reloadData()
    }
    
    func failedRequest(_ manager: NicooBaseAPIManager) {
        endRefreshing()
        NicooErrorView.showErrorMessage(.noNetwork, on: view, topMargin: 0, clickHandler: {
            self.loadData()
        })
    }
}

// MARK: - UICollectionViewDelegateFlowLayout
extension FocusVideoController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        if kind == UICollectionView.elementKindSectionHeader {
            let header = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: SegmentItemView.identifier, for: indexPath) as! SegmentItemView
            header.backgroundColor = ConstValue.kVcViewColor
            header.setTitles(["全部", "只看长视频", "只看短视频"])
            header.setIndex(segmentIndex)
            header.segAction = { [weak self] index in
                self?.segmentIndex = index
                self?.loadData()
            }
            return header
        }
        return UICollectionReusableView()
    }
}
extension FocusVideoController: WaterfallMutiSectionDelegate {
    func heightForRowAtIndexPath(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, indexPath: IndexPath, itemWidth: CGFloat) -> CGFloat {
        if indexPath.section == 0 {
            return UserRecScrollCell.itemSize.height
        }
        if segmentIndex == 0 {
            if cateModels.count > indexPath.item {
                let video = cateModels[indexPath.item]
                return video.is_long == 0 ? ShortVideoCell.itemSizeDouble.height : LongVideoCell.itemSizeDouble.height
            }
        } else if segmentIndex == 2 {
            return ShortVideoCell.itemSizeDouble.height
        } else if segmentIndex == 1 {
            return LongVideoCell.itemSizeDouble.height
        }
        return .zero
    }
    
    func columnNumber(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> Int {
        if section == 0 {
            return 1
        }
        return 2
    }
    
  func referenceSizeForHeader(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGSize {
    if section == 1 {
        return CGSize(width: screenWidth, height: 50)
    }
    return .zero
  }
  
  func referenceSizeForFooter(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGSize {
    return .zero
  }
  
  func insetForSection(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> UIEdgeInsets {
    if section == 0 {
        return UIEdgeInsets(top: 5, left: 0, bottom: 0, right: 0)
    }
    return UIEdgeInsets(top: 5, left: 15, bottom: 5, right: 15)
  }
  
  
  func lineSpacing(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
    return 10.0
  }
  
  func interitemSpacing(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
    return 10.0
  }
  
  func spacingWithLastSection(collectionView collection: UICollectionView, layout: WaterfallMutiSectionFlowLayout, section: Int) -> CGFloat {
    return 0
  }
}

// MARK: - UICollectionViewDelegate, UICollectionViewDataSource
extension FocusVideoController: UICollectionViewDelegate, UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 2
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }
        return cateModels.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if indexPath.section == 0 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: UserRecScrollCell.cellId, for: indexPath) as! UserRecScrollCell
            cell.setUsers(userModels)
            cell.addFocusHandler = { [weak self] index in
                guard let strongSelf = self else { return }
                if index >= strongSelf.userModels.count { return }
                self?.addUserFocus(strongSelf.userModels[index].code ?? "")
            }
            cell.itemClickHandler = { [weak self] index in
                guard let strongSelf = self else { return }
                if index == 0 {
                    let vc = SearchAnchorController()
                    vc.pageType = 1
                    self?.navigationController?.pushViewController(vc, animated: true)
                } else {
                    if index-1 >= strongSelf.userModels.count { return }
                    self?.goUserCenter(strongSelf.userModels[index-1])
                }
            }
            return cell
        }
        if segmentIndex == 0 {
            let video = cateModels[indexPath.item]
            if video.is_long == 0 {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShortVideoCell.cellId, for: indexPath) as! ShortVideoCell
                if cateModels.count > indexPath.item {
                    let model = cateModels[indexPath.item]
                    cell.setModel(model: model,.itemSizeDouble)
                    cell.avataClickHandler = { [weak self] in
                        self?.goUserCenter(model.user)
                    }
                }
                return cell
            } else {
                let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongVideoCell.cellId, for: indexPath) as! LongVideoCell
                let model = cateModels[indexPath.row]
                 cell.setModel(model,.itemSizeDouble)
                cell.avataClickHandler = { [weak self] in
                    self?.goUserCenter(model.user)
                }
                return cell
            }
           
        } else if segmentIndex == 2 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: ShortVideoCell.cellId, for: indexPath) as! ShortVideoCell
            if cateModels.count > indexPath.item {
                let model = cateModels[indexPath.item]
                cell.setModel(model: model,.itemSizeDouble)
                cell.avataClickHandler = { [weak self] in
                    self?.goUserCenter(model.user)
                }
            }
            return cell
        } else if segmentIndex == 1 {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: LongVideoCell.cellId, for: indexPath) as! LongVideoCell
            let model = cateModels[indexPath.row]
             cell.setModel(model,.itemSizeDouble)
            cell.avataClickHandler = { [weak self] in
                self?.goUserCenter(model.user)
            }
            return cell
        }
        return UICollectionViewCell()
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: true)
        if indexPath.section == 0 {
            return
        }
        let video = self.cateModels[indexPath.item]
        if segmentIndex == 0 {
            if video.is_long == 1 {
                goLongVideoDetail(video)
            } else {
                goShortVideoPlayerVC(video)
            }
        } else if segmentIndex == 2 {
            goShortVideoPlayerVC(video)
        } else if segmentIndex == 1 {
            goLongVideoDetail(video)
        }
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension FocusVideoController: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is VideoAttentionListApi {
            if segmentIndex == 1 {
                return [VideoAttentionListApi.kIslong: 1]
            } else if segmentIndex == 2 {
                return [VideoAttentionListApi.kIslong: 0]
            }
        }
//        if manager is RelationActorApi {
//            return [RelationActorApi.kIslong: 1]
//        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager is VideoAttentionListApi {
            if let videoList = manager.fetchJSONData(VideoReformer()) as? [VideoNew] {
                succeedRequest(videoList)
            }
        }
        if manager is RelationActorApi {
            if let users = manager.fetchJSONData(SearchReformer()) as? [CLUserInfo] {
                userModels = users
                collectionView.reloadData()
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        XSProgressHUD.hide(for: view, animated: false)
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        if manager is VideoAttentionListApi {
            failedRequest(manager)
        }
    }
}

// MARK: - Layout
private extension FocusVideoController {
    
    func layoutPageSubviews() {
        layoutCollection()
    }
    func layoutCollection() {
        collectionView.snp.makeConstraints { (make) in
            make.leading.trailing.top.equalToSuperview()
            if #available(iOS 11.0, *) {
                make.bottom.equalTo(view.safeAreaLayoutGuide.snp.bottom).offset(-44)
            } else {
                make.bottom.equalToSuperview().offset(-44)
            }
        }
    }
    
}
