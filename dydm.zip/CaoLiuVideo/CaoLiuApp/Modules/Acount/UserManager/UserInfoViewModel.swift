
import UIKit
import NicooNetwork

struct CellEditModel {
    var videoModel: VideoModel?
    var isSelected: Bool?   // 此属性是本地为了区分数据Model的选中狀態而加的，初始值应该为nil
    
}

/// 用户信息ViewModel
class UserInfoViewModel: NSObject {
    private lazy var uploadCrashApi: UploadCrashLogApi = {
        let api = UploadCrashLogApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var uploadActionApi: UploadActionsLogApi = {
        let api = UploadActionsLogApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var userInfoApi: UserInfoApi = {
        let api = UserInfoApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var userInfoOtherApi: UserInfoOtherApi = {
        let api = UserInfoOtherApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var userFadeBackApi: UserFadeBackApi = {
        let api = UserFadeBackApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var videoFavorApi: UserFavorAddApi =  {
        let api = UserFavorAddApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var userAddFollowApi: UserAddFollowApi = {
        let api = UserAddFollowApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var userCancleFollowApi: UserCancleFollowApi = {
        let api = UserCancleFollowApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    /// 反馈消息 回复
    private lazy var replyApi: FeedReplyApi = {
        let api = FeedReplyApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    /// 消息 回复
    private lazy var chatReplyApi: ChatMsgReplyApi = {
        let api = ChatMsgReplyApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var acountBackApi: AcountBackWithPhoneApi =  {
        let api = AcountBackWithPhoneApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var sortFindApi: RecallByCardApi = {
        let api = RecallByCardApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    /// 兌換vip详情
    private lazy var convertInfoApi: VipConvertInfoApi = {
        let api = VipConvertInfoApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    /// 兌換vip
    private lazy var convertApi: VipCardExChangeApi = {
        let api = VipCardExChangeApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var inviteLinkApi: UserInviteLinkApi = {
        let api = UserInviteLinkApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var coinsBuyVideoApi: UseBuyVideoApi = {
        let api = UseBuyVideoApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var coinsBuyPicApi: UseBuyImgsApi = {
        let api = UseBuyImgsApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var coinsBuyMsgApi: UseBuyMsgApi = {
        let api = UseBuyMsgApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var userSignApi: UserSignApi = {
        let api = UserSignApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    private lazy var shopUpdateInfoApi: ShopUpdateInfoApi = {
        let api = ShopUpdateInfoApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    
    var videoList = [VideoNew]()
    var cellEditModelList = [CellEditModel]()
    /// 崩溃日志
    var paramsCrashLog: [String: Any]?
    /// 用户详情
    var paramsUserInfo: [String: Any]?
    /// 用户反馈Api参数
    var paramsFadeBack: [String: Any]?
    /// 用户回复反馈消息
    var paramsReply: [String: Any]?
    /// 用户点赞视频Api参数
    var paramsFavor: [String: Any]?
    /// 用户手機號找回账号信息
    var paramsAcountBack: [String: Any]?
    /// 用户盐找回
    var paramsSort: [String: Any]?
    /// paramsForuser
    var paramsUserCenter: [String: Any]?
    /// 关注相关参数
    var paramsFollow: [String: Any]?
    /// 兌換vip
    var paramsExchange:[String: Any]?
    var paramsAddGroup: [String : Any]?
    /// 金币购买视频
    var paramsCoinsBuyVideo: [String : Any]?
    
    /// 历史观看删除成功回调（用于回调用户主页，刷新历史观看列表）
    var loadDeletedWatchedListSuccessHandler:(() ->Void)?
    /// 用户信息请求
    var loadUserInfoSuccessHandler:(() ->Void)?
    var loadUserInfoFailHandler:(() ->Void)?
    /// 用户别人信息请求
    var loadUserOtherInfoSuccessHandler:((_ user: CLUserInfo) ->Void)?
    var loadUserOtherInfoFailHandler:(() ->Void)?
    /// 用户找回原账号
    var loadUserFindBackSuccessHandler:(() ->Void)?
    var loadUserFindBackFailHandler:((_ msg: String) ->Void)?
    /// 用户sort回账号毁掉
    var sortFindApiSuccessHandler:(() ->Void)?
    var sortFindApiFailHandler:(() ->Void)?
    /// 用户反馈
    var fadeBackSuccessHandler:(() ->Void)?
    var fadeBackFailHandler:((_ msg: String) ->Void)?
    /// 用户回复反馈消息 回调
    var replyApiSuccessHandler:((_ msgModel: MsgModel) ->Void)?
    var replyApiFailHandler:((_ msg: String) ->Void)?
    
    /// 用户回复消息
    var chatReplyApiSuccessHandler:(() ->Void)?
    var chatReplyApiFailHandler:((_ msg: String) ->Void)?

    /// 添加关注 取消关注回调
    var followAddOrCancelSuccessHandler:((_ isAdd: Bool)->())?
    var followOrCancelFailureHandler:((_ isAdd: Bool, _ msg: String)->())?
    // 用户兌換會員卡
    var exchangeInfoApiSuccessHandler:((_ model: ExCoinsInfo) ->Void)?
    var exchangeIndoApiFailHandler:((_ msg: String) ->Void)?
    /// 兌換结果
    var convertVipSuccessHandler:(() ->Void)?
    var convertVipFailHandler:((_ msg: String) ->Void)?
    var addGroupLinkSuccessHandler: ((_ models: [AddGroupLinkModel])->())?
    var addGroupLinkFailureHandelr: ((_ msg: String)->())?
    /// 购买视频
    var coinsBuyVideoSuccessHandler:((_ mu: String) ->Void)?
    var coinsBuyVideovFailedHandler:((_ msg: String) ->Void)?
    /// 购买楼风信息
    var coinsBuyLFInfoSuccessHandler:((_ mu: LFMsgModel) ->Void)?
    var coinsBuyLFInfoFailedHandler:((_ msg: String) ->Void)?
    /// 签到
    var signSuccessHandler:((_ sign: SignInfo) ->Void)?
    var signFailedHandler:(() ->Void)?
    
    func uploadCrashLog(_ params: [String: Any]?) {
        paramsCrashLog = params
        _ = uploadCrashApi.loadData()
    }
    func uploadActionLog(_ params: [String: Any]?) {
        paramsCrashLog = params
        _ = uploadActionApi.loadData()
    }
    /// 请求用户信息
    func loadUserInfo(params: [String : Any]? ,
                      succeedHandler: @escaping () -> (),
                      failHandler: @escaping () -> ())
    {
        loadUserInfoSuccessHandler = succeedHandler
        loadUserInfoFailHandler = failHandler
        let _ = userInfoApi.loadData()
    }
    /// 请求用户信息
    func loadUserOtherInfo(_ params: [String : Any]? ,
                           succeedHandler: @escaping (_ user: CLUserInfo) -> (),
                           failHandler: @escaping () -> ())
    {
        paramsUserInfo = params
        loadUserOtherInfoSuccessHandler = succeedHandler
        loadUserOtherInfoFailHandler = failHandler
        let _ = userInfoOtherApi.loadData()
    }
    /// 请求shop信息修改
    func loadShopInfoUpdate(_ params: [String : Any]? ,
                           succeedHandler: @escaping () -> (),
                           failHandler: @escaping (_ msg: String) -> ())
    {
        paramsUserInfo = params
        loadUserFindBackSuccessHandler = succeedHandler
        loadUserFindBackFailHandler = failHandler
        let _ = shopUpdateInfoApi.loadData()
    }
    
    /// 日常签到
    func userDailySign(succeedHandler: @escaping (_ sign: SignInfo) -> (),
                       failHandler: @escaping () -> ()) {
        signSuccessHandler = succeedHandler
        signFailedHandler = failHandler
        _ = userSignApi.loadData()
    }
    /// 用户反馈
    func fadeBack(_ params: [String: Any]) {
        paramsFadeBack = params
        let _ = userFadeBackApi.loadData()
    }
    
    /// 消息回复
    func replyFeedMsg(_ params: [String: Any]) {
        paramsReply = params
        let _ = replyApi.loadData()
    }
    func chatReplayMsg(_ params: [String: Any]) {
        paramsReply = params
        let _ = chatReplyApi.loadData()
    }
    
    /// 视频添加点赞
    func addVideoFavor(_ params: [String: Any]) {
        paramsFavor = params
        videoFavorApi.favorIndex = 0
        let _ = videoFavorApi.loadData()
    }
    /// 图集添加点赞
    func addPictureFavor(_ params: [String: Any]) {
        paramsFavor = params
        videoFavorApi.favorIndex = 1
        let _ = videoFavorApi.loadData()
    }
    /// 楼凤信息添加点赞
    func addMsgFavor(_ params: [String: Any]) {
        paramsFavor = params
        videoFavorApi.favorIndex = 2
        let _ = videoFavorApi.loadData()
    }
    
    /// 用户通过手機號找回用户信息
    func findAcountBack(_ params: [String: Any]){
        paramsAcountBack = params
        let _ = acountBackApi.loadData()
    }
    
    /// 利用身份卡二维码找回
    func findAcountWithSort(_ params: [String: Any]){
        paramsSort = params
        let _ = sortFindApi.loadData()
    }

    /// 添加关注
    func loadAddFollowApi(_ params: [String: Any]) {
        paramsFollow = params
        let _ = userAddFollowApi.loadData()
    }
    
    /// 取消关注
    func loadCancleFollowApi(_ params: [String: Any]) {
        paramsFollow = params
        let _ = userCancleFollowApi.loadData()
    }
    /// 兌換Vip
    func exchangeVip(_ params: [String: Any]) {
        paramsExchange = params
        let _ = convertApi.loadData()
    }
    /// 兌換卷详情
    func exchangeInfo(_ params: [String: Any]) {
        paramsExchange = params
        let _ = convertInfoApi.loadData()
    }
    
    ///推广交流
    func inviteLinkInfo(_ params: [String : Any]?) {
        paramsAddGroup = params
        let _ = inviteLinkApi.loadData()
    }
    ///推广交流
    func inviteLinkInfo(params: [String : Any]? ,
                        succeedHandler: @escaping ([AddGroupLinkModel]) -> (),
                        failHandler: @escaping (_ failMessage: String) -> ())
    {
        paramsAddGroup = params
        addGroupLinkSuccessHandler = succeedHandler
        addGroupLinkFailureHandelr = failHandler
        let _ = inviteLinkApi.loadData()
    }
    
    /// 金币购买视频
    func coinsBuyVideo(params: [String : Any]? ,
                       succeedHandler: @escaping (String) -> (),
                       failHandler: @escaping (_ failMessage: String) -> ())
    {
        paramsCoinsBuyVideo = params
        coinsBuyVideovFailedHandler = failHandler
        coinsBuyVideoSuccessHandler = succeedHandler
        _ = coinsBuyVideoApi.loadData()
    }
    
    /// 金币购买图集
    func coinsBuyImgs(params: [String : Any]? ,
                       succeedHandler: @escaping (String) -> (),
                       failHandler: @escaping (_ failMessage: String) -> ())
    {
        paramsCoinsBuyVideo = params
        coinsBuyVideovFailedHandler = failHandler
        coinsBuyVideoSuccessHandler = succeedHandler
        _ = coinsBuyPicApi.loadData()
    }
    /// 金币购买楼风
     func coinsBuyMsg(params: [String : Any]? ,
                          succeedHandler: @escaping (LFMsgModel) -> (),
                          failHandler: @escaping (_ failMessage: String) -> ())
    {
        paramsCoinsBuyVideo = params
        coinsBuyLFInfoFailedHandler = failHandler
        coinsBuyLFInfoSuccessHandler = succeedHandler
        _ = coinsBuyMsgApi.loadData()
    }
    
}

// MARK: - 收藏 , 历史观看 列表
extension UserInfoViewModel {
    
    /// 创建表编辑model
    private func createFakeModel(_ videoList: [VideoModel]) -> [CellEditModel] {
        var fakeModelList = [CellEditModel]()
        for video in videoList {
            let fakeModel = CellEditModel(videoModel: video, isSelected: false)
            fakeModelList.append(fakeModel)
        }
        return fakeModelList
    }
    
    /// 获取表编辑对象和Model
    func getCellEditModelList() -> [CellEditModel] {
        return cellEditModelList
    }
    
    func getCellEditModel(_ index: Int) -> CellEditModel {
        if cellEditModelList.count > index {
            return cellEditModelList[index]
        }
        return CellEditModel()
    }
}

// MARK: - 请求用户信息
extension UserInfoViewModel {
    /// 请求成功，给单利赋值
    func requestUserInfoSuccess(_ user: CLUserInfo) {
      //DLog("user ========== \(user)")
        UserModel.share().user = user
        UserDefaults.standard.set(user.code, forKey: UserDefaults.kUserInviteCode)
        loadUserInfoSuccessHandler?()
    }
    /// 找回用户成功
    func findAcountBackSuccess() {
        loadUserFindBackSuccessHandler?()
    }
    /// 请求成功，给单利赋值
    func requestUserOtherInfoSuccess(_ user: CLUserInfo) {
        loadUserOtherInfoSuccessHandler?(user)
    }
}

// MARK: - NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate
extension UserInfoViewModel: NicooAPIManagerCallbackDelegate, NicooAPIManagerParamSourceDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is UploadCrashLogApi || manager is UploadActionsLogApi {
            return paramsCrashLog
        }
        if manager is UserFadeBackApi {
            return paramsFadeBack
        }
        if manager is UserFavorAddApi  {
            return paramsFavor
        }
        if manager is AcountBackWithPhoneApi {
            return paramsAcountBack
        }
        if manager is RecallByCardApi {
            return paramsSort
        }
        if manager is FeedReplyApi  || manager is ChatMsgReplyApi {
            return paramsReply
        }
        if manager is UserAddFollowApi || manager is UserCancleFollowApi {
            return paramsFollow
        }
        if manager is VipCardExChangeApi || manager is VipConvertInfoApi {
            return paramsExchange
        }
        
        if manager is UserInviteLinkApi {
            return paramsAddGroup
        }
        if manager is UserInfoOtherApi {
            return paramsUserInfo
        }
        if manager is UseBuyVideoApi || manager is UseBuyImgsApi || manager is UseBuyMsgApi {
            return paramsCoinsBuyVideo
        }
        if manager is ShopUpdateInfoApi {
            return paramsUserInfo
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {
        if manager is UploadCrashLogApi {
            DLog("crash Log upload successed")
            let path = TBUncaughtExceptionHandler.shared.getdataPath()
            if FileManager.default.fileExists(atPath: path) {
                 DLog("exceptionLog path = \(path) ")
                 FileManager.default.remove(atPath: path)
            }
        }
        if manager is UserInfoApi {
            if let userInfo = manager.fetchJSONData(UserReformer()) as? CLUserInfo {
                requestUserInfoSuccess(userInfo)
            }
        }
        if manager is UserInfoOtherApi {
            if let userInfo = manager.fetchJSONData(UserReformer()) as? CLUserInfo {
                requestUserOtherInfoSuccess(userInfo)
            }
        }
        if manager is UserFadeBackApi {
            fadeBackSuccessHandler?()
        }
        
        if manager is AcountBackWithPhoneApi {
            findAcountBackSuccess()
        }
        if manager is RecallByCardApi {
            findAcountBackSuccess()
        }
        if manager is FeedReplyApi {
            if let model = manager.fetchJSONData(UserReformer()) as? MsgModel {
                replyApiSuccessHandler?(model)
            }
            
        }
        if manager is ChatMsgReplyApi {
            chatReplyApiSuccessHandler?()
        }
        if manager is UserAddFollowApi || manager is UserCancleFollowApi {
            followAddOrCancelSuccessHandler?((manager is UserAddFollowApi))
        }
        if manager is VipConvertInfoApi {
            if let coinsInfo = manager.fetchJSONData(UserReformer()) as? ExCoinsInfo {
                exchangeInfoApiSuccessHandler?(coinsInfo)
            }
        }
        if manager is VipCardExChangeApi {
            convertVipSuccessHandler?()
        }
        if manager is UseBuyVideoApi {
            if let mu = manager.fetchJSONData(UserReformer()) as? VideoMU {
                coinsBuyVideoSuccessHandler?(mu.u ?? "")
            }
        }
        if manager is UseBuyImgsApi {
            coinsBuyVideoSuccessHandler?("")
        }
        if manager is UseBuyMsgApi {
            if let model = manager.fetchJSONData(UserReformer()) as? LFMsgModel {
                coinsBuyLFInfoSuccessHandler?(model)
            }
        }
        if manager is UserInviteLinkApi {
            if let inviteLinks = manager.fetchJSONData(UserReformer()) as? [AddGroupLinkModel] {
                addGroupLinkSuccessHandler?(inviteLinks)
            }
        }
        if manager is UserSignApi {
            if let signModel = manager.fetchJSONData(UserReformer()) as? SignInfo {
                signSuccessHandler?(signModel)
            }
        }
        if manager is ShopUpdateInfoApi {
            loadUserFindBackSuccessHandler?()
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        if manager is UploadCrashLogApi {
            DLog("crash log upload Failed")
        }
        if manager is UserInfoApi {
            loadUserInfoFailHandler?()
        }

        if manager is UserFadeBackApi {
            fadeBackFailHandler?(manager.errorMessage)
        }
        if manager is ChatMsgReplyApi {
            chatReplyApiFailHandler?(manager.errorMessage)
        }
        if manager is AcountBackWithPhoneApi {
            loadUserFindBackFailHandler?(manager.errorMessage)
        }
        if manager is RecallByCardApi {
            loadUserFindBackFailHandler?(manager.errorMessage)
        }
        if manager is FeedReplyApi {
            replyApiFailHandler?(manager.errorMessage)
        }
        
        if manager is UserAddFollowApi || manager is UserCancleFollowApi {
            followOrCancelFailureHandler?(manager is UserAddFollowApi, manager.errorMessage)
        }
        if manager is VipConvertInfoApi {
            exchangeIndoApiFailHandler?(manager.errorMessage)
        }
        if manager is VipCardExChangeApi {
            convertVipFailHandler?(manager.errorMessage)
        }
        if manager is UseBuyVideoApi || manager is UseBuyImgsApi {
            coinsBuyVideovFailedHandler?(manager.errorMessage)
        }
        if manager is UseBuyMsgApi {
            coinsBuyLFInfoFailedHandler?(manager.errorMessage)
        }
        if manager is UserInviteLinkApi {
            addGroupLinkFailureHandelr?(manager.errorMessage)
        }
        if manager is UserSignApi {
            signFailedHandler?()
        }
        if manager is ShopUpdateInfoApi {
            loadUserFindBackFailHandler?(manager.errorMessage)
        }
    }
}
