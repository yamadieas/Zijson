
import UIKit

/// 用户单利
class UserModel: Codable {
    
    static private let shareModel: UserModel = UserModel()
    class func share() -> UserModel {
        return shareModel
    }
    var authInfo: DeviceAuthModel?
    var user: CLUserInfo?
    var signInfo: SignInfo?
    var token: String?
    var addGroupLinkModels: [AddGroupLinkModel]?
    var isPushLF: Bool = false
    /// 将要分享的图片链接
    var shareImageLink: String?
    /// 将要分享的文本
    var shareText: String?
    var searchHotTips: [SearchHotTips]?
    
    var uploadDiamond_limit: Int?
    
}
