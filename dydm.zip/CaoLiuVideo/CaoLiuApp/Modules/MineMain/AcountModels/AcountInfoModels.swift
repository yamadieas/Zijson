//
import Foundation

// MARK: - ----- 订单列表model
struct OrderListModel: Codable {
    var current_page: Int?
    var data:[OrderInfoModel]?
}

// MARK: - ----- 订单model
struct OrderInfoModel: Codable {
    var id: Int?
    var order_sn: String?  // 订单号
    var order_type: Int? //订单类型
    var vip_title: String?
    var pay_type: String?
    var vip_days: Int?
    var pay_time: String?
    var status: Int? // ding
    var created_at: String?
    var user_id: Int?
    var nikename: String?
    var mobile: String?
    var payment_id: Int?
    var payment_name: String?
    var order_amount: String?
    var real_amount: String?
    var trade_no: String?
    var is_user_proof: Int?
    var pay_url: String?
}

struct OrderDateModel: Codable {
    var date: String?
    var timezone_type: Int?
    var timezone: String?
}

struct VipCardListModel: Codable {
//    var current_page: Int?
    var package: [VipCardModel]?
    var ad: [AdHome]?
}

// MARK: - -----  VIP cards
class VipCardModel: Codable {
    var id: Int?
    var title: String?  // 卡片名
    var key: String? //卡片类型
    var remark: String?
    var mark: String?
    var day: String?
    var price: String?
    var buy_notice: String?
    var payment: [PayTypeModel]?
    var payTypeIndex: Int? = 0
    var selected: Bool? = false
    /// 钻石
    var coins: Int?
    var send_coins: Int?
    var intro: String?
    
    var countdown: CountDown?
    
    var daily_until: Int? // 使用天数
    var view_count_daily: Int? // 每天使用次数 ,0 表示无限次数 或者没有次数。取决于卡的类型
    var price_original: String? // 正常价格
    var price_current: String?  // 当前价格
    var level: Int? // 卡等级 1 - 6
    var sort: Int? // 排序号
    var status: Int? //
    var display: Int?
    var created_at: String?
    var updated_at: String?
    
    var color: String?
    var vip_card_authority: [VipAuthModel]?
}

//MARK: - 金币套餐
class CoinListModel: Codable {
    var coins: [CoinModel]?
    var coins_message: String?
}

//MARK: - 金币套餐
class CoinModel: Codable {
    var id: Int?
    var coins: String?
    var price: String?
    var intro: String?
    var buy_notice: String?
    var payment: [PayTypeModel]?
    var payTypeIndex: Int? = 0
}

//MARK: -金币明细
class CoinDetailModel: Codable {
    var _id: String?
    var user_id: String?
    var title: String?
    var coins: Int?
    var remark: String?
    var amount: String?
    var created_at: String?
    var updated_at: String?
}

class CoinDetailListModel: Codable {
    var current_page: Int?
    var data: [CoinDetailModel]?
    var total: Int?
}
class VipAuthModel: Codable {
    var title: String?
    var cover : String?
    var remark: String?
}

// MARK: - 用户邀請历史列表 model
struct InviteListModel: Codable {
    var current_page: Int?
    var data: [inviteUserModel]?
}

struct inviteUserModel: Codable {
    var code: String?
    var owner_user_id: Int?
    var name: String?
    var nick: String?
    var mobile: String?
    var use_user_id: Int?
    var created_at: String?
}


// MARK: - 订单详情
struct OrderDetailModel: Codable {
    var id: Int?
    var title: String?
    var remark: String?
    var price_original: String?
    var price_current: String?
}


enum Jump: String, Codable {
    case enable = "y"
    case disable = "n"
    var isJump: Bool {
        switch self {
        case .enable:
            return true
        case .disable:
            return false
        }
    }
}
// MARK: - 订单model
struct OrderAddModel: Codable {
    var link: String?
    var type: PaymentType?
    var jump: Jump?
    var order_info: OrderInfoMsg?
}

enum PaymentType: String, Codable {
    case wechatSDK = "wechat"
    case alipaySDK = "alipay"
    case url = "url"
}
// MARK: - 支付方式列表
class PayTypeModel: Codable {
    var id: String?
    var title: String?
    var name: String?
    var img: String?
    var is_sdk: Int?
    var selected: Bool? = false
}
struct OrderInfoMsg: Codable {
    var title: String?
    var pay_type: String?
    var order_sn: String?
    var created_at: String?
}

/// 消息会话列表
class MsgSessionModel: Codable {
    var feedback: MsgModel?
    var notice: MsgModel?
    var msg: [MsgModel]?
}

/// 聊天消息列表
class MsgLsModel: Codable {
    var current_page: Int?
    var data: [MsgModel]?
}
enum MsgType: Int, Codable {
    case text = 1
    case image = 2
    case QA = 3
}
enum ChatMsgType: String, Codable {
    case text = "text"
    case image = "image"
}
class MsgModel: Codable {
    
    /// 会话字段
    var rid: String?  //  0: 管理员回复。  其他： 用户發送的
    var uid: String?
    var id: Int?
    var content: String?
    var type: MsgType?   /// 1: 普通文本。2: 图片消息
    var avatar: String?
    
    
    var from_code: String?  //发送者 code
    var from_nick: String?
    var from_avatar: String?
    var to_code: String?   // 接受者 code
    var to_nick: String?
    var to_avatar: String?
    
    /// 公共字段
    var msg_type: ChatMsgType?
    var msg_content: String?
    var created_at: String?
    var time: String?
    var is_reply: Int?  /// is_reply = 0 有红点 1 - 没有红点
    
    /// 私信会话
    var user_code: String?
    var user_nick: String?
    var user_avatar: String?
    var other_code: String?
    var talk_id: String?
    var is_my: Int?
    
}
class Q_AItemModel: Codable {
    var id: Int?
    var title: String?
    var content: String?
}

struct ExCoinsInfo: Codable {
    var id: Int?
    var code: String?
    var coupon: Int?
    var status: Int?
    var title: String?
    var remark: String?
    var is_exchange: Int?
    var day: Int?
    var limit: Int?
    var type: Int?
    var created_at: String?
    var updated_at: String?
}

class VideoMU: Codable {
    var u: String?
}

class FollowListModel: Codable {
    var list: [CLUserInfo]?
}
/// 关系
///
/// - notRelate: 无关系
/// - myFollow: 我关注他
/// - follwMe: 我的粉絲
/// - followEachOther: 相互关注
/// - isMySelf: 是我自己
enum RelationShip: Int, Codable {
    case notRelate = 0
    case myFollow = 1
    case follwMe = 2
    case followEachOther = 3
    case isMySelf = 4
}

///是否关注该视频的作者
enum FocusVideoUploader: Int, Codable {
    case notFocus = 0 //未关注
    case focus = 1 //已关注
}

///关注狀態
struct FollowStatu: Codable {
    var status: Int?
}

/////关注和取消关注的模型
struct FollowOrCancelModel: Codable {
    var uid: Int?
    var flag: RelationShip?
}

struct AddGroupLinkModel: Codable {
    var id: Int?
    var title: String?
    var url: String?
    var icon: String?
    var sort: Int?
    var created_at: String?
    var updated_at: String?
}

//MARK: - 签到
class SignInfo: Codable {
    var is_first: Int?
    var sign_info: SignShort?
    var sign_ini: SignAlertInfo?
    var user_info: CLUserInfo?
}

class SignShort: Codable {
    var date: String?
    var sign: Int?
    var coins: String?
}

class SignAlertInfo: Codable {
    var maxday: Int?
    var sign_help: String?
    var ini: [SignAlerPic]?
}

class SignAlerPic: Codable {
    var day: Int?
    var cover: String?
    var coins: Int?
}

class CreatorInfoPage: Codable {
    var top: [AdHome]?
    var data: CreatorInfo?
    var bottom: [AdHome]?
}

class CreatorInfo: Codable {
    var type: Int?
    var diamond: Int? // 钻石
    var diamond_limit: Int?
    var diamond_bill: Int?
    var upload_limit: Int?  //最多上传
    var upload_count: Int? // 今日上传
    var play: Int?
    var fans: Int?
    var like: Int?
    var time: String?
    var long_video: Int?
    var short_video: Int?
}
