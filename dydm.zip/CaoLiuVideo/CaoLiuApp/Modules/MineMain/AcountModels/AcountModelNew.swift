

import UIKit
import Foundation

class CLUserInfo: Codable {
    var service_link: [CLServiceLink]?
    var nick: String?
    var code: String?
    var is_vip: String?
    var fans: Int?
    var flow: Int?
    var like: StrInt?
    var gender: Int?
    var avatar: String?
    var invite: Int?
    var play: StrInt?
    var video_count: StrInt?
    var channel: String?
    
    var video_long_count: Int?
    var video_short_count: Int?
    var like_short_count: Int?
    var like_long_count: Int?
    var like_tag_count: Int?
    var buy_short_count: Int?
    var buy_long_count: Int?
    var like_image_count: Int?
    var like_floor_count: Int?
    var floor_post_count: Int?
    var buy_image_count: Int?
    var buy_floor_count: Int?
    
    var is_attention: Int?
    var bind_mobile: String?
    var has_parent: String?
    var play_num_notice: String?
    var vip_text: String?
    var coins_text: String?
    var vip_expired_text: String?
    var bill: String?
    var is_user_auth: Int?
    var balance: String?
    var coins: Int?
    var is_new_msg: Int?
    var is_new_order: Int?
    var rank_type: Int?
    var account_qrcode_content: String?
    var intro: String?
    var cover: String?
    
    /// 上传认证
    var upload_auth: String?
    /// 楼凤认证
    var is_shop_auth: Int?
    
    var countdown_time: Int?
    var countdown_intro: String?
    var countdown_link: String?
    var countdown_display: Int?
}

class CLServiceLink: Codable {
    var created_at: String?
    var id: Int?
    var title: String?
    var sort: Int?
    var url: String?
    var icon: String?
    var updated_at: String?
}
