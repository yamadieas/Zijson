//
//  DownloadImageOperation.swift
//  SwiftAdView
//
//  Created by shiliu on 27/3/2021.
//  Copyright © 2021 AnakinChen Network Technology. All rights reserved.
//

import UIKit
import Alamofire

class DownloadImageOperation: Operation {
    //下载图像的url
    private var URLString: String?
    //回调block
    private var finishBlock: ((_ image: Data) -> Void)?
    
    class func downloadImage(urlString: String, finish: @escaping ((_ image: Data) -> Void)) -> DownloadImageOperation {
        let op = DownloadImageOperation()
        op.URLString = urlString
        op.finishBlock = finish
        //print("网络下载")
        return op
    }
    
    override func main() {
        autoreleasepool { () -> () in
            assert(URLString != nil, "图像的地址不能为空")
            assert(finishBlock != nil, "必须传入回调")
            guard let url = URL(string: URLString!) else { return }
            /// 图片下载
            Alamofire.SessionManager.default.request(URLString!, method: .get, parameters: nil, encoding: URLEncoding.default, headers: ["referer":UserModel.share().authInfo?.config?.sys?.request_referer ?? "http://www.qq.com"]).responseData { (response) in
                if let _ = response.result.error {
                    DLog("图片下载失败,请检查您的url地址是否正确")
                    return
                } else {
                    let statusCode = (response.response?.statusCode)! //example : 200
                    if statusCode == 200 {
                        if let dataImg = response.data, !dataImg.isEmpty {
                            if url.absoluteString.hasSuffix(".ceb") { // 表示图片加过密
                                if let data = dataImg as NSData? {
                                    if let dataDec = data.aes128DecryptWidthKey(ConstValue.kImageDataDecryptKey) as Data?  {
                                        //将图片保存到沙盒目录
                                        try! dataDec.write(to: DownloadImageExtensions.imageFilesPath(url), options: .atomic)
                                        //判断操作是否被取消
                                        if self.isCancelled {
                                            //print("操作被取消", url)
                                            return
                                        }
                                        //主线程回调
                                        OperationQueue.main.addOperation {
                                            if self.finishBlock != nil {
                                                self.finishBlock!(dataDec)
                                            }
                                        }
                                    } else {
                                        DLog("图片解密失败")
                                    }
                                }
                            } else { // 未加密图片， 直接走正常流程
                                //将图片保存到沙盒目录
                                try! dataImg.write(to: DownloadImageExtensions.imageFilesPath(url), options: .atomic)
                                //判断操作是否被取消
                                if self.isCancelled {
                                    //print("操作被取消", url)
                                    return
                                }
                                //主线程回调
                                OperationQueue.main.addOperation {
                                    if self.finishBlock != nil {
                                        self.finishBlock!(dataImg)
                                    }
                                }
                            }
                        } else {
                            DLog("图片缓存失败,请检查您的url地址是否正确")
                        }
                    }
                }
            }
        }
    }
}
