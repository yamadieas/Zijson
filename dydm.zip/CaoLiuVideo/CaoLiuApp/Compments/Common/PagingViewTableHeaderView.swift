//
//  PagingViewTableHeaderView.swift
//  JXPagingView
//
//  Created by jiaxin on 2018/5/28.
//  Copyright © 2018年 jiaxin. All rights reserved.
//

import UIKit

class PagingViewTableHeaderView: UIView {
   private lazy var userInfoHeader: AcountNewHeaderView = {
        if let header = Bundle.main.loadNibNamed("AcountNewHeaderView", owner: nil, options: nil)?[0] as? AcountNewHeaderView {
            header.frame = CGRect(x: 0, y: 0, width: screenWidth, height: 150)
            return header
        }
        return AcountNewHeaderView()
    }()
    private let userItemView: AcountNewItemView = {
        let itemView = AcountNewItemView(frame: CGRect.zero)
        return itemView
    }()

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clear
 
        addSubview(userInfoHeader)
        addSubview(userItemView)
        layoutHeaderSubviews()
    }

     func layoutHeaderSubviews() {
          userInfoHeader.snp.makeConstraints { (make) in
              make.leading.trailing.top.equalToSuperview()
            make.height.equalTo(150 + ConstValue.kStatusBarHeight)
          }
          userItemView.snp.makeConstraints { (make) in
              make.leading.trailing.equalToSuperview()
              make.top.equalTo(userInfoHeader.snp.bottom)
              make.bottom.equalToSuperview()
          }
      }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

}
