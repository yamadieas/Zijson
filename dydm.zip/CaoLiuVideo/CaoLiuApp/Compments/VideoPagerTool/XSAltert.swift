//
//  XSAltert.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/24.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import MBProgressHUD

class XSAlert: NSObject {
    enum AlertType {
        case success
        case info
        case error
        case warning
        case nono
        case text
    }
    
    class func show(type: AlertType, text: String) {
        if let window = UIApplication.shared.delegate?.window {
            var image = UIImage(named: "Alert_success")
            switch type {
            case .success:
                image = UIImage(named: "Alert_success")
            case .info:
                image = UIImage(named: "Alert_info")
            case .error:
                image = UIImage(named: "Alert_error")
            case .warning:
                image = UIImage(named: "Alert_warning")
            case .nono:
                image = UIImage(named: "Alert_nono")
            case .text:
                image = UIImage()
            }
            let hud = MBProgressHUD.showAdded(to: window! , animated: true)
            hud.backgroundColor = UIColor.lightGray.withAlphaComponent(0.05)
            hud.mode = .customView
            hud.customView = UIImageView(image:image)
            hud.label.text = text
            hud.label.font = UIFont.systemFont(ofSize: 14)
            hud.hide(animated: true, afterDelay: 1.0)
        }
    }
}

open class NearSystemAlert: UIView {
    
    static private let kAlertViewWidth: CGFloat = 269.5
    static private let kAlertViewHeight: CGFloat = 125
    
    /// 存放按钮title
    public var itemTitles: [String]?
    public var itemButtonClick:((_ title: String) ->Void)?
    /// 是否允许当前视频集在4G网下播放
    public var allowedWWanPlayInCurrentVideoGroups: Bool = false
    let msgLable: ActiveLabel = {
        let lable = ActiveLabel()
        lable.numberOfLines = 0
        lable.font = UIFont.systemFont(ofSize: 13)
        lable.textAlignment = .center
        lable.textColor = UIColor(white: 0.9, alpha: 1)
        return lable
    }()
    let redMsgLable: UILabel = {
        let lable = UILabel()
        lable.numberOfLines = 1
        lable.textColor = .white
        lable.font = UIFont.boldSystemFont(ofSize: 14)
        lable.textAlignment = .center
        return lable
    }()
    private let alertView: UIView = {
        let alertView = UIView()
        alertView.backgroundColor = ConstValue.kCoverBgColor
        alertView.layer.cornerRadius = 15
        alertView.layer.masksToBounds = true
        return alertView
    }()
    
    deinit {
        DLog("弹框被释放")
    }
    
    public init(frame: CGRect, itemButtonTitles: [String]?, message: String, redMsg: String) {
        super.init(frame: frame)
        
        self.backgroundColor = UIColor(white: 0, alpha: 0.6)
        itemTitles = itemButtonTitles
        redMsgLable.text = redMsg
        msgLable.attributedText = TextSpaceManager.getAttributeStringWithString(message, lineSpace: 5, .center)
        msgLable.customize { (label) in
            label.numberOfLines = 0
            label.lineSpacing = 5
            label.textAlignment = .center
            label.URLColor = UIColor.systemRed
            label.URLSelectedColor = .lightGray
            label.handleURLTap { (url) in
                if #available(iOS 10, *) {
                    UIApplication.shared.open(url, options: [:],
                                              completionHandler: {
                                                (success) in
                    })
                } else {
                    UIApplication.shared.openURL(url)
                }
            }
        }
        alertView.addSubview(msgLable)
        alertView.addSubview(redMsgLable)
        addSubview(alertView)
        layoutPageSubviews()
        if redMsg.isEmpty {
            redMsgLable.snp.updateConstraints { (make) in
                make.top.equalTo(16)
                make.height.equalTo(0)
            }
        }
        loadButtons()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
}

// MARK: - Public funcs in the component

public extension NearSystemAlert {
    
    /// 展示
    func showInWindow() {
        if let window = UIApplication.shared.keyWindow {
            var hasAdd: Bool = false
            window.subviews.forEach { (view) in
                if view is NearSystemAlert  {
                    hasAdd = true
                }
            }
            if !hasAdd {
                window.addSubview(self)
                self.snp.makeConstraints { (make) in
                    make.edges.equalToSuperview()
                }
            }
        }
    }
    
    /// 隐藏
    func hideFromWindow() {
        if self.superview != nil {
            self.removeFromSuperview()
        }
    }
    
}

// MARK: - Private funcs

private extension NearSystemAlert {
    
    // MARK: - User Actions
    
    @objc func menuButtonClick(_ sender: UIButton) {
        guard let _ = sender.titleLabel?.text else {
            return
        }
        guard let titles = itemTitles, titles.count > 0 else {
            return
        }
        itemButtonClick?(sender.titleLabel!.text!)
        self.removeFromSuperview()
    }
    
    // MARK : - Private funcs
    func createButton() -> UIButton {
        let button = UIButton(type: .custom)
        button.bordercolor = UIColor(red: 48.0/255.0, green: 52.0/255.0, blue: 68.0/255.0, alpha: 1)
        button.layer.borderWidth = 0.2
        return button
    }
    
    func loadButtons() {
        guard let titles = itemTitles, titles.count > 0 else {
            return
        }
        let buttonWidth = NearSystemAlert.kAlertViewWidth / CGFloat(titles.count)
        for i in 0 ..< titles.count {
            let title = titles[i]
            let button = createButton()
            button.setTitle(title, for: .normal)
            button.titleLabel?.font = UIFont.boldSystemFont(ofSize: 14)
            button.setTitleColor(i == 0 ? .lightGray : .white, for: .normal)
            button.setTitleColor(UIColor.lightGray, for: .highlighted)
            button.addTarget(self, action: #selector(NearSystemAlert.menuButtonClick(_:)), for: .touchUpInside)
            button.tag = i
            alertView.addSubview(button)
            button.snp.makeConstraints { (make) in
                make.width.equalTo(buttonWidth)
                make.bottom.equalTo(0)
                make.height.equalTo(48)
                make.leading.equalTo(buttonWidth * CGFloat(i))
            }
        }
    }
    
}

// MARK: - Layout

private extension NearSystemAlert {
    
    func layoutPageSubviews() {
        layoutAlertView()
        layoutMessageLabel()
    }
    
    func layoutAlertView() {
        alertView.snp.makeConstraints { (make) in
            make.center.equalToSuperview()
            make.width.equalTo(269.5)
        }
    }
    
    func layoutMessageLabel() {
        redMsgLable.snp.makeConstraints { (make) in
            make.leading.equalTo(15)
            make.trailing.equalTo(-12)
            make.top.equalTo(24)
            make.height.equalTo(20)
        }
        msgLable.snp.makeConstraints { (make) in
            make.leading.equalTo(20)
            make.trailing.equalTo(-12)
            make.top.equalTo(redMsgLable.snp.bottom).offset(12)
            make.bottom.equalTo(-75)
        }
    }
}


extension UIViewController {
    //MARK:- 显示红黑标题的弹框
    func showNearDialog(redTitle: String, message: String, okTitle: String?, cancelTitle: String?, okHandler: (() -> Void)?, cancelHandler: (() -> Void)?) {
        var titles = [String]()
        if let canclet = cancelTitle, !canclet.isEmpty {
            titles.append(canclet)
        }
        if let okt = okTitle, !okt.isEmpty {
            titles.append(okt)
        }
        let alert = NearSystemAlert.init(frame: view.bounds, itemButtonTitles: titles, message: message, redMsg: redTitle)
        alert.backgroundColor = UIColor(white: 0, alpha: 0.6)
        alert.showInWindow()
        alert.itemButtonClick = { title in
            if title == cancelTitle {
                cancelHandler?()
            } else if title == okTitle {
                okHandler?()
            }
        }
    }
}
