//
//  UIView+Extention.swift
//  CaoLiuApp
//
//  Created by mac on 2019/10/12.
//  Copyright © 2019 AnakinChen Network Technology. All rights reserved.
//

import UIKit

extension UIView {
    
    @IBInspectable var borderRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.cornerRadius = newValue
            layer.masksToBounds = newValue > 0
        }
    }
    
    @IBInspectable var borderWidth: CGFloat {
        get {
            return self.layer.borderWidth
        }
        set {
            self.layer.borderWidth = newValue
        }
    }
    @IBInspectable var bordercolor: UIColor {
        get {
            return UIColor(cgColor: self.layer.borderColor ?? UIColor.clear.cgColor)
        }
        set {
            self.layer.borderColor = newValue.cgColor
        }
    }
    
    @IBInspectable var shadowColor: UIColor {
        get {
            return UIColor(cgColor: layer.shadowColor ?? UIColor.clear.cgColor)
        }
        set {
            layer.shadowColor = newValue.cgColor
        }
    }
    
    @IBInspectable var shadowOpacity: Float {
        get {
            return layer.shadowOpacity
        }
        set {
            layer.shadowOpacity = newValue
        }
    }
    
    @IBInspectable var shadowRadius: CGFloat {
        get {
            return layer.shadowRadius
        }
        set {
            layer.shadowRadius = newValue
        }
    }
    @IBInspectable var maskToBounds: Bool {
        get {
            return layer.masksToBounds
        }
        set {
            layer.masksToBounds = newValue
        }
    }
    
    func toImage() -> UIImage? {
        // UIGraphicsBeginImageContextWithOptions(size: CGSize, opaque: Bool, scale: CGFloat)
        // 第2引数: true = 背景不透明, false = 背景透明
        // 第3引数: Retinaに対応するために必要
        UIGraphicsBeginImageContextWithOptions(self.frame.size, false, 0.0)
        guard let context = UIGraphicsGetCurrentContext() else {
            return nil
        }
        self.layer.render(in: context)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()
        return image
    }
    
    ///部分圆角
    func corner(byRoundingCorners corners: UIRectCorner, radii: CGFloat) {
        let maskPath = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: CGSize(width: radii, height: radii))
        let maskLayer = CAShapeLayer()
        maskLayer.frame = self.bounds
        maskLayer.path = maskPath.cgPath
        self.layer.mask = maskLayer
    }
    
    /// 添加阴影
    func addShadow(radius: CGFloat,
                   opacity: Float,
                   _ color: UIColor? = UIColor.lightGray)
    {
        self.layer.shadowColor = color?.cgColor
        self.layer.shadowOffset = CGSize()
        self.layer.shadowOpacity = opacity
        self.layer.shadowRadius = radius
        self.clipsToBounds = false
        self.layer.masksToBounds = false
    }
    /// 请正确设置bounds后调用， position ：（1，2，3，4）<-> (上,左,下,右) 可随机组合， 0 -> 4边都加
    func addShadow(opacity: Float,
                   position: Int,
                   pathWidth: CGFloat,
                   _ color:  UIColor? = .lightGray)
    {
        self.layer.shadowColor = color?.cgColor
        self.layer.shadowOffset = CGSize()
        self.layer.shadowOpacity = opacity
        self.layer.shadowRadius = pathWidth
        self.layer.masksToBounds = false
        self.clipsToBounds = false
        var shadowRect = CGRect.zero
        let orX: CGFloat = 0
        let orY: CGFloat = 0
        let size_w = self.bounds.width
        let size_h = self.bounds.height
        if position == 0 {
            shadowRect = CGRect(x: orX-pathWidth/2, y: orY-pathWidth/2, width: size_w+pathWidth, height: size_h+pathWidth)
        } else if position == 1 {
            shadowRect = CGRect(x: orX, y: orY-pathWidth/2, width: size_w, height: pathWidth)
        } else if position == 2 {
            shadowRect = CGRect(x: orX-pathWidth/2, y: orY, width: pathWidth, height: size_h)
        } else if position == 3 {
            shadowRect = CGRect(x: orY, y: size_h-pathWidth/2, width: size_w, height: pathWidth)
        } else if position == 4 {
            shadowRect = CGRect(x: size_w-pathWidth/2, y: orY, width: pathWidth, height: size_h)
        } else if position == 12 || position == 21 {
            shadowRect = CGRect(x: orX-pathWidth/2, y: orY-pathWidth/2, width: size_w-2*pathWidth, height: size_h-2*pathWidth)
        } else if position == 13 || position == 31 {
            shadowRect = CGRect(x: orX+2*pathWidth, y: orY-pathWidth/2, width: size_w-4*pathWidth, height: size_h+pathWidth)
        } else if position == 14 || position == 41 {
            shadowRect = CGRect(x: 2*pathWidth, y: orY-pathWidth/2, width: size_w-1.5*pathWidth, height: size_h-2*pathWidth)
        } else if position == 23 || position == 32 {
            shadowRect = CGRect(x: orX-pathWidth/2, y: orY+2*pathWidth, width: size_w-2*pathWidth, height: size_h-1.5*pathWidth)
        } else if position == 24 || position == 42 {
            shadowRect = CGRect(x: orX-pathWidth/2, y: 2*pathWidth, width: size_w+pathWidth, height: size_h-4*pathWidth)
        } else if position == 34 || position == 43 {
            shadowRect = CGRect(x: 2*pathWidth, y: 2*pathWidth, width: size_w-1.5*pathWidth, height: size_h-1.5*pathWidth)
        } else if position == 123 || position == 213 || position == 321 || position == 312 || position == 132 || position == 231 {
            shadowRect = CGRect(x: orX-pathWidth/2, y: orY-pathWidth/2, width: size_w-2*pathWidth, height: size_h+pathWidth)
        } else if position == 234 || position == 243 || position == 324 || position == 342 || position == 432 || position == 423 {
            shadowRect = CGRect(x: orX-pathWidth/2, y: orY+2*pathWidth, width: size_w+pathWidth, height: size_h-2*pathWidth)
        } else if position == 134 || position == 143 || position == 314 || position == 341 || position == 431 || position == 413 {
            shadowRect = CGRect(x: orX+2*pathWidth, y: orY-pathWidth/2, width: size_w-2*pathWidth, height: size_h+pathWidth)
        } else if position == 124 || position == 142 || position == 214 || position == 241 || position == 421 || position == 412 {
            shadowRect = CGRect(x: orX-pathWidth/2, y: orY-pathWidth/2, width: size_w+pathWidth, height: size_h-2*pathWidth)
        }
        let bazier = UIBezierPath.init(rect: shadowRect)
        self.layer.shadowPath = bazier.cgPath
    }
}
