//
//  UIViewController+PresentHud.h
//  PlatformKit
//
//  Created by mac on 2020/5/16.
//  Copyright © 2020 TouchingApp. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UIViewController (PresentHud)

@end


