

import UIKit

class AdvertiseController: CLBaseViewController {
    
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }
    
    var adUrl = ""
    var adClickOrShowToEndHandler:(() -> Void)?

    let viewModel = VideoViewModel()
    
    deinit {
        DLog("AdvertiseController ---- release")
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = ConstValue.kVcViewColor
        addAdvertisement(adUrl)
    }
    
    /// 启动广告
    func addAdvertisement(_ url: String) {
        let advertisement = AdvertisementView(frame: nil, duration: 5, delay: 0, adUrl: url, isHiddenSkipBtn: false, isIgnoreCache: false, placeholderImage: UIImage(named: "playCellBg"), completion: { [weak self] (isClickDetail) in
            DLog("广告展示完毕=\(isClickDetail)")
            self?.setVideoRootVC()
           
        }) { [weak self]  (isClickDetail) in
            if !isClickDetail {
                DLog("点击了跳过广告 =\(isClickDetail)")
                self?.setVideoRootVC()
            }
        }
        advertisement.advertiseDetailClickHandler = { [weak self] in
             DLog("点击了广告页面 ")
            self?.clickAdInfo()
        }
        advertisement.backgroundColor = UIColor.clear
        view.addSubview(advertisement)
    }
    
  func outSideLink(_ url: String) {
        guard let adHref = URL(string: url) else { return }
         DLog("主流程不变， 跳到外部广告链接 == \(adHref)")
        if #available(iOS 10, *) {
            UIApplication.shared.open(adHref, options: [:],
                                      completionHandler: {
                                        (success) in
            })
        } else {
            UIApplication.shared.openURL(adHref)
        }
    }
    func innerLink(_ url: String) {
        guard let adHref = URL(string: url) else { return }
        let aavc = AAViewController(url: adHref)
        aavc.backLaunchAdViewController = {
            self.setVideoRootVC()
        }
        navigationController?.pushViewController(aavc, animated: false)
    }
    
    func clickAdInfo() {
        if let herf = UserDefaults.standard.string(forKey: UserDefaults.kAdLinkUrl), !herf.isEmpty {
            DLog("herf == \(herf)")
            goLink(herf)
        }
    }
    
    func goLink(_ herf: String) {
        AppInfo.share().uploadUserAction([UploadActionsLogApi.kEvent: UploadActionsLogApi.kAD, UploadActionsLogApi.kEvent_data : "startup||\(herf)"])
        if herf.contains("url://") {
            let urlStrs = herf.components(separatedBy: "url://")
            DLog("herf == \(urlStrs)")
            if urlStrs.count > 1 {
                outSideLink(urlStrs[1])
                setVideoRootVC()
            }
        } else if herf.contains("tag://") {
            let urlStrs = herf.components(separatedBy: "://")
            if urlStrs.count > 1 {
                if let tag_id = Int(urlStrs[1]) {
                    var model = SearchHotTips()
                    model.id = tag_id
                    model.type_id = tag_id
                    if let vcs = navigationController?.viewControllers {
                        let allPlayVcs = vcs.filter { (vc) -> Bool in
                            return vc.isKind(of: TypeVideosController.self)
                        }
                        if allPlayVcs.count > 0 {
                            navigationController?.viewControllers.removeAll(where: { (detailVc) -> Bool in
                                return detailVc.isKind(of: TypeVideosController.self)
                            })
                        }
                        let detail = TypeVideosController()
                        detail.keyMode = model
                        detail.backLaunchAdViewController = {
                            self.setVideoRootVC()
                        }
                        navigationController?.pushViewController(detail, animated: true)
                    }
                }
            }
        } else if herf.contains("type://") {
            let urlStrs = herf.components(separatedBy: "://")
            if urlStrs.count > 1 {
                if let type_id = Int(urlStrs[1]) {
                    let model = ModuleDetailModel()
                    model.id = type_id
                    if let vcs = navigationController?.viewControllers {
                        let allPlayVcs = vcs.filter { (vc) -> Bool in
                            return vc.isKind(of: ModuleMoreController.self)
                        }
                        if allPlayVcs.count > 0 {
                            navigationController?.viewControllers.removeAll(where: { (vc) -> Bool in
                                return vc.isKind(of: ModuleMoreController.self)
                            })
                        }
                        let detail = ModuleMoreController()
                        detail.detailModel = model
                        detail.backLaunchAdViewController = {
                            self.setVideoRootVC()
                        }
                        navigationController?.pushViewController(detail, animated: true)
                    }
                }
            }
        } else if herf.contains("user://") {
            let urlStrs = herf.components(separatedBy: "://")
            if urlStrs.count > 1 {
                let userCode = urlStrs[1]
                if !userCode.isEmpty {
                    let v = CLUserInfo()
                    v.code = userCode
                    let userPage = UserMCenterController()
                    userPage.userNew = v
                    userPage.userCode = userCode
                    userPage.backLaunchAdViewController = {
                        self.setVideoRootVC()
                    }
                    navigationController?.pushViewController(userPage, animated: true)
                }
            }
        } else if herf.contains("video://") {
            let urlStrs = herf.components(separatedBy: "://")
            if urlStrs.count > 1 {
                if let videoId = Int(urlStrs[1]) {
                    viewModel.loadVideoAuthData(params: [VideoAuthApi.kVideo_id: videoId], succeedHandler: { [weak self] (video) in
                        self?.goVideoPlayVc(video)
                    }) { (error) in
                        XSAlert.show(type: .error, text: error)
                    }
                }
            }
        } else if herf.contains("buycoins://") {
            let vip = CoinsCardsController()
            vip.backLaunchAdViewController = {
                self.setVideoRootVC()
            }
            navigationController?.pushViewController(vip, animated: true)
        } else if herf.contains("buyvip://") {
            let vip = VipCardsController()
            vip.backLaunchAdViewController = {
                self.setVideoRootVC()
            }
            navigationController?.pushViewController(vip, animated: true)
        } else if herf.contains("urlself://") {
            let urlStrs = herf.components(separatedBy: "urlself://")
            DLog("herf == \(urlStrs)")
            if urlStrs.count > 1 {
                innerLink(urlStrs[1])
            }
        } else if herf.contains("game://") {
            let game = GameListControlller()
            game.position = .OnePage
            navigationController?.pushViewController(game, animated: false)
        }
    }
    
    func goVideoPlayVc(_ model: VideoNew) {
        if model.is_long == 1 {
            let detail = VideoDetailController()
            detail.video = model
            detail.backLaunchAdViewController = {
                 self.setVideoRootVC()
            }
            navigationController?.pushViewController(detail, animated: true)
        } else {
            let controller = PresentPlayController()
            controller.videos = [model]
            controller.currentIndex = 0
            controller.currentPlayIndex = 0
            navigationController?.pushViewController(controller, animated: false)
            controller.backLaunchAdViewController = {
                self.setVideoRootVC()
            }
        }
    }

}
