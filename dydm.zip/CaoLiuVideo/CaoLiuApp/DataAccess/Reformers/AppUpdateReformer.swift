//
//  AppUpdateReformer.swift
//  XSVideo
//
//  Created by pro5 on 2018/12/28.
//  Copyright © 2018年 pro5. All rights reserved.
//

import Foundation
import NicooNetwork

/// App版本更新信息解析
class AppUpdateReformer: NSObject {
    
    /// AppVersionInfo    Api
    private func reformUpdateInfoDatas(_ data: Data?) -> Any? {
        if let info = try? decode(response: data, of: ObjectResponse<AppVersionInfo>.self)?.data {
            return info
        }
        return nil
    }
}

// MARK: - NicooAPIManagerDataReformProtocol
extension AppUpdateReformer: NicooAPIManagerDataReformProtocol {
    
    func manager(_ manager: NicooBaseAPIManager, reformData jsonData: Data?) -> Any? {
        if manager is AppUpdateApi {
            return reformUpdateInfoDatas(jsonData)
        }
        return nil
    }
}
