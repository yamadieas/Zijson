
import Foundation
import NicooNetwork

/// 设备号注册
class DeviceRegisterApi: XSVideoBaseAPI {
    
    static let kDevice_code = "device_no"
    static let kDevice_type = "device_type"
    static let kInviteCode = "code"
    static let kToken = "token"
    static let kChannel = "channel"     /// 平台
    static let kDefaultChannel = "share"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/auth/login/device"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
       return super.reform(params)
    }
}
/// 刷新token
class RefreshTokenApi: XSVideoBaseAPI {
    
    static let kDevice_code = "device_no"
    static let kDevice_type = "device_type"
    static let kOldToken = "old_token"

    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/auth/refresh/token"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform([RefreshTokenApi.kDevice_code: UIDevice.current.getIdfv(), RefreshTokenApi.kDevice_type : "I",RefreshTokenApi.kOldToken : UserDefaults.standard.value(forKey: UserDefaults.kUserToken) ?? ""])
    }
}

//MARK:- 用户检查ip
class UserCheckIpApi: XSVideoBaseAPI {
    
    override func methodName() -> String {
        return "pass"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK:- 用户手機號注册/綁定
class UserRegisterApi: XSVideoBaseAPI {
    
    static let kMobile = "phone"
    static let kCode = "code"
    
    var isGameBind: Bool = false
    
    override func methodName() -> String {
        return isGameBind ? "app/api/game/bind/send" : "app/api/user/bindphone"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK:- 用户手機號 解绑
class UserUntieApi: XSVideoBaseAPI {
    
    static let kMobile = "phone"
    static let kCode = "code"
    
    override func methodName() -> String {
        return "app/api/user/unbindphone"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}


/// 發送验证码
class SendCodeApi: XSVideoBaseAPI {
    
    static let kMobile = "phone"
    static let kImgCode = "img_code"
    
    
    var isGameCode: Bool = false
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return isGameCode ? "app/api/game/image/code/check" : "app/api/sendmsg"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
    
}

/// 图片验证码
class ImageCodeApi: XSVideoBaseAPI {
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/game/image/code/create"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
    
}

