

import UIKit
import NicooNetwork
class UploadCrashLogApi: XSVideoBaseAPI  {
    static let kUa = "ua"
    static let kError_message = "message"
    static let kDevice_code = "device_no"
    static let kVersion = "version"
    static let kPlatform = "device_type"
    static let kCode  = "user_id"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/crash/log"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String : Any]?) -> [String : Any]? {
        return super.reform(params)
    }
}


class UploadActionsLogApi: XSVideoBaseAPI  {

    static let kEvent = "event"
    static let kEvent_data = "event_data"  // 广告传（位置||协议  视频播放失败传（视频编号|链接）
    
    static let kAD = "ad" // 广告点击ad
    static let kSave_account = "save_account" // 保存账号凭证save_account
    static let kSave_share = "save_share"   // 保存分享凭证save_share
    static let kShare = "share"          // 复制分享链接或者发起分享share
    static let kPlay_error = "play_error"  // 视频播放错误play_error
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/report/action"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String : Any]?) -> [String : Any]? {
        return super.reform(params)
    }
}
