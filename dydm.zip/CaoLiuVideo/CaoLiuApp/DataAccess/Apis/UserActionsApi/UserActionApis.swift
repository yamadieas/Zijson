
import Foundation
import NicooNetwork

//MARK: - 用户点赞
class UserFavorAddApi: XSVideoBaseAPI {
    
    static let kVideo_id = "video_id"
    static let kIslong = "is_long"
    static let kPicture_id = "id"
    static let kMsg_Id = "shop_id"

    /// 0 : 视频 1: 图集 2: 楼风  --- 默认视频点赞
    var favorIndex: Int = 0

    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        if favorIndex == 0 {
            return "app/api/video/like"
        } else if favorIndex == 1 {
            return "app/api/photos/like"
        } else if favorIndex == 2 {
            return "app/api/yuepa/like"
        }
        return "app/api/video/like"
    }
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}
//MARK: - 用户删除观看历史
class UserDelWatchRecordsApi: XSVideoBaseAPI {
    
    static let kVideo_Ids = "video_ids"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/video/history/remove"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}


//MARK: - 用户签到
class UserSignApi: XSVideoBaseAPI {
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/user/sign"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}
//MARK: - 用户加关注
class UserAddFollowApi: XSVideoBaseAPI {
    
    static let kUserId = "to_user_id"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/relation/do"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
    
}


//MARK: - 用户取消关注
class UserCancleFollowApi: XSVideoBaseAPI {
    
    static let kUserId = "to_user_id"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/relation/do"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
    
}

//MARK: - 金币购买视频
class UseBuyVideoApi: XSVideoBaseAPI {
    
    static let kVideoId = "video_id"

    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/video/buy"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: - 金币购买图集
class UseBuyImgsApi: XSVideoBaseAPI {
    
    static let kPicId = "id"

    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/photos/buy"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: - 金币购买楼风信息
class UseBuyMsgApi: XSVideoBaseAPI {
    
    static let kMsgId = "id"

    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/floor/buy"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: - 用户手機號找回用户信息
class AcountBackWithPhoneApi: XSVideoBaseAPI {
    
    static let kMobile = "phone"
    static let kCode = "code"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/user/bindphone"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: - 用户反馈Api
class UserFadeBackApi: XSVideoBaseAPI {
    
    /// 反馈内容
    static let kContent = "content"
    /// 联系方式
    static let kContact = "contact"
    /// 问题keys
    static let kKeys = "types"
    /// 上传成功的图片名称
    static let kCover_filename = "imgs"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/feedback/submit"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}


//MARK: - idcardFindApi
class RecallByCardApi: XSVideoBaseAPI {
    
    static let kQRCode = "qrcode"
 
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/user/findbyqr"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
       return super.reform(params)
    }
}

//MARK: - 用户邀請规则借口
class InvitationRulesApi: XSVideoBaseAPI {
    
 
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/invite/rule"
    }
    
    override func shouldCache() -> Bool {
        return true
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}


//MARK: - 补填邀請碼Api
class SetInviteCodeApi: XSVideoBaseAPI {
    
    /// 卷码
    static let kCode = "code"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/user/bindcode"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}

//MARK: - 卷码 信息
class VipConvertInfoApi: XSVideoBaseAPI {
    
    static let kCode = "code"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/code/info"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
    
}

//MARK: - vip兌換Api
class VipCardExChangeApi: XSVideoBaseAPI {
    /// 卷码
    static let kCode = "code"
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/code/exchange"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}


//MARK: - 上传提交Api
class PushVideoApi: XSVideoBaseAPI {

    static let kTitle = "title"
    static let kCoverImage = "cover"
    static let kVideo = "mu"
    static let kTagIds = "type_ids"
    static let kDuration = "duration"
    static let kCoins = "coins"
    static let kIslong = "is_long"
    
    static let kVideoLocalPath = "videoLocal"
    static let kImageLocalPath = "coverLocalPath"
    
    static let kUplodAt = "UplodAt"
    static let kTagModels = "TagModels"
    static let kTagParams = "TagParams"
    static let kUploadStatu = "UploadStatu"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/video/user/upload"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}



//MARK: - 删除上传列表
class UserDeleteWorkApi: XSVideoBaseAPI {
    /// 卷码
    static let kVideoId = "video_id"
    
    override func loadData() -> Int {
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/video/delete"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        return super.reform(params)
    }
}
