
import Foundation
import NicooNetwork

//MARK: -查询用户点赞视频列表Api
class UserFavorListApi: XSVideoBaseAPI {
    
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kIslong = "is_long"
    static let kDefaultCount = 10
    
    var pageNumber: Int = 1
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/video/like/list"
    }
    override func shouldCache() -> Bool {
        return false
    }
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        /// 分页参数
        var newParams: [String: Any] = [UserFavorListApi.kPageNumber: pageNumber,
                                        UserFavorListApi.kPageCount: UserFavorListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
    
}

//MARK: - 用户视频作品列表
class UserWorkListApi: XSVideoBaseAPI {
 
    static let kUserCode = "code"
    static let kIsLong = "is_long"
    static let kCheckStatu = "check"  // 不传：全部  0审核中 1已通过 2未通过
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 10
    
    var pageNumber: Int = 1
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/video/user/list"
    }
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        /// 分页参数
        var newParams: [String: Any] = [UserWorkListApi.kPageNumber: pageNumber,
                                        UserWorkListApi.kPageCount: UserWorkListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
}
//MARK: - 用户上传管理视频列表
class UserUploadListApi: XSVideoBaseAPI {
    static let kCheckStatu = "check"  // 不传：全部  0审核中 1已通过 2未通过
    static let kIslong = "is_long"
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 20
    
    var pageNumber: Int = 1
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return  "app/api/video/user/video"
    }
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        /// 分页参数
        var newParams: [String: Any] = [UserUploadListApi.kPageNumber: pageNumber,
                                        UserUploadListApi.kPageCount: UserUploadListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
}

//MARK: - 用户点赞 图集 列表Api
class UserFavorImgsApi: XSVideoBaseAPI {
    
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kImg_type = "images_type"
    static let kDefaultCount = 20
    
    var pageNumber: Int = 1
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/photos/list/like"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        /// 分页参数
        var newParams: [String: Any] = [UserFavorImgsApi.kPageNumber: pageNumber,
                                        UserFavorImgsApi.kPageCount: UserFavorImgsApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
}

//MARK: - 用户点赞  楼凤 列表Api
class UserFavorLFMsgApi: XSVideoBaseAPI {
    
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kImg_type = "images_type"
    static let kDefaultCount = 20
    
    var pageNumber: Int = 1
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/floor/list/like"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        /// 分页参数
        var newParams: [String: Any] = [UserFavorLFMsgApi.kPageNumber: pageNumber,
                                        UserFavorLFMsgApi.kPageCount: UserFavorLFMsgApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
}

//MARK: - 用户  tip 列表Api
class UserFavorTipTypeApi: XSVideoBaseAPI {
    
    // 分页参数
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 10
    
    var pageNumber: Int = 1
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/video/like/type/list"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        /// 分页参数
        var newParams: [String: Any] = [UserFavorTipTypeApi.kPageNumber: pageNumber,
                                        UserFavorTipTypeApi.kPageCount: UserFavorTipTypeApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
}


//MARK: - 用户购买视频列表
class UserBuyListApi: XSVideoBaseAPI {
 
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kIsLong = "is_long"
    static let kDefaultCount = 10
    
    var pageNumber: Int = 1
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    
    override func methodName() -> String {
        return "app/api/video/buy/list"
    }
    
    override func shouldCache() -> Bool {
        return false
    }
    
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        /// 分页参数
        var newParams: [String: Any] = [UserBuyListApi.kPageNumber: pageNumber,
                                        UserBuyListApi.kPageCount: UserBuyListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
}

//MARK: - 用户观看历史
class UserWatchReccordListApi: XSVideoBaseAPI {
 
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 10
    
    static let kIsLong = "is_long"
    
    var pageNumber: Int = 1
    // MARK: - Public method
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/video/history/list"
    }
    override func shouldCache() -> Bool {
        return false
    }
    // the optional method may used for pageable API manager
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        /// 分页参数
        var newParams: [String: Any] = [UserWatchReccordListApi.kPageNumber: pageNumber,
                                        UserWatchReccordListApi.kPageCount: UserWatchReccordListApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
}


//MARK: - 用户购买 楼风  列表
class UserBuyFLMsgsApi: XSVideoBaseAPI {
 
    static let kPageNumber = "page"
    static let kPageCount = "page_size"
    static let kDefaultCount = 20
    
    var pageNumber: Int = 1
    // MARK: - Public method
    
    override func loadData() -> Int {
        self.pageNumber = 1
        if self.isLoading {
            self.cancelAllRequests()
        }
        return super.loadData()
    }
    func loadNextPage() -> Int {
        if self.isLoading {
            return 0
        }
        return super.loadData()
    }
    override func methodName() -> String {
        return "app/api/floor/list/buy"
    }
    override func shouldCache() -> Bool {
        return false
    }
    override func reform(_ params: [String: Any]?) -> [String: Any]? {
        var newParams: [String: Any] = [UserBuyFLMsgsApi.kPageNumber: pageNumber,
                                        UserBuyFLMsgsApi.kPageCount: UserBuyFLMsgsApi.kDefaultCount]
        if params != nil {
            for (key, value) in params! {
                newParams[key] = value
            }
        }
        return super.reform(newParams)
    }
    override func manager(_ manager: NicooBaseAPIManager, beforePerformSuccess response: NicooURLResponse) -> Bool {
        return true
    }
    override func manager(_ manager: NicooBaseAPIManager, afterPerformSuccess response: NicooURLResponse) {
        self.pageNumber += 1
    }
}



