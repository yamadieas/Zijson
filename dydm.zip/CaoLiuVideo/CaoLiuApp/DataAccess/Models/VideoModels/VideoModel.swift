

import Foundation

/// 首页视频类型。 "V" - 正常视频  "A" - 广告
enum HomeVideoType: String, Codable {
    case videoType = "v"   // 视频
    case adType = "a"  // 广告
}
class VideoHomeNew: Codable {
    var type: HomeVideoType?
    var video: VideoNew?
    var ad: AdHome?
}

class WatchRecordList: Codable {
    var timeKey: String?
    var recordModels: [WatchRecord]?
}

class WatchRecord: Codable {
    var duration: Int?
    var is_long: Int?
    var time: String?
    var uid: String?
    var vid: Int?
    var time_diff_key: String?
    var video: VideoNew?
    
    var isSelected: Bool? = false
}

class WorksLisModel: Codable {
    var current_page: Int?
    var data:[VideoNew]?
    var total: Int?
}
class VideoNew: Codable {
    var id: Int?
    var title: String?
    var cover: String?
    var smu: String?
    var duration: Int?
    var uid: String?
    var from: Int?
    var category: [SearchHotTips]?
    var user: CLUserInfo?
    var ad: [AdHome]?
    /// 自己插入的广告
    var recAd: AdHome?
    /// 搜索插入的 热搜关键词
    var hotSearchs: [SearchHotTips]?
    
    var coins: Int?
    var vip_coins: Int?
    var mu: String?   /// 播放地址
    var like: Int?
    var hot: Int?      // 热度
    var play: Int?      // 播放量
    var is_free: Int?
    var buy_video_count: Int?      // 销量
    var is_like: Int?
    var is_long: Int?
    var is_attention: Int? = 0
    var auth_error: Auth_error?
    var isAuthAccross: Bool? = false
    var countdown: CountDown?
    
    var check: Int?
    var created_at: String?
    
    var textHeight: Float?
    
    /// 上次看到啥位置
    var lastWatchDurration: Int?
}
class AdHome: Codable {
    var id: Int?
    var position: String?
    var title: String?
    var cover: String?
    var click: Int?
    var link: String?
    var type: Int?    //1为图片2为视频 为视频时用play地址播放
    var play: String?
}

class Auth_error: Codable {
    var key: Int?
    var info: String?
}

class CountDown: Codable {
    var countdown_intro:String?
    var image: String?
    var countdown_time: Int?
    var countdown_link: String?
    var countdown_display: Int?
}



/// 视频列表model
class VideoListModel: Codable {
    var current_page: Int?
    var data: [VideoModel]?
    var total: Int?
}

/// 首页数据源列表
class VideoHomeListModel: Codable {
    var current_page: Int?
    var data: [HomeVideoModel]?
}


/// 首页model
class HomeVideoModel: Codable {
    var type: HomeVideoType?
    var video: VideoModel?
    var ad: AdvertiseModel?
}

/// 视频Model
class VideoModel: Codable {
    
    var id: Int?
    var title: String?
    var title_att: String?
    var created_at: String?
    var updated_at: String?
    var shift_original_filename: String?
    var shift_original_status: Int?
    var genre: Int?
    var user_id: Int?
    var _oid: Int?
    var _origin: String?
    
    var intro: String?
    var cover_path: String?
    var cover_oss_filename: String?
    var play_count: Int?
    var play_url_m3u8: String?
    var play_url_mp4: String?
    var play_url_m3u8_short: String?
    
    var isAuthAccross: Bool?  // false 不通过。 true 通过
    
    var is_coins: Int?            // 是否金币视频
    var coins: Int?               // 金币价格

    var recommend: Recommend?     // 是否点过❤️
    var comment_count: Int?       // 评论数
    var recommend_count: Int? = 0 // 点赞数
    var view_flag: Bool? = false  // 当前用户是否可以播放 本视频
    var keys: [VideoKey]?         // 视频标签
    
    var check: CheckStatu?        // 用于作品的审核狀態
    var isLocalUpload: Bool? = false // 是否为本地上传Model
    var localUrl: URL?
}

/// 是否点👍
enum Recommend: Int, Codable {
    case notRecommend = 0
    case recommend = 1
    
    var isFavor: Bool {
        switch self {
        case .recommend:
            return true
        case .notRecommend:
            return false
        }
    }
}

/// 作品审核狀態
///
/// - waitForCheck: 待审核
/// - passCheck: 已审核通过
/// - notPassCheck: 未审核通过
//  - uploading: 本地添加的，正在上传狀態
enum CheckStatu: Int, Codable {
    case waitForCheck = 0
    case passCheck = 1
    case notPassCheck = -1
    // 下面两个是本地的狀態
    case uploading = 2
    case uploadFailed = 3
}

/// 首页广告
struct AdvertiseModel: Codable {
    var id: Int?
    var ad_type: String?
    var title: String?
    var remark: String?
    var redirect_url: String?   // 广告去哪
    var cover_path: String?     // 封面
    var play_url_m3u8: String?
    var recommend_count: Int?   // 点赞数
    var recommend: Recommend?   // 是否点过❤️
    var comment_count: Int?     // 评论数
}


struct GameEnterData: Codable {
    var id: Int?
    var sk_icon: String?
    var banner_icon: String?
    var created_at: String?
}

struct GameUrlData: Codable {
    var playerID: String?
    var lobbyAddr: String?
    var token: String?
}

/// 视频key
struct VideoKey: Codable {
    var key_id: Int?
    var title: String?
    var pivot: Pivot?
}

struct Pivot: Codable {
    var video_id: Int?
    var key_id: Int?
}

/// 系列分类列表model
struct CateTypeListModel: Codable {
    var current_page: Int?
    var data: [VideoCategoryModel]?
}

/// 视频大分类列表MOdel
struct VideoCategoryModel: Codable {
    var id: Int?
    var key_id: Int?
    var keys_title: String?
    var keys_cover: String?
    var view_key_title: String?
    var intro: String?
    var cover_filename: String?
    var page: String?
    var recommend: Int?
    var updated_at: String?
    var updated_at_string: String?
    var video_lists:[VideoModel]?
    var relation_keys: [VideoKey]?
}

/// 视频评论列表MOdel
class VideoCommentListModel: Codable {
    var current_page: Int?
    var data: [VideoCommentModel]?
    var total: Int?
}

/// 评论回复列表MOdel
class CommentAnswerListModel: Codable {
    var current_page: Int?
    var data: [CommentAnswerModel]?
    var total: Int?
}


class VideoCommentModel: Codable {
    var id: Int?
    var parent_id: Int?
    var video_id: Int?
    var topic_content_id: Int?

    var user_id: Int?
    var content: String?
    var status: Int?
    var ip: String?
    var created_at: String?
    var updated_at: String?
    var deleted_at: String?
    var nikename: String?
    var cover_path: String?
    var time: String?
    var like: Int?      // 喜歡数量
    var is_like: Int?   // 是否👍
    var comment: [CommentAnswerModel]?
    /// 是否已经拉取全部f回复
    var isAllAnswers: Bool? = false
    /// 当前区是否展开
    var isOpen: Bool? = false
    /// 当前请求的页码
    var answerPageNumber: Int? = 1
}

///视频子评论模型
class CommentAnswerModel: Codable {
    
    var id: Int?
    var parent_id: Int?
    var video_id: Int?
    var user_id: Int?
    var nikename: String?
    var cover_path: String?
    var content: String?
    var status: Int?
    var ip: String?
    var created_at: String?
//    var updated_at: String?
//    var deleted_at: String?
    var time: String?
    /// 是否是作者
    var isZZ: Bool? = false
}

///视频点赞评论
class VideoCommentLikeModel: Codable {
    var result: Int?
}

struct StrInt: Codable {
    var int:Int {
        didSet {
            let stringValue = String(int)
            if  stringValue != string {
                string = stringValue
            }
        }
    }
    
    var string:String {
        didSet {
            if let intValue = Int(string), intValue != int {
                int = intValue
            }
        }
    }
    
    init(from decoder: Decoder) throws {
        let singleValueContainer = try decoder.singleValueContainer()
        
        if let stringValue = try? singleValueContainer.decode(String.self)
        {
            string = stringValue
            int = Int(stringValue) ?? 0
            
        } else if let intValue = try? singleValueContainer.decode(Int.self)
        {
            int = intValue
            string = String(intValue);
        } else
        {
            int = 0
            string = ""
        }
    }
}

class ShareContentModel: Codable {
    var cover: String?
    var content: String?
    var ini: String?
    var ini_people: String?
    var ini_content: String?
    var ini_cash_back: String?
}
