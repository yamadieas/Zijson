
import UIKit
import NicooNetwork

class RegisterLoginViewModel: NSObject {
    
    
    private lazy var ipApi: UserCheckIpApi = {
        let api = UserCheckIpApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var registerApi: UserRegisterApi = {
        let api = UserRegisterApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var untieApi: UserUntieApi = {
        let api = UserUntieApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var sendCodeApi: SendCodeApi = {
        let api = SendCodeApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var imgCodeApi: ImageCodeApi = {
        let api = ImageCodeApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    
    private lazy var refreshTokenApi: RefreshTokenApi = {
        let api = RefreshTokenApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var deviceRegisterApi: DeviceRegisterApi = {
        let api = DeviceRegisterApi()
        api.paramSource = self
        api.delegate = self
        return api
    }()
    private lazy var updateAPI: AppUpdateApi = {
        let api = AppUpdateApi()
        api.delegate = self
        api.paramSource = self
        return api
    }()
    /// 参数
    var paramsRegister: [String: Any]?
    var paramsLogin: [String: Any]?
    var paramsSendCode: [String: Any]?
    var paramsChangePsw: [String: Any]?
    /// 注册接口回调
    var loadRegisterApiSuccess:(() ->Void)?
    var loadRegisterApiFail:((_ msg: String) ->Void)?
    /// 登錄接口回调
    var loadLoginApiSuccess:(() ->Void)?
    var loadLoginApiFail:((_ msg: String) ->Void)?
    /// 發送验证码接口回掉
    var loadSendCodeApiSuccess:(() ->Void)?
    var loadSendCodeApiFail:((_ msg: String) ->Void)?
    /// 修改密码接口回调
    var loadChangePswApiSuccess:(() ->Void)?
    var loadChangePswApiFail:((_ msg: String) ->Void)?
    /// 检查更新接口回调
    var loadCheckVersionInfoApiSuccess:(() ->Void)?
    var loadCheckVersionInfoApiFail:((_ msg: String) ->Void)?
    
    var refreshTokenSuccessCallBack:((_ newToken: String) ->Void)?
    
    /// 注册成功
    var loadDeviceRegisterSuccess:(() ->Void)?
    var loadDeviceRegisterFail:(() -> Void)?
    /// 图片验证码
    var imgCodeSuccessCallBack:((_ imgCode: String) ->Void)?
    /// ipCheck成功
    var checkIpSuccess:(() ->Void)?
    var checkIpFail:((_ msg: String) -> Void)?
    
    var codeModel: CodeModel?
    
    var versionInfo: AppVersionInfo?
    
    var isInGameRegist: Bool = false
    

    /// 检查是否需要更新
    func checkUpdateInfo(succeedHandler: @escaping (() -> ()),
                         failHandler: @escaping (_ failMessage: String) -> ()) {
        loadCheckVersionInfoApiSuccess = succeedHandler
        loadCheckVersionInfoApiFail = failHandler
        let _ = updateAPI.loadData()
    }
    
    /// 检测ip
    func checkIp(_ params: [String: Any]?,
                       succeedHandler: @escaping (() -> ()),
                       failHandler: @escaping (_ msg: String) -> ()) {
        paramsRegister = params
        checkIpSuccess = succeedHandler
        checkIpFail = failHandler
        let _ = ipApi.loadData()
    }
    
    /// 注册
    func reginsterUser(_ params: [String: Any],
                       succeedHandler: @escaping (() -> ()),
                       failHandler: @escaping (_ msg: String) -> ()) {
        paramsRegister = params
        registerApi.isGameBind = isInGameRegist
        loadRegisterApiSuccess = succeedHandler
        loadRegisterApiFail = failHandler
        let _ = registerApi.loadData()
    }
    /// 解除手机号
    func untiePhone(_ params: [String: Any],
                    succeedHandler: @escaping (() -> ()),
                    failHandler: @escaping (_ msg: String) -> ()) {
        paramsRegister = params
        loadRegisterApiSuccess = succeedHandler
        loadRegisterApiFail = failHandler
        let _ = untieApi.loadData()
    }
    /// 發送验证码
    func sendCode(_ params: [String: Any],
                  succeedHandler: @escaping (() -> ()),
                  failHandler: @escaping (_ msg: String) -> ()) {
        paramsSendCode = params
        if let imgCode = params[SendCodeApi.kImgCode] as? String, !imgCode.isEmpty {
            sendCodeApi.isGameCode = true
        } else {
            sendCodeApi.isGameCode = false
        }
        loadSendCodeApiSuccess = succeedHandler
        loadSendCodeApiFail = failHandler
        let _ = sendCodeApi.loadData()
    }
    /// 图片验证码
    func imageCode(_ params: [String: Any]?,
                   succeedHandler: @escaping ((_ imgCode: String) -> ()),
                  failHandler: @escaping (_ msg: String) -> ()) {
        paramsSendCode = params
        imgCodeSuccessCallBack = succeedHandler
        //loadSendCodeApiFail = failHandler
        let _ = imgCodeApi.loadData()
    }
    
    /// 设备注册
    func registerDevice(succeedHandler: @escaping (() -> ()),
                        failHandler: @escaping () -> ()) {
        loadDeviceRegisterSuccess = succeedHandler
        loadDeviceRegisterFail = failHandler
        let _ = deviceRegisterApi.loadData()
    }
    /// 刷新token
    func refreshToken(succeedHandler: @escaping ((_ newToken: String) -> ())) {
        refreshTokenSuccessCallBack = succeedHandler
        let _ = refreshTokenApi.loadData()
    }

}

// MARK: - PUBLIC FUNCS
extension RegisterLoginViewModel {
    
    func getCodeModel() -> CodeModel {
        if codeModel != nil {
            return codeModel!
        }
        return CodeModel()
    }
    
    func getInviteCode() -> [String: Any]? {
        let pastesss = UIPasteboard.general.string
        DLog("inviteCodeFrom : == \(pastesss ?? "")")
        if let paste = UIPasteboard.general.string, (paste.hasPrefix("wp_")) {
            //如果剪贴板中的内容包含邀請碼
            DLog("inviteCodeFrom : == \(paste)")
            if let paramString = paste.components(separatedBy: "wp_").last {
                DLog("inviteCodeFrom : == \(paramString)")
                var params = [String: Any]()
                let paramsValues = paramString.components(separatedBy: "#")
                DLog("paramsValues = \(paramsValues)")
                if paramsValues.count >= 2 {
                    params[DeviceRegisterApi.kInviteCode] = paramsValues[0]
                    params[DeviceRegisterApi.kChannel] = paramsValues[1]
                    AppInfo.share().channel = paramsValues[1]
                } else if 1 <= paramsValues.count && paramsValues.count < 2 {
                    params[DeviceRegisterApi.kInviteCode] = paramsValues[0]
                }
                return params
            }
        }
        return nil
    }
   
}

// MARK: - Privite Funcs
 private extension RegisterLoginViewModel {
    
    func sendCodeSuccess(_ model: CodeModel) {
        codeModel = model
    }
    
    func checkVersionSuccess(_ model: AppVersionInfo) {
        versionInfo = model
        loadCheckVersionInfoApiSuccess?()
    }
    
    func deviceRegisterSuccess(_ model: DeviceAuthModel) {
        UserModel.share().authInfo = model
        UserDefaults.standard.set(model.auth?.token, forKey: UserDefaults.kUserToken)
        loadDeviceRegisterSuccess?()
    }
}

// MARK: - NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate
extension RegisterLoginViewModel: NicooAPIManagerParamSourceDelegate, NicooAPIManagerCallbackDelegate {
    
    func paramsForAPI(_ manager: NicooBaseAPIManager) -> [String : Any]? {
        if manager is UserRegisterApi || manager is UserUntieApi {
            return paramsRegister
        }
        if manager is SendCodeApi {
            return paramsSendCode
        }
        if manager is DeviceRegisterApi {
             DLog("deviceId = \(UIDevice.current.getIdfv())")
            let vparam = "\(ConstValue.kAppVersion)t"
            if var params = getInviteCode(), params.count > 0 {
                params[DeviceRegisterApi.kDevice_code] = UIDevice.current.getIdfv()
                params[DeviceRegisterApi.kDevice_type] = "I"
                params["version"] = vparam
                return params
            } else {
                return [DeviceRegisterApi.kDevice_code: UIDevice.current.getIdfv(), DeviceRegisterApi.kDevice_type : "I","version": vparam]
            }
        }
       
        if manager is AppUpdateApi {
            return [AppUpdateApi.kPlatform: AppUpdateApi.kDefaultPlatform, AppUpdateApi.kDomain: ""]
        }
        return nil
    }
    
    func managerCallAPISuccess(_ manager: NicooBaseAPIManager) {

        if manager is UserCheckIpApi {
            if let content = manager.response.content as? [String: Any], let result = content["result"] as? Int, result == 1 {
                checkIpSuccess?()
            } else {
                checkIpFail?("")
            }
        }
        if manager is UserRegisterApi || manager is UserUntieApi {
            loadRegisterApiSuccess?()
        }
        if manager is SendCodeApi {
            loadSendCodeApiSuccess?()
        }
        if manager is ImageCodeApi {
            if let model = manager.fetchJSONData(LoginRegisterReformer()) as? ImgCodeModel {
                if let imgBase64 = model.image, !imgBase64.isEmpty {
                    imgCodeSuccessCallBack?(imgBase64)
                }
            }
        }
        if manager is RefreshTokenApi {
            if let model = manager.fetchJSONData(LoginRegisterReformer()) as? AuthTokenModel {
                if let tokenNew = model.token, !tokenNew.isEmpty {
                    UserDefaults.standard.set(tokenNew, forKey: UserDefaults.kUserToken)
                    refreshTokenSuccessCallBack?(tokenNew)
                }
            }
        }
        if manager is DeviceRegisterApi {
            if let model = manager.fetchJSONData(LoginRegisterReformer()) as? DeviceAuthModel {
                deviceRegisterSuccess(model)
            }
        }
        if manager is AppUpdateApi {
            if let data = manager.fetchJSONData(AppUpdateReformer()) as? AppVersionInfo {
                checkVersionSuccess(data)
            }
        }
    }
    
    func managerCallAPIFailed(_ manager: NicooBaseAPIManager) {
        if manager is UserCheckIpApi {
            checkIpFail?(manager.errorMessage)
        }
        if manager.errorMessage == "401" {
            ProdValue.prod().tokenRefeshModel.refreshToken { (token) in
                _ = manager.loadData()
            }
            return
        }
        if manager is UserRegisterApi || manager is UserUntieApi {
            loadRegisterApiFail?(manager.errorMessage)
        }
        if manager is SendCodeApi {
            loadSendCodeApiFail?(manager.errorMessage)
        }
        if manager is ImageCodeApi {
            XSAlert.show(type: .text, text: manager.errorMessage)
        }
        if manager is DeviceRegisterApi {
            loadDeviceRegisterFail?()
        }
        if manager is AppUpdateApi {
            loadCheckVersionInfoApiFail?(manager.errorMessage)
        }
        if manager is RefreshTokenApi {
        }
    }
}
