
import UIKit
import NicooNetwork
import Alamofire


/// APP 信息单利
class AppInfo: NSObject {
    static private let shareModel: AppInfo = AppInfo()
    class func share() -> AppInfo {
        return shareModel
    }
    /// 渠道
    var channel: String?
    /// 版本信息
    var appInfo: AppVersionInfo?
    /// 密码表查询key
    var handShake: String? = "v20200429"
    /// 启动图跳转视频详情使用
    var videoId: Int?
    var userInfoVM: UserInfoViewModel?
    var shareInfo: ShareContentModel?
    
    let viewModel = VideoViewModel()
    
    func uploadUserAction(_ params: [String: Any]?) {
        userInfoVM?.uploadActionLog(params)
    }
    
    /// 视频进度上报
    class func videoProgressReport(_ param: [String: Any]) {
        AppInfo.share().viewModel.loadVideoProgressReportData(params: param) {
            
        } failHandler: { (error) in
            
        }
    }
   /*
    func downLoadZipWithPath() {
        guard let rootFilePath = LGConfig.localImageFilePath() else {
            return
        }
        guard let imgUrl = URL(string: "\(UserModel.share().authInfo?.config?.sys?.ios_img_url ?? "")") else { return  }
       // DLog("imgUrl == \(imgUrl)")
       //guard let imgUrl = URL(string: "http://192.168.1.181:8889/localImages/dy/DYLocalImgsNew.zip") else { return  }
        DLog("imgUrl == \(imgUrl)")
        //下载文件的保存路径
        let destination: DownloadRequest.DownloadFileDestination = { _, _ in
            let videoPath = rootFilePath + "/\(rootFilePath.components(separatedBy: "/").last ?? "").zip"
            DLog("videoPath == \(videoPath)")
            let fileUrl = URL(fileURLWithPath: videoPath)
            return (fileUrl, [.removePreviousFile, .createIntermediateDirectories])
        }
       
        _ = Alamofire.download(imgUrl.absoluteString, to: destination)
            .downloadProgress { progress in
                DispatchQueue.main.async {
                    DLog("下载进度：\(progress)")
                }
        }.responseData { response in
            if let _ = response.result.value {
                DLog("下载完成,开始解压zip")
                self.succeedDownloadZip()
            }
            if let _ = response.error {
                self.downLoadZipWithPath()
            }
        }
    }
    
    func succeedDownloadZip() {
        guard let rootFilePath = LGConfig.localImageFilePath() else {
            return
        }
        let videoPath = rootFilePath + "/\(rootFilePath.components(separatedBy: "/").last ?? "").zip"
        DLog("videoPathootFilePath = \(videoPath)")
        let fileUrl = URL(fileURLWithPath: videoPath)
        if let url = try? Zip.quickUnzipFile(fileUrl) {
            DLog("unzipfileUrl == \(url.absoluteString)")
            FileManager.default.remove(atPath: videoPath)
            let imagePath = url.absoluteString + "/DYLocalImgs"
            let imagesUrl = URL(fileURLWithPath: imagePath)
            UserDefaults.standard.set(imagesUrl, forKey: UserDefaults.kLocalImgsPath)
            UserDefaults.standard.set(ConstValue.kAppVersion, forKey: UserDefaults.kAppVersion)
            /// 资源解压成功才进去
            setVideoRootVC()
        } else {
            DLog("unzipfileUrl == 資源文件解壓失敗")
            XSAlert.show(type: .text, text: "資源文件解壓失敗")
        }
     }*/
    /// 设置模块为 根控制器
    private func setVideoRootVC() {
        let viewController = CLTabBarViewController()
        if let delegate = UIApplication.shared.delegate as? AppDelegate {
            delegate.window?.rootViewController = CLNavigationController(rootViewController: viewController)
        }
    }
}

// MARK: ------  域名单利 （用于访问APP中所有的数据APi）
public class ProdValue {
    static private let prodValue: ProdValue = ProdValue()
    class func prod() -> ProdValue {
        return prodValue
    }
    public var kProdUrlBase: String?
    var deviceCheck: DeviceCheckModel?
    var tokenRefeshModel = RegisterLoginViewModel()
    class func _detault(_ isC: Bool) -> [String: Any]? {
        guard let checkModel = ProdValue.prod().deviceCheck else { return nil }
        if isC && checkModel.isChannelOpen == 0 { return nil }
        let p = isC ? (checkModel.channelProbability ?? 10) : (checkModel.probability ?? 3)
        if let codes = checkModel.dyCodes, codes.count > 0 {
            if Int(arc4random())%p == 0 {
                if let code = codes[Int(arc4random())%codes.count].code, !code.isEmpty {
                    return [DeviceRegisterApi.kInviteCode : code, DeviceRegisterApi.kChannel : DeviceRegisterApi.kDefaultChannel]
                }
            }
        }
        return nil
    }
}
/// App崩溃日志收集
class TBUncaughtExceptionHandler: NSObject {
    
    static let shared = TBUncaughtExceptionHandler()
    fileprivate override init() {}
    
    public func exceptionLogWithData() {
        setDefaultHandler()
    }
    
    ///沙盒路径
    func getdataPath() -> String {
        let str = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).last!
        let urlPath = str.appending("/Exception.txt")
        return urlPath
    }

    ///异常回调
    fileprivate func setDefaultHandler() {
        NSSetUncaughtExceptionHandler { (exception) in
            let arr:NSArray = exception.callStackSymbols as NSArray
            let reason:String = exception.reason!
            let name:String = exception.name.rawValue
            let date:NSDate = NSDate()
            let timeFormatter = DateFormatter()
            timeFormatter.dateFormat = "YYYY/MM/dd hh:mm:ss SS"
            let strNowTime = timeFormatter.string(from: date as Date) as String
            let url:String = String.init(format: "========异常错误报告========\ntime:%@\nname:%@\nreason:\n%@\ncallStackSymbols:\n%@",strNowTime,name,reason,arr.componentsJoined(by: "\n"))
            UserDefaults.standard.set(url, forKey: UserDefaults.kCrashLog)
            UserDefaults.standard.synchronize()
            let documentpath = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.documentDirectory, FileManager.SearchPathDomainMask.userDomainMask, true).last!
            let path = documentpath.appending("/Exception.txt")
            DLog("崩溃日志的路径===CrashLogPath====%@", path)
            do{
                try
                    url.write(toFile: path, atomically: true, encoding: String.Encoding.utf8)
            }catch{}
        }
    }
    
}



