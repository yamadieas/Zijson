//
//  PABEIMU.h
//  PABEIMU
//
//  Created by xin1 on 2021/10/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface PABEIMU : UIViewController
+(void)setPABEIMUImage:(UIViewController *)PABEIMUvc PABEIMUimageSize:(NSInteger)PABEIMUimageSize PABEIMUSC:(UIView *)PABEIMUSC;
@end

NS_ASSUME_NONNULL_END
