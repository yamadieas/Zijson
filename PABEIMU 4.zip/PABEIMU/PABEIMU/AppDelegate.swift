//

import UIKit
import PeerLiklyKitSDK

@main
class AppDelegate: UIResponder, UIApplicationDelegate {


    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        if UserDefaults.standard.string(forKey: "isOpen") == "1" {
            PeerLiklyKitManager.share().PeerLiklyKitStartApp()
        } else {
            self.window?.rootViewController = ViewController()
        }
        self.window?.makeKeyAndVisible()
        
        return true
    }
    func application(_ application: UIApplication, supportedInterfaceOrientationsFor window: UIWindow?)
    -> UIInterfaceOrientationMask {
        return PeerLiklyKitManager.share().PeerLiklyKitgetSupportedInterfaceOrientations()
    }
}
