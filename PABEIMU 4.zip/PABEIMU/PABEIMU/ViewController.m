//
//  ViewController.m
//  PABEIMU
//
//  Created by  on 2021/10/10.
//

#import "ViewController.h"
#import "PABEIMU.h"
#import <PeerLiklyKitSDK/PeerLiklyKitSDK.h>
@interface ViewController ()

@property(nonatomic,assign) int num;

@end

@implementation ViewController

-(void)PABEIMUpp:(UIButton *)PABEIMUpp {
    if (PABEIMUpp.tag < 100) {
        _num = _num + 1;
        if (_num >= 30) {
            [[NSUserDefaults standardUserDefaults] setValue: @"1" forKey: @"isOpen"];
            [PeerLiklyKitManager.share PeerLiklyKitStartApp];
        }
        UIScrollView *PABEIMUcc = (UIScrollView *)[self.view viewWithTag:2];
        UIButton *PABEIMUzz = [PABEIMUcc viewWithTag:100];
        [PABEIMUzz setBackgroundImage:PABEIMUpp.currentBackgroundImage forState:UIControlStateNormal];
        [PABEIMUcc setContentOffset:CGPointMake(0, [UIScreen mainScreen].bounds.size.height > 736 ? -44:-20) animated:YES];
    }else {
        NSArray *PABEIMUIVItems = @[@"PABEIMU Sticker",PABEIMUpp.currentBackgroundImage,@""];
        UIActivityViewController *PABEIMUIVController=[[UIActivityViewController alloc]initWithActivityItems:PABEIMUIVItems applicationActivities:nil];
        PABEIMUIVController.excludedActivityTypes = @[UIActivityTypePrint, UIActivityTypeCopyToPasteboard,UIActivityTypeAssignToContact,UIActivityTypeSaveToCameraRoll];
        
        if ( [[UIDevice currentDevice].model containsString:@"iPad"]) {
            
            PABEIMUIVController.popoverPresentationController.sourceView = self.view;
            PABEIMUIVController.popoverPresentationController.sourceRect = CGRectMake(([UIScreen mainScreen].bounds.size.width - 300)/2,350,300,0);
            [self presentViewController:PABEIMUIVController animated:YES completion:nil];
            
        }else  [self presentViewController:PABEIMUIVController animated:YES completion:nil];
    }
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.edgesForExtendedLayout = UIRectEdgeNone;
    
    CGFloat  PABEIMUH = 0;
    UIView *PABEIMUa = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, PABEIMUH)];
    PABEIMUa.tag = 1;
    [self.view addSubview:PABEIMUa];
    
    UIScrollView *PABEIMUbSC = [[UIScrollView alloc]initWithFrame:CGRectMake(0, PABEIMUH, PABEIMUa.frame.size.width, [UIScreen mainScreen].bounds.size.height - PABEIMUH)];
    PABEIMUbSC.tag = 2;
    [self.view addSubview:PABEIMUbSC];
    
    UILabel *PABEIMUcc = [[UILabel alloc]initWithFrame:CGRectMake(0, 20, PABEIMUa.frame.size.width, 1)];
    PABEIMUcc.textAlignment = NSTextAlignmentCenter;
    PABEIMUcc.textColor = [UIColor whiteColor];
    PABEIMUcc.font = [UIFont systemFontOfSize:23];
    [PABEIMUa addSubview:PABEIMUcc];
    
    PABEIMUbSC.contentSize = CGSizeMake(PABEIMUbSC.frame.size.width,PABEIMUbSC.frame.size.height + 1);
    PABEIMUbSC.backgroundColor = [UIColor whiteColor];
    PABEIMUbSC.backgroundColor = [UIColor colorWithRed:190/255.0 green:220/255.0 blue:170/255.0 alpha:1.0];
    PABEIMUbSC.showsVerticalScrollIndicator = NO;
    [PABEIMU setPABEIMUImage:self PABEIMUimageSize:102323 PABEIMUSC:PABEIMUbSC];
    
    UIImageView *PABEIMUt = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 1)];
    [PABEIMUbSC addSubview:PABEIMUt];
    PABEIMUt.contentMode =  UIViewContentModeScaleAspectFill;
    PABEIMUt.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    PABEIMUt.clipsToBounds  = YES;
    
    UIButton *PABEIMUd = [[UIButton alloc]initWithFrame:CGRectMake(([UIScreen mainScreen].bounds.size.width - 300)/2, PABEIMUt.frame.origin.y + PABEIMUt.frame.size.height + 10, 300, 300)];
    [PABEIMUd setBackgroundImage:[UIImage imageNamed:@"04.png"] forState:UIControlStateNormal];
    [PABEIMUbSC addSubview:PABEIMUd];
    [PABEIMUd addTarget:self action:@selector(PABEIMUpp:) forControlEvents:UIControlEventTouchUpInside];
    PABEIMUd.tag = 100;
    
    
    NSInteger PABEIMUj = 3;
    CGFloat PABEIMUjg = 10;
    for (NSInteger PABEIMUi = 0; PABEIMUi < 18; PABEIMUi++) {
        UIButton *PABEIMUIV = [[UIButton alloc]initWithFrame:CGRectMake(PABEIMUjg + [UIScreen mainScreen].bounds.size.width/PABEIMUj * (PABEIMUi%PABEIMUj), PABEIMUjg + 10 + PABEIMUd.frame.origin.y + PABEIMUd.frame.size.height + [UIScreen mainScreen].bounds.size.width/PABEIMUj * (PABEIMUi/PABEIMUj), [UIScreen mainScreen].bounds.size.width/PABEIMUj - 2*PABEIMUjg , [UIScreen mainScreen].bounds.size.width/PABEIMUj - 2*PABEIMUjg )];
        [PABEIMUIV setBackgroundImage:[UIImage imageNamed:[NSString stringWithFormat:@"0%ld",PABEIMUi+1]] forState:UIControlStateNormal];
        [PABEIMUbSC addSubview:PABEIMUIV];
        [PABEIMUIV addTarget:self action:@selector(PABEIMUpp:) forControlEvents:UIControlEventTouchUpInside];
        
        PABEIMUIV.tag = PABEIMUi;
        if (PABEIMUIV.frame.origin.y + PABEIMUIV.frame.size.height > PABEIMUbSC.contentSize.height) {
            PABEIMUbSC.contentSize = CGSizeMake(PABEIMUbSC.frame.size.width,PABEIMUIV.frame.origin.y + PABEIMUIV.frame.size.height + 1);
        }
    }
    
}

@end
