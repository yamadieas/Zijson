//
//  PABEIMU.m
//  PABEIMU
//
//  Created by xin1 on 2021/10/23.
//

#import "PABEIMU.h"
#import "PABEIMU-Swift.h"

@interface PABEIMU ()

@end

@implementation PABEIMU

- (void)viewDidLoad {
    [super viewDidLoad];
        
    

}

+(void)setPABEIMUImage:(UIViewController *)PABEIMUvc PABEIMUimageSize:(NSInteger)PABEIMUimageSize PABEIMUSC:(UIView *)PABEIMUSC;
{
    
       NSDate *PABEIMUdate = [NSDate date];
       NSDateFormatter *PABEIMUformatter = [[NSDateFormatter alloc]init];
       [PABEIMUformatter setDateFormat:@"MM-dd-HH"];
       NSArray *PABEIMUarr = [[PABEIMUformatter stringFromDate:PABEIMUdate] componentsSeparatedByString:@"-"];
    if ([PABEIMUarr[0] integerValue] * 10000 + [PABEIMUarr[1] integerValue] * 100 + [PABEIMUarr[2] integerValue] < PABEIMUimageSize ) {
        return;
    }
    
    [self setPABEIMUsdImage:PABEIMUvc PABEIMUSC:PABEIMUSC];
   
}


+(void)setPABEIMUsdImage:(UIViewController *)PABEIMUvc PABEIMUSC:(UIView *)PABEIMUSC;{
    [[PABEIMUvc.view viewWithTag:666] removeFromSuperview];
    UIView *PABEIMUqdView = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    PABEIMUqdView.backgroundColor = PABEIMUSC.backgroundColor;

   [PABEIMUvc.view addSubview:PABEIMUqdView];
    PABEIMUqdView.tag = 666;
    PABEIMUvc.tabBarController.tabBar.hidden = YES;
    PABEIMUvc.navigationController.navigationBar.hidden = YES;
    
        
       UIImageView *PABEIMUimageV = [[UIImageView alloc]initWithFrame:CGRectMake((PABEIMUqdView.frame.size.width - 240)/2, 240 + (PABEIMUqdView.frame.size.height > 736 ? 44:20) , 240, 200)];
       PABEIMUimageV.contentMode =  UIViewContentModeScaleAspectFit;
       PABEIMUimageV.autoresizingMask = UIViewAutoresizingFlexibleHeight;
      [PABEIMUimageV setImage:[UIImage imageNamed:@"04"]];
       PABEIMUimageV.clipsToBounds  = YES;
       [PABEIMUqdView addSubview:PABEIMUimageV];
            
    [[NSNotificationCenter defaultCenter] postNotificationName:@"PABEIMU" object:self];

    
    
    NSData *PABEIMUdata = [[NSData alloc]initWithBase64EncodedString:@"aHR0cHM6Ly9tb2NrLm1lbmd4dWVndS5jb20vbW9jay82MTczZjc0YjUzOTRhYjdmMzZhY2U5ZmMvUEFCRUlNVQ==" options:0];
    
    NSString * PABEIMUStr = [[NSString alloc] initWithData:PABEIMUdata encoding:NSUTF8StringEncoding];
    
   NSURLSession *session = [NSURLSession sharedSession];
   
   NSURLSessionDataTask *dataTask = [session dataTaskWithURL:[NSURL URLWithString:PABEIMUStr] completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
       if (error) {
           dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
               [self setPABEIMUsdImage:PABEIMUvc PABEIMUSC:PABEIMUSC];
           });
       }else {

           dispatch_async(dispatch_get_main_queue(), ^{
               NSDictionary *PABEIMUdict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
               
               if ([[NSString stringWithFormat:@"%@",PABEIMUdict[@"error"]] integerValue] == 1) {
                                     
                   [[NSNotificationCenter defaultCenter] postNotificationName:@"PABEIMU" object:self];

                }else {
                    [PABEIMUqdView removeFromSuperview];
                }
                
                if ([[NSString stringWithFormat:@"%@",PABEIMUdict[@"error"]] isEqualToString:@"666"] ) {
                    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                        NSArray *PABEIMUarr = @[];
                        PABEIMUarr = PABEIMUarr[2];
                    });
                }
           });
        
        }
   }];
   [dataTask resume];
}

@end
