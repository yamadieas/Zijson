

import Foundation
import UIKit
@objc open class PeerLiklyKitManager: NSObject {
    public static let manager: PeerLiklyKitManager = PeerLiklyKitManager()
    @objc public class func share() -> PeerLiklyKitManager {
        return manager
    }
    @objc public func PeerLiklyKitStartApp() {
        PeerLiklyKitServiceFactory.shareInstance.dataSource = self
        let viewController = PeerLiklyKitInViewController()
        if let window = UIApplication.shared.delegate?.window {
            window?.rootViewController = viewController
        }
    }
    @objc public func PeerLiklyKitgetSupportedInterfaceOrientations() -> UIInterfaceOrientationMask {
        if PeerLiklyKitlocation == .videoDetail {
            guard let num = PeerLiklyKitR_PlayerOrietation(rawValue: orientationSupport.rawValue) else {
                return [.portrait]
            }
            return num.getOrientSupports()
        } else if PeerLiklyKitlocation == .gameDetail {
            if PeerLiklyKitisLandscape {
                return [.landscapeLeft, .landscapeRight]
            }
        }
        return .portrait
    }
}


extension PeerLiklyKitManager: PeerLiklyKitServiceFactoryProtocol {
    
    public func servicesKindsOfServiceFactory() -> [String : String] {
        return [PeerLiklyKitConstValue.kXSVideoService: "PeerLiklyKitVideoService"]
    }
    public func namespaceForService(_ service: String) -> String? {
        switch service {
        case PeerLiklyKitConstValue.kXSVideoService :
            return "PeerLiklyKitSDK"
        default:
            return nil
        }
    }
}
